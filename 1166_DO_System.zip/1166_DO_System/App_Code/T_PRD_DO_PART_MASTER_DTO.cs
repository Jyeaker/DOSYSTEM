﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for T_PRD_DO_PART_MASTER_DTO
/// </summary>
public class T_PRD_DO_PART_MASTER_DTO
{
    public string _FACTORY_CD;
    public string _PART_NO;
    public string _DIM;
    public string _BLOCK_CD;
    public string _SUPPLIER_CD;
    public string _TOTAL_PROCESS_LT;
    public string _USER_ID;
    //add _DO_LOGIC,_SP_PLAN_SLIDE 20221005 cn
    public string _DO_LOGIC;
    public string _SP_PLAN_SLIDE;

    //add _DO_LOGIC,_SP_PLAN_SLIDE 20221005 cn
    public string SP_PLAN_SLIDE
    {
        get { return this._SP_PLAN_SLIDE; }
        set { this._SP_PLAN_SLIDE = value.ToUpper(); }

    }
    public string DO_LOGIC
    {
        get { return this._DO_LOGIC; }
        set { this._DO_LOGIC = value.ToUpper(); }

    }

    public string USER_ID
    {
        get { return this._USER_ID; }
        set { this._USER_ID = value.ToUpper(); }

    }
    public string FACTORY_CD
    {
        get { return this._FACTORY_CD; }
        set { this._FACTORY_CD = value.ToUpper(); }

    }
    public string PART_NO
    {
        get { return this._PART_NO; }
        set { this._PART_NO = value.ToUpper(); }

    }
    public string DIM
    {
        get { return this._DIM; }
        set { this._DIM = value.ToUpper(); }

    }
    public string BLOCK_CD
    {
        get { return this._BLOCK_CD; }
        set { this._BLOCK_CD = value.ToUpper(); }

    }
    public string SUPPLIER_CD
    {
        get { return this._SUPPLIER_CD; }
        set { this._SUPPLIER_CD = value.ToUpper(); }

    }
    public string TOTAL_PROCESS_LT
    {
        get { return this._TOTAL_PROCESS_LT; }
        set { this._TOTAL_PROCESS_LT = value.ToUpper(); }

    }

    private DOControl_Dataservice Service;
    public T_PRD_DO_PART_MASTER_DTO()
    {
        Service = new DOControl_Dataservice();
    }

    public DataSet DO_PART_MASTER_INQ()
    {

        DataSet data;
        data = Service.DO_PART_MASTER_INQ(this);
        return data; 
    }

    public int DO_PART_MASTER_INS()
    {
        int Flg;
        Flg = Service.DO_PART_MASTER_INS(this);
        return Flg;
    }
    public int DO_PART_MASTER_UPD()
    {
        int Flg;
        Flg = Service.DO_PART_MASTER_UPD(this);
        return Flg;
    }

    public int DO_PART_MASTER_PLAN_SP_UPD()
    {
        int Flg;
        Flg = Service.DO_PART_MASTER_PLAN_SP_UPD(this);
        return Flg;
    }

    public int DO_PART_MASTER_LOGIC_UPD()
    {
        int Flg;
        Flg = Service.DO_PART_MASTER_LOGIC_UPD(this);
        return Flg;
    }

    public int DO_PART_MASTER_DEL()
    {
        int Flg;
        Flg = Service.DO_PART_MASTER_DEL(this);
        return Flg;
    }
}