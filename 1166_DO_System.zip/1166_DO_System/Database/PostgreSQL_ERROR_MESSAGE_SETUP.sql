-- ============================================================================
-- PostgreSQL Error Message Table Setup
-- สร้างตาราง ERROR_MESSAGE สำหรับเก็บข้อความข้อผิดพลาด
-- ============================================================================

-- สร้าง Schema dosystem ถ้ายังไม่มี
CREATE SCHEMA IF NOT EXISTS dosystem;

-- สร้างตาราง ERROR_MESSAGE
CREATE TABLE IF NOT EXISTS dosystem.error_message (
    error_message VARCHAR(20) PRIMARY KEY,
    message_th VARCHAR(500) NOT NULL,
    message_en VARCHAR(500) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ลบข้อมูลเก่า (ถ้ามี)
TRUNCATE TABLE dosystem.error_message;

-- Insert ข้อมูล Error Messages
INSERT INTO dosystem.error_message (error_message, message_th, message_en) VALUES
-- Validation Errors
('WG0001', 'กรุณาระบุข้อมูลให้ครบถ้วน', 'Please enter all required information'),
('WF0001', 'รหัส Supplier ไม่ถูกต้อง', 'Invalid Supplier Code'),
('WF0002', 'ชื่อ Supplier ไม่ถูกต้อง', 'Invalid Supplier Name'),
('WF0003', 'วันที่ไม่ถูกต้อง', 'Invalid Date Format'),
('WF0004', 'รหัส Supplier มีความยาวเกิน 4 ตัวอักษร', 'Supplier Code length exceeds 4 characters'),
('WF0007', 'Part No ไม่ได้ระบุ', 'Part No is required'),
('WF0008', 'DIM ไม่ได้ระบุ', 'DIM is required'),
('WF0009', 'BLOCK_CD ไม่ได้ระบุ', 'BLOCK_CD is required'),
('WF0010', 'TOTAL_PROCESS_LT ไม่ได้ระบุ', 'TOTAL_PROCESS_LT is required'),
('WF0011', 'Part No มีความยาวเกิน 12 ตัวอักษร', 'Part No length exceeds 12 characters'),
('WF0012', 'DIM มีความยาวเกิน 3 ตัวอักษร', 'DIM length exceeds 3 characters'),
('WF0013', 'BLOCK_CD มีความยาวเกิน 4 ตัวอักษร', 'BLOCK_CD length exceeds 4 characters'),
('WF0014', 'TOTAL_PROCESS_LT มีความยาวเกิน 6 ตัวอักษร', 'TOTAL_PROCESS_LT length exceeds 6 characters'),
('WF0021', 'TOTAL_PROCESS_LT ต้องเป็นตัวเลขเท่านั้น', 'TOTAL_PROCESS_LT must be numeric'),
('WF0023', 'DO_LOGIC ไม่ตรงกับข้อมูลเดิม', 'DO_LOGIC does not match existing data'),
('WF0024', 'TOTAL_PROCESS_LT ไม่ตรงกับข้อมูลเดิม', 'TOTAL_PROCESS_LT does not match existing data'),

-- Success/Info Messages
('IG0004', 'บันทึกข้อมูลสำเร็จ', 'Data saved successfully'),
('IG0007', 'ลบข้อมูลสำเร็จ', 'Data deleted successfully'),
('IG0008', 'ค้นหาข้อมูลสำเร็จ', 'Data retrieved successfully'),
('IG0010', 'ไม่สามารถลบข้อมูลได้', 'Unable to delete data'),

-- Duplicate/Conflict Errors
('SG0001', 'ข้อมูลซ้ำกับข้อมูลที่มีอยู่แล้ว', 'Data already exists'),

-- Warning/Logic Errors
('WL0001', 'การบันทึกข้อมูลล้มเหลว', 'Failed to save data'),
('WL0002', 'การแก้ไขข้อมูลล้มเหลว', 'Failed to update data'),
('WL0128', 'ไม่พบข้อมูล', 'No data found'),

-- Confirmation Messages
('CG0003', 'คุณต้องการลบข้อมูลนี้หรือไม่?', 'Do you want to delete this record?'),
('CG0004', 'คุณต้องการแก้ไขข้อมูลนี้หรือไม่?', 'Do you want to update this record?'),

-- File Upload Messages
('WH0067', 'ข้อมูลซ้ำในไฟล์ CSV', 'Duplicate record in CSV file');

-- Verify data
SELECT COUNT(*) as total_error_messages FROM dosystem.error_message;

-- Display all error messages
SELECT error_message, message_th, message_en FROM dosystem.error_message ORDER BY error_message;
