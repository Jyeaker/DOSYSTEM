-- TABLE: dosystem.wbgjt002
-- สร้างจากข้อมูลที่ใช้ในโปรเจกต์ (CD_SPLY_FACT, CD_SPLY)
-- หากมีคอลัมน์เพิ่มเติมจาก Oracle เดิม สามารถ ALTER TABLE เพิ่มได้ภายหลัง

CREATE TABLE IF NOT EXISTS dosystem.wbgjt002 (
    cd_sply_fact    CHARACTER VARYING(2)   NOT NULL,
    cd_sply         CHARACTER VARYING(4)   NOT NULL,
    PRIMARY KEY (cd_sply_fact, cd_sply)
);

ALTER TABLE dosystem.wbgjt002 OWNER TO dosystem;
