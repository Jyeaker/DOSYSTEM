﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for T_PRD_DO_DELIVERY_MASTER_DTO
/// </summary> 
public class T_PRD_DO_DELIVERY_MASTER_DTO
{
    public string _FACTORY_CD;
    public string _SUPPLIER_CD;
    public string _VENDOR_FCTRY;
    public string _EFFECT_STA_DATE;
    public string _SUPPLIER_NAME;
    public string _TIME_ETA_1;
    public string _TIME_ETA_2;
    public string _TIME_ETA_3;
    public string _TIME_ETA_4;
    public string _TIME_ETA_5;
    public string _TIME_ETA_6;
    public string _TIME_ETA_7;
    public string _TIME_ETA_8;
    public string _TIME_ETA_9;
    public string _TIME_ETA_10;
    public string _TIME_ETA_11;
    public string _TIME_ETA_12;
    public string _TIME_ETA_13;
    public string _TIME_ETA_14;
    public string _TIME_ETA_15;
    public string _TIME_ETA_16;
    public string _TIME_ETA_17;
    public string _TIME_ETA_18;
    public string _TIME_ETA_19;
    public string _TIME_ETA_20;
    public string _TIME_ETA_21;
    public string _TIME_ETA_22;
    public string _TIME_ETA_23;
    public string _TIME_ETA_24;
    public string _USER_ID;
    public string _FLG_IN_HOUSE;

    public string FLG_IN_HOUSE
    {
        get { return this._FLG_IN_HOUSE; }
        set { this._FLG_IN_HOUSE = value.ToUpper(); }
    }

    public string FACTORY_CD
    {
        get { return this._FACTORY_CD; }
        set { this._FACTORY_CD = value.ToUpper(); }
    }
    public string SUPPLIER_CD
    {
        get { return this._SUPPLIER_CD; }
        set { this._SUPPLIER_CD = value.ToUpper(); }
    }

    public string VENDOR_FCTRY
    {
        get { return this._VENDOR_FCTRY; }
        set { this._VENDOR_FCTRY = value.ToUpper(); }
    }
    public string EFFECT_STA_DATE
    {
        get { return this._EFFECT_STA_DATE; }
        set { this._EFFECT_STA_DATE = value.ToUpper(); }
    }
    public string SUPPLIER_NAME
    {
        get { return this._SUPPLIER_NAME; }
        set { this._SUPPLIER_NAME = value.ToUpper(); }

    }
    public string TIME_ETA_1
    {
        get { return this._TIME_ETA_1; }
        set { this._TIME_ETA_1 = value.ToUpper(); }

    }
    public string TIME_ETA_2
    {
        get { return this._TIME_ETA_2; }
        set { this._TIME_ETA_2 = value.ToUpper(); }

    }
    public string TIME_ETA_3
    {
        get { return this._TIME_ETA_3; }
        set { this._TIME_ETA_3 = value.ToUpper(); }

    }
    public string TIME_ETA_4
    {
        get { return this._TIME_ETA_4; }
        set { this._TIME_ETA_4 = value.ToUpper(); }

    }
    public string TIME_ETA_5
    {
        get { return this._TIME_ETA_5; }
        set { this._TIME_ETA_5 = value.ToUpper(); }

    }
    public string TIME_ETA_6
    {
        get { return this._TIME_ETA_6; }
        set { this._TIME_ETA_6 = value.ToUpper(); }

    }
    public string TIME_ETA_7
    {
        get { return this._TIME_ETA_7; }
        set { this._TIME_ETA_7 = value.ToUpper(); }

    }
    public string TIME_ETA_8
    {
        get { return this._TIME_ETA_8; }
        set { this._TIME_ETA_8 = value.ToUpper(); }

    }
    public string TIME_ETA_9
    {
        get { return this._TIME_ETA_9; }
        set { this._TIME_ETA_9 = value.ToUpper(); }

    }
    public string TIME_ETA_10
    {
        get { return this._TIME_ETA_10; }
        set { this._TIME_ETA_10 = value.ToUpper(); }

    }
    public string TIME_ETA_11
    {
        get { return this._TIME_ETA_11; }
        set { this._TIME_ETA_11 = value.ToUpper(); }

    }
    public string TIME_ETA_12
    {
        get { return this._TIME_ETA_12; }
        set { this._TIME_ETA_12 = value.ToUpper(); }

    }
    public string TIME_ETA_13
    {
        get { return this._TIME_ETA_13; }
        set { this._TIME_ETA_13 = value.ToUpper(); }

    }
    public string TIME_ETA_14
    {
        get { return this._TIME_ETA_14; }
        set { this._TIME_ETA_14 = value.ToUpper(); }

    }
    public string TIME_ETA_15
    {
        get { return this._TIME_ETA_15; }
        set { this._TIME_ETA_15 = value.ToUpper(); }

    }
    public string TIME_ETA_16
    {
        get { return this._TIME_ETA_16; }
        set { this._TIME_ETA_16 = value.ToUpper(); }

    }
    public string TIME_ETA_17
    {
        get { return this._TIME_ETA_17; }
        set { this._TIME_ETA_17 = value.ToUpper(); }

    }
    public string TIME_ETA_18
    {
        get { return this._TIME_ETA_18; }
        set { this._TIME_ETA_18 = value.ToUpper(); }

    }
    public string TIME_ETA_19
    {
        get { return this._TIME_ETA_19; }
        set { this._TIME_ETA_19 = value.ToUpper(); }

    }
    public string TIME_ETA_20
    {
        get { return this._TIME_ETA_20; }
        set { this._TIME_ETA_20 = value.ToUpper(); }

    }
    public string TIME_ETA_21
    {
        get { return this._TIME_ETA_21; }
        set { this._TIME_ETA_21 = value.ToUpper(); }

    }
    public string TIME_ETA_22
    {
        get { return this._TIME_ETA_22; }
        set { this._TIME_ETA_22 = value.ToUpper(); }

    }
    public string TIME_ETA_23
    {
        get { return this._TIME_ETA_23; }
        set { this._TIME_ETA_23 = value.ToUpper(); }

    }
    public string TIME_ETA_24
    {
        get { return this._TIME_ETA_24; }
        set { this._TIME_ETA_24 = value.ToUpper(); }

    }
    public string USER_ID
    {
        get { return this._USER_ID; }
        set { this._USER_ID = value.ToUpper(); }

    }
    private DOControl_Dataservice Service;
    public T_PRD_DO_DELIVERY_MASTER_DTO()
    {
        Service = new DOControl_Dataservice();
    }

    public DataSet DO_DELIVERY_ROUND_MASTER_INQ()
    {
        DataSet data;
        data = Service.DO_DELIVERY_ROUND_MASTER_INQ(this);
        return data;
    }

    public int DO_DELIVERY_ROUND_MASTER_INS_UPD()
    {
        int Flg;
        Flg = Service.DO_DELIVERY_ROUND_MASTER_INS_UPD(this);
        return Flg;
    }
    public int DO_DELIVERY_ROUND_MASTER_DEL()
    {
        int Flg;
        Flg = Service.DO_DELIVERY_ROUND_MASTER_DEL(this);
        return Flg;
    }
    
}