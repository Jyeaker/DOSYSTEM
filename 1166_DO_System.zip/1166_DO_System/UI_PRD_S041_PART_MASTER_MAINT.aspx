﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UI_PRD_S041_PART_MASTER_MAINT.aspx.cs" Inherits="UI_PRD_S041_PART_MASTER_MAINT" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <!-- Reference for Freeze Gridview -->
    <link href="js/GridViewScroll/GridviewScroll.css" rel="stylesheet" />
    <link href="js/GridViewScroll/GridviewCustomStyle.css" rel="stylesheet" />
     <%--jQuery v1.9.0 and jQuery UI - v1.9.1--%>
    <script src="js/GridViewScroll/jquery.min.js"></script>
    <script src="js/GridViewScroll/jquery-ui.min.js"></script>    
    <script src="js/GridViewScroll/gridviewScroll.min.js"></script>
    

    <style type="text/css">
        /*Ex. Custom css on gidview*/
        .CustomHearderGrid > th {
            background-color: #99ccff !important;
            height:40px !important;
            line-height:15px !important;                     
        }
                
        .CustomItemGrid > td {
            
        }
        .auto-style1 {
            height: 80%;
            width: 100%;
        }
    </style>

    <script type="text/javascript">


     
        //Call Reference in this page only(gridviewScroll Require jQuery v1.9.0 and jQuery UI - v1.9.1)
        var $j = jQuery.noConflict();
        $j(document).ready(function () {
            //Fix header when rows more than 0 rows  
            if(document.getElementById("<%=gvShowData.ClientID %>"))
            {
                var grid = document.getElementById("<%=gvShowData.ClientID %>");
                if (grid.rows.length > 7) {
                    gridviewScroll();
                }
            }
            
        });

        function gridviewScroll() {
                $j('#<%=gvShowData.ClientID%>').gridviewScroll({
                width: screen.width - 60,
                height: 350,
                arrowsize: 30,
                varrowtopimg: "js/GridViewScroll/Images/arrowvt.png",
                varrowbottomimg: "/js/GridViewScroll/Images/arrowvb.png",
                harrowleftimg: "/js/GridViewScroll/Images/arrowhl.png",
                harrowrightimg: "/js/GridViewScroll/Images/arrowhr.png",
                headerrowcount: 1                 
                });            
        }

        function ConfirmDelete() {
            if (confirm("<%=CSUtilities.GetErrMsg( "CG0003" )%>"))
                    return true;
                else
                    return false;
        }
        function ConfirmUpdate() {
            if (confirm("<%=CSUtilities.GetErrMsg( "CG0004" )%>"))
                    return true;
                else
                    return false;
        }
                       

        function isNumberKey(evt, element) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
                return false;
            else {
                var len = $(element).val().length;
                var index = $(element).val().indexOf('.');
                if (index > 0 && charCode == 46) {
                    return false;
                }
                if (index > 0) {
                    var CharAfterdot = (len + 1) - index;
                    if (CharAfterdot > 3) {
                        return false;
                    }
                }

            }
            return true;
        }

        function clearInputValue() {
            $('#<%=txtParNoAdd.ClientID%>').val("");
            $('#<%=txtDIMAdd.ClientID%>').val("");
            $('#<%=txtUseBlockAdd.ClientID%>').val("");
            $('#<%=txtSupplierCDAdd.ClientID%>').val("");
            $('#<%=txtTotal_Process_LtAdd.ClientID%>').val("");

            $('#<%=DdlDogicAdd.ClientID%>').val("");

            $('#<%=lblErrMsg.ClientID%>').val("");
        }

        //add function showDailogSpPlanSlide 20221006 cn

        function showDailogSpPlanSlide() {
            clearInputValue();

            $('#<%=lblSPFac.ClientID%>').text($('#<%=hdnFactory.ClientID%>').val());
            $('#<%=lblSPFac.ClientID%>').show();  

            $('#<%=txtSP_Plan_Slide.ClientID%>').val($('#<%=hdnSP_PLAN_SLIDE.ClientID%>').val())
            $('#<%=txtSP_Plan_Slide.ClientID%>').show();  


            $('#dailogSP_Plan_Slide').dialog({
                buttons: [{
                    text: "Confirm",
                    click: function () {
                        var factory = $('#<%=lblSPFac.ClientID%>').text().toUpperCase();
                        var sp_plan_slide = $('#<%=txtSP_Plan_Slide.ClientID%>').val().toUpperCase();
                        var UserID = $('#<%=hdnUserId.ClientID%>').val().toUpperCase();

                        var strdata = '{pFac : "' + factory + '" , pUser : "' + UserID + '", pSP_Plan_Slide : "' + sp_plan_slide + '"}'
                       
                         $.ajax({
                            type: 'POST',
                            url: 'UI_PRD_S041_PART_MASTER_MAINT.aspx/Update_SP_Plan_Slide',
                            data: strdata,
                            contentType: 'application/json; charset=utf-8',
                            dataType: 'json',
                            success: function (response) {
                                var obj = JSON.parse(response.d);
                                var result = obj[0].RESULT.indexOf("IG0004");

                                if (result != -1) { 
                                    //CASE result OK
                                    $('#<%=lblErrMsg_SP.ClientID%>').text(obj[0].RESULT);
                                    $('#<%=txtSP_Plan_Slide.ClientID%>').val("");
                                  
                                }else {
                                    $('#<%=lblErrMsg_SP.ClientID%>').text(obj[0].RESULT);
                                  
                                }
                            },
                            error: function (xhr, status, error) {
                                $('#<%=lblErrMsg_SP.ClientID%>').text(xhr.responseText);
                                alert("ERROR : " + xhr.responseText)
                            }
                        });

                        
                      }

                },
                {
                    text: "EXIT",
                    click: function () {
                        $('#dailogSP_Plan_Slide').dialog('close');
                        document.getElementById("<%=btnSearch.ClientID%>").click();
                    }
                }],
                modal: true,
                height: 350,
                width: 750,
                title: "UPDATE SPECIAL PLAN SLIDE",
                open: function () {
                    $('#<%=txtParNoAdd.ClientID%>').focus();
                },
            });
            return false;
          
        }

        //add function showDailogLogic

        function showDailogLogic() {
            clearInputValue();

            $('#<%=lblLogicFac.ClientID%>').text($('#<%=hdnFactory.ClientID%>').val());
            $('#<%=lblLogicFac.ClientID%>').show();

            $('#<%=DdlLogicUpd.ClientID%>').val($('#<%=hdnLOGIC.ClientID%>').val())
            $('#<%=DdlLogicUpd.ClientID%>').show();

            $('#dailogLogic').dialog({
                buttons: [{
                    text: "Confirm",
                    click: function () {
                        var factory = $('#<%=lblLogicFac.ClientID%>').text().toUpperCase();
                        var logic = $('#<%=DdlLogicUpd.ClientID%>').val().toUpperCase();
                        var UserID = $('#<%=hdnUserId.ClientID%>').val().toUpperCase();

                        var strdata = '{pFac : "' + factory + '" , pUser : "' + UserID + '", pLogic : "' + logic + '"}'

                         $.ajax({
                            type: 'POST',
                            url: 'UI_PRD_S041_PART_MASTER_MAINT.aspx/Update_Logic',
                            data: strdata,
                            contentType: 'application/json; charset=utf-8',
                            dataType: 'json',
                            success: function (response) {
                                var obj = JSON.parse(response.d);
                                var result = obj[0].RESULT.indexOf("IG0004");

                                if (result != -1) {
                                    //CASE result OK
                                    $('#<%=lblErrMsg_Logic.ClientID%>').text(obj[0].RESULT);

                                }else {
                                    $('#<%=lblErrMsg_Logic.ClientID%>').text(obj[0].RESULT);

                                }
                            },
                            error: function (xhr, status, error) {
                                $('#<%=lblErrMsg_Logic.ClientID%>').text(xhr.responseText);
                                alert("ERROR : " + xhr.responseText)
                            }
                        });


                      }

                },
                {
                    text: "EXIT",
                    click: function () {
                        $('#dailogLogic').dialog('close');
                        document.getElementById("<%=btnSearch.ClientID%>").click();
                    }
                }],
                modal: true,
                height: 350,
                width: 750,
                title: "UPDATE DO LOGIC",
                open: function () {
                    $('#<%=DdlLogicUpd.ClientID%>').focus();
                },
            });
            return false;

        }

        function showDailogAdd() {

            clearInputValue();

            $('#<%=lblFac.ClientID%>').text($('#<%=hdnFactory.ClientID%>').val());
            $('#<%=lblFac.ClientID%>').show();            
       
            $('#dailogAddOrUpdate').dialog({
                buttons: [{
                    text: "ADD NEW",
                    click: function () {
                        var factory = $('#<%=lblFac.ClientID%>').text().toUpperCase();
                        var PartNo = $('#<%=txtParNoAdd.ClientID%>').val().toUpperCase();
                        var Dim = $('#<%=txtDIMAdd.ClientID%>').val().toUpperCase();
                        var UseBlock = $('#<%=txtUseBlockAdd.ClientID%>').val().toUpperCase();
                        var SupplierCD = $('#<%=txtSupplierCDAdd.ClientID%>').val().toUpperCase();
                        var Total_Process_Lt = $('#<%=txtTotal_Process_LtAdd.ClientID%>').val().toUpperCase();
                        //add do logic 20220510 cn
                        var Do_Logic = $('#<%=DdlDogicAdd.ClientID%>').val().toUpperCase();

                        var UserID = $('#<%=hdnUserId.ClientID%>').val().toUpperCase();
                        var strdata = '{pFac : "' + factory + '" , pPartNo : "' + PartNo + '" , pDim : "' + Dim + '" , pUseBlock : "' + UseBlock + '" , pSupplierCD : "' + SupplierCD + '" , pUser : "' + UserID + '", pTotal_Process_Lt : "' + Total_Process_Lt + '" ,pDoLogic : "'+Do_Logic+'"}'
                        
                        $.ajax({
                            type: 'POST',
                            url: 'UI_PRD_S041_PART_MASTER_MAINT.aspx/AddNew',
                            data: strdata,
                            contentType: 'application/json; charset=utf-8',
                            dataType: 'json',
                            success: function (response) {
                                var obj = JSON.parse(response.d);
                                var result = obj[0].RESULT.indexOf("IG0004");

                                if (result != -1) { 
                                    //CASE result OK
                                    $('#<%=lblErrMsg.ClientID%>').text(obj[0].RESULT);
                                    $('#<%=txtParNoAdd.ClientID%>').val("");
                                    $('#<%=txtDIMAdd.ClientID%>').val("");
                                    $('#<%=txtUseBlockAdd.ClientID%>').val("");
                                    $('#<%=txtSupplierCDAdd.ClientID%>').val("");
                                    $('#<%=txtTotal_Process_LtAdd.ClientID%>').val("");
                                    //add do logic 20220510 cn
                                    $('#<%=DdlDogicAdd.ClientID%>').val("");


                                }else {
                                    $('#<%=lblErrMsg.ClientID%>').text(obj[0].RESULT);
                                }
                            },
                            error: function (xhr, status, error) {
                                $('#<%=lblErrMsg.ClientID%>').text(xhr.responseText);
                            }
                        });
                    }
                 }, {
                    text: "EXIT",
                    click: function () {
                        $('#dailogAddOrUpdate').dialog('close');
                        document.getElementById("<%=btnSearch.ClientID%>").click();
                    }
                }],
                modal: true,
                height: 600,
                width: 750,
                title: "ADD NEW PART MASTER",
                open: function () {
                    $('#<%=txtParNoAdd.ClientID%>').focus();
                },
            });
            return false;
    }
        
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <div id="showData">
    <div class="container" style="text-align: center;">
        <table class="table table-hover" style="width: 100%; text-align: center; color: #006bff;">
            <tr>
                <td style="width: 6%; text-align: right; margin-right: 1em; vertical-align: middle;">PART NO :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtPartNo" Height="28px" runat="server" MaxLength="12" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>
                <td style="width: 5%; text-align: right; margin-right: 1em; vertical-align: middle;">DIM :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDIM" Height="28px" runat="server" MaxLength="3" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>
                <td style="width: 6%; text-align: right; margin-right: 1em; vertical-align: middle;">USE BLOCK :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtUseBlock" Height="28px" runat="server" MaxLength="4" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>  
                </tr>

                <tr>
                    <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">SUPPLIER CD :</td>
                    <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtSupplierCD" Height="28px" runat="server" MaxLength="4" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                    </td>  
                    <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">DO LOGIC :</td>
                    <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDogic" Height="28px" runat="server" MaxLength="4" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                    </td>  
                    
                </tr>  
                             

            <tr style="height: 70%;">
                <td style="text-align: left; margin-left: 1em; text-align: center;" colspan="8" class="auto-style1">
                    <asp:Button ID="btnSearch" runat="server" Text="SEARCH" CssClass="btn btn-primary" Width="12%" Style="display: inline-block;" OnClick="btnSearch_Click" />
                    <asp:Button ID="btnDownload" runat="server" Text="DOWNLOAD" CssClass="btn btn-info" Width="13%" Style="display: inline-block; margin-left: 1em" OnClick="btn_dow_csv_Click"/>
                    <asp:Button ID="btnAdd" runat="server" Text="ADD" class="btn btn-success" Width="12%" Style="display: inline-block; margin-left: 1em" UseSubmitBehavior="False" OnClientClick="return showDailogAdd();"/>
                    <asp:Button ID="btnClear" runat="server" Text="CLEAR" class="btn btn-warning" Width="12%" Style="display: inline-block; margin-left: 1em" OnClick="btnClear_Click" />
                    <asp:Button ID="btnSp" runat="server" Text="SPECIAL PLAN SLIDE" class="btn btn-warning" Width="15%" Style="border-color:black; background-color:black; display: inline-block; margin-left: 1em"  OnClientClick="return showDailogSpPlanSlide();" UseSubmitBehavior="False" />
                    <asp:Button ID="btnLogic" runat="server" Text="DO LOGIC" class="btn btn-warning" Width="12%" Style="border-color:#8B0000; background-color:#8B0000; display: inline-block; margin-left: 1em"  OnClientClick="return showDailogLogic();" UseSubmitBehavior="False" />
                    <asp:Button ID="btnExit" runat="server" Text="EXIT" CssClass="btn btn-danger" Width="13%" Style="display: inline-block; margin-left: 1em" OnClick="btnExit_Click"/>

                </td>
            </tr>
        </table>
    </div>
    <%-- START : Gridview  --%>
    <div class="container" style="height: 360px; width: 100%; text-align: center;  overflow-x: scroll; overflow-y:hidden;">            
            <asp:Panel ID="pnlShowData" runat="server" class="panel panel-default" Height="100%"  >
                <asp:GridView ID="gvShowData" runat="server" Width="100%" CssClass="table-bordered table-hover" Font-Size="Smaller" GridLines="None"
                    AutoGenerateColumns="false"
                    AllowPaging="true" PageSize="200" PagerSettings-Mode="NumericFirstLast"
                    PagerSettings-FirstPageText="First" PagerSettings-LastPageText="Last"
                    OnPageIndexChanging="gvShowData_PageIndexChanging"
                    OnRowDeleting="gvShowData_RowDeleting"                     
                    OnRowEditing="gvShow_RowEditing"
                    OnRowCancelingEdit="gvShow_RowCancelingEdit"  
                    OnRowUpdating="gvShow_RowUpdating"
                    OnRowDataBound="gvShowData_RowDataBound">
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <Columns>
                        <asp:TemplateField HeaderText="COMMAND" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED"  >
                            <ItemTemplate>
                                <asp:ImageButton ID="imgEdit" runat="server" CommandName="edit" AlternateText="UPDATE" ImageUrl="~/images/edit.png" Width="20" />
                                <asp:ImageButton ID="imgDel" runat="server" CommandName="delete" AlternateText="DELETE" ImageUrl="~/images/deleteX.png" Width="20" OnClientClick="return ConfirmDelete();" />            
                            </ItemTemplate>                            
                            <EditItemTemplate>
                                <asp:ImageButton ID="imgUpdate" runat="server" CommandName="update" AlternateText="UPDATE" ImageUrl="~/images/update1.png" Width="20" OnClientClick="return ConfirmUpdate();" />
                                <asp:ImageButton ID="imgCancel" runat="server" CommandName="cancel" AlternateText="CANCEL" ImageUrl="~/images/cancel1.png" Width="20" />
                            </EditItemTemplate>                            
                            <ItemStyle />
                        </asp:TemplateField>
                        <asp:BoundField HeaderText="PART_NO" DataField="PART_NO" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="DIM" DataField="DIM" ReadOnly="true" ItemStyle-HorizontalAlign="Center"  HeaderStyle-BackColor="#99ccff"/>
                        <asp:BoundField HeaderText="BLOCK_CD" DataField="BLOCK_CD" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff"/>
                        <asp:BoundField HeaderText="SUPPLIER_CD" DataField="SUPPLIER_CD"  ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff"  />
                        <asp:BoundField HeaderText="TOTAL_PROCESS_LT" DataField="TOTAL_PROCESS_LT" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="DO_LOGIC" DataField="LOGIC" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="SPECIAL_PLAN_SLIDE" DataField="SP_PLAN_SLIDE" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="CREATE_DATE" DataField="CREATE_DATE2" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="CREATE_BY" DataField="CREATE_BY"  ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="UPDATE_DATE" DataField="UPDATE_DATE2"  ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="UPDATE_BY" DataField="UPDATE_BY"  ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                    </Columns>
                    <HeaderStyle BackColor="#99ccff" HorizontalAlign="Center" ForeColor="Black"  VerticalAlign="Middle" CssClass="headerGrid CustomHearderGrid" Wrap="False"/>
                    <PagerSettings FirstPageText="First" LastPageText="Last" Mode="NumericFirstLast" />
                    <PagerStyle CssClass="pagination-ys" />
                    <RowStyle Height="40px" Font-Size="11px" HorizontalAlign="Center" VerticalAlign="Middle" CssClass="ItemGrid"  Wrap="False"/>
                </asp:GridView>                        
            </asp:Panel>
        </div>
        <%-- END : Gridview  --%>


         <%-- SP PLAN SLIDE DIALOG --%>
        <div id="dailogSP_Plan_Slide" hidden='hidden'>
            <div class="ui-front" style="width:100%;">
                <table  class="table" style="width:100%;margin:auto 0;">
                    <tr>
                        <td style="text-align: right; vertical-align:middle; width:30%; color: #006BFF;">FACTORY CD : </td>
                        <td style="text-align: left;  vertical-align:middle; width:90%;">
                        <asp:Label ID="lblSPFac" runat="server" ForeColor="Blue" Font-Size="Medium" Font-Bold="True"></asp:Label>
                    </td>
                    </tr>
                    <tr>
                        <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>SPECIAL PLAN SLIDE(Hr.) : </b></td>
                        <td colspan="5"style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtSP_Plan_Slide" runat="server" CssClass="form-control" style="display:inline-block; font-size:16px; text-transform: uppercase;" Width="70%" MaxLength="12" /> *
                    </td>
                    </tr>
                    <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; "><b>MESSAGE : </b></td>
                    <td  colspan="5" style="width:65%;text-align:left;vertical-align:middle;" >
                        <asp:Label ID="lblErrMsg_SP" runat="server" style="display:inline-block; color:red;"></asp:Label> 
                    </td>
                </tr>
                </table>
            </div>
        </div>
        <%-- DO LOGIC DIALOG --%>
        <div id="dailogLogic" hidden='hidden'>
            <div class="ui-front" style="width:100%;">
                <table  class="table" style="width:100%;margin:auto 0;">
                    <tr>
                        <td style="text-align: right; vertical-align:middle; width:30%; color: #006BFF;">FACTORY CD : </td>
                        <td style="text-align: left;  vertical-align:middle; width:90%;">
                        <asp:Label ID="lblLogicFac" runat="server" ForeColor="Blue" Font-Size="Medium" Font-Bold="True"></asp:Label>
                    </td>
                    </tr>
                    <tr>
                        <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>DO LOGIC : </b></td>
                        <td colspan="5"style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" >
                        <asp:DropDownList ID="DdlLogicUpd" runat="server" CssClass="form-control" style="display:inline-block; font-size:16px;" Width="70%">
                            <asp:ListItem Text="1" Value="1"></asp:ListItem>
                            <asp:ListItem Text="2" Value="2"></asp:ListItem>
                            <asp:ListItem Text="3" Value="3"></asp:ListItem>
                        </asp:DropDownList> *
                    </td>
                    </tr>
                    <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; "><b>MESSAGE : </b></td>
                    <td  colspan="5" style="width:65%;text-align:left;vertical-align:middle;" >
                        <asp:Label ID="lblErrMsg_Logic" runat="server" style="display:inline-block; color:red;"></asp:Label>
                    </td>
                </tr>
                </table>
            </div>
        </div>
        <%-- Add Dialog --%>
    <div id="dailogAddOrUpdate" hidden='hidden'>
        <div class="ui-front" style="width:100%;">
            <table  class="table" style="width:100%;margin:auto 0;">
                <tr>
                    <td style="text-align: right; vertical-align:middle; width:30%; color: #006BFF;">FACTORY CD : </td>
                    <td style="text-align: left;  vertical-align:middle; width:90%;">
                        <asp:Label ID="lblFac" runat="server" ForeColor="Blue" Font-Size="Medium" Font-Bold="True"></asp:Label>
                    </td>
                    
                </tr>
                 <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>PART NO : </b></td>
                    <td colspan="5"style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtParNoAdd" runat="server" CssClass="form-control" style="display:inline-block; font-size:16px; text-transform: uppercase;" Width="70%" MaxLength="12" /> *
                    </td>
                </tr>
                <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>DIM : </b></td>
                    <td  colspan="5" style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000;  font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtDIMAdd" runat="server" CssClass="form-control" style="display:inline-block; font-size:16px;text-transform: uppercase;" Width="70%" MaxLength="3"/> *
                    </td>
                </tr>
                <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>USE BLOCK : </b></td>
                    <td  colspan="5" style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtUseBlockAdd" runat="server" CssClass="form-control" style="display:inline-block;font-size:16px; text-transform: uppercase;" Width="70%" MaxLength="4"/> *
                    </td>
                </tr>
                 <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>SUPPLIER CD : </b></td>
                    <td  colspan="5" style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtSupplierCDAdd" runat="server" CssClass="form-control" style="display:inline-block;font-size:16px; text-transform: uppercase;" Width="70%" MaxLength="4"/> *
                    </td>
                </tr>

                <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>TOTAL PROCESS LEAD TIME : </b></td>
                    <td  colspan="5" style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <asp:TextBox id="txtTotal_Process_LtAdd" runat="server" CssClass="form-control" style="display:inline-block;font-size:16px; text-transform: uppercase; " Width="70%" MaxLength="6" onkeypress="return isNumberKey(event,this)"/> *
                    </td>
                </tr>

                <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; color: #006BFF;"><b>DO Logic : </b></td>
                    <td colspan="5"style="width:65%; text-align:left;margin-left:10px;vertical-align:middle; color: #FF0000; font-weight: bold; font-size: 25px;" > 
                        <%--add do logic 20220510 cn--%>
                        <asp:DropDownList ID="DdlDogicAdd" runat="server" CssClass="form-control" style="display:inline-block; font-size:16px; text-transform: uppercase;" Width="70%" >
                            <asp:ListItem  Text="1" Value="1"></asp:ListItem>
                            <asp:ListItem Text="2"  Value="2"></asp:ListItem>
                            <asp:ListItem  Text="3"  Value="3"></asp:ListItem>
                        </asp:DropDownList>
                    </td>
                </tr>

                <tr>
                    <td style="width:40%; text-align:right;vertical-align:middle; "><b>MESSAGE : </b></td>
                    <td  colspan="5" style="width:65%;text-align:left;vertical-align:middle;" >
                        <asp:Label ID="lblErrMsg" runat="server" style="display:inline-block; color:red;"></asp:Label> 
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <%-- End Add Dialog --%>

        <%-- START : upload  --%>
        <div class="container" style="position: relative; margin-top: 0.5em; border: dotted; background: #d6eaf8; border-color: #aed6f1;">

            <table class="table" style="width: 80%; margin: 0 auto;">
                <tr>
                    <td style="text-align: left; margin-right: 3em; font-family: Candara; vertical-align: middle; width: 30%;" class="auto-style1">
                        <font size="3px">  Please  select csv : For Upload Data </font></td>

                    <td style="text-align: left; margin-right: 10px; vertical-align: middle; width: 70%;">
                        <asp:FileUpload ID="fluUpload" runat="server" CssClass="form-control" Style="display: inline-block;" Width="50%" />
                        <asp:Button ID="btnUpload" runat="server" Text="Upload CSV" CssClass="btn btn-success" Style="display: inline-block; margin-left: 10px" Width="20%" OnClick="btnUpload_Click" />
                        <asp:Button ID="btnDetialformat" runat="server" Text="Upload Format" CssClass="btn btn-primary" Style="display: inline-block; margin-left: 10px" Width="20%" OnClick="btnDetialformat_Click" />
                    </td>
                </tr>
            </table>
        </div>

        <%-- END : upload  --%>
    </div>
    <asp:HiddenField ID="hdnUserId" runat="server"/>
    <asp:HiddenField ID="hdnFactory" runat="server"/>
    <asp:HiddenField ID="hdnSP_PLAN_SLIDE" runat="server"/>
    <asp:HiddenField ID="hdnLOGIC" runat="server"/>
        
    
</asp:Content>


