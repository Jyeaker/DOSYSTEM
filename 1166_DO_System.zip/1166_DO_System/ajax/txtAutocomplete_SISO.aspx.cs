﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

public partial class Ajax_txtAutocomplete : System.Web.UI.Page
{
    string param;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            int count;

            param = Request["param"].ToString();
            DataTable dt = getDataTable();
            count = dt.Rows.Count;

            string keyword = Request["keyword"].ToString();
            string fields = Request["fields"].ToString();
            string objName = Request["objName"].ToString();

            DataView dv = new DataView(dt);

            

            if (keyword != null)
            {
                //add by chayanon 20201004
                if (fields == "DO_LOGIC")
                {
                    dv.RowFilter = string.Format("CONVERT({0}, System.String) LIKE '%{1}%'", fields, keyword);
                }
                else
                {
                    dv.RowFilter = string.Format("{0} LIKE '%{1}%'", fields, keyword);
                }
            }

            string bgColor = "#FFE4C4";

            StringBuilder sb = new StringBuilder();
            sb.Append("<table class='rolloverShowRecord' border='0' bgcolor='#eeeeee'width='250' cellpadding='5' cellspacing='0' >");
            sb.Append("<tr class='rolloverShowRecord'>");
            sb.Append("<td>");
            sb.AppendFormat("<b><font color='#9090dd' size='2'>Total: <font color='#000000'> {0} records </font></b> ",dv.Count);
            sb.Append("</td>");
            sb.Append("</tr>");

            if (dv.Count > 0)
            {
                if (dv.Count < 10)
                {
                    for (int i = 0; i <= dv.Count - 1; i++)
                    {

                        bgColor = (bgColor == "#FFE4C4") ? "#F5DEB3" : "#FFE4C4";

                        string strColumnValue = null;
                        try
                        {
                            if (dv[i][1].ToString() != null)
                            {
                                strColumnValue = dv[i][0].ToString() + ":" + dv[i][1].ToString();
                            }
                        }
                        catch
                        {
                            strColumnValue = dv[i][0].ToString();
                        }

                        string strShow = "\"" + strColumnValue + "\"";

                        sb.Append("<tr>");
                        sb.AppendFormat("<td cellpadding='5' class='rolloverBlue'  onmouseover='recName({0});' style='cursor:hand'  onclick='destroy_autocomplete();'>", strShow);
                        sb.AppendFormat("<a class='rolloverBlue' href='#' onclick='destroy_autocomplete();' style='text-decoration:none;color:blue;font-size:9pt;'>&nbsp; {0} </a>", strColumnValue);
                        sb.Append("</td>");
                        sb.Append("</tr>");
                    }
                }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {

                        bgColor = (bgColor == "#FFE4C4") ? "#F5DEB3" : "#FFE4C4";

                        string strColumnValue = null;
                        try
                        {
                            if (dv[i][1].ToString() != null)
                            {
                                strColumnValue = dv[i][0].ToString() + ":" + dv[i][1].ToString();
                            }
                        }
                        catch
                        {
                            strColumnValue = dv[i][0].ToString();
                        }

                        string strShow = "\"" + strColumnValue + "\"";

                        sb.Append("<tr>");
                        sb.AppendFormat("<td cellpadding='5' class='rolloverBlue'  onmouseover='recName({0});' style='cursor:hand'  onclick='destroy_autocomplete();'>", strShow);
                        sb.AppendFormat("<a class='rolloverBlue' href='#' onclick='destroy_autocomplete();' style='text-decoration:none;color:blue;font-size:9pt;'>&nbsp; {0} </a>", strColumnValue);
                        sb.Append("</td>");
                        sb.Append("</tr>");
                    }
                }
            } 
            else 
            {
                sb.Append("<tr>");
                sb.Append("<td align='center' bgcolor='#ffffff'  >");
                sb.Append("</td>");
                sb.Append("</tr>");
            }

            Response.Write(sb.ToString());
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected DataTable getDataTable() {
        ExcuteModeServices obExSV = new ExcuteModeServices();
        DataTable dt = new DataTable();
        StringBuilder sb = new StringBuilder();
        string fields = Request["fields"].ToString();
        string[] condition = param.Split(',');
        string Sql = null;
        try
        {
            switch (fields)
            {                 
                /*case "SUPPLIER_CD":
                    Sql = "SELECT DISTINCT SUPPLIER_CD FROM  T_PRD_DO_DELIVERY_MASTER ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "SUPPLIER_CD").Tables[0];
                    break;*/

                case "SUPPLIER_CD":
                    Sql = "SELECT DISTINCT SUPPLIER_CD FROM  T_PRD_DO_DELIVERY_MASTER WHERE FACTORY_CD = '{0}'";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "MERCHANDISE_MASTER").Tables[0];
                    break;

                case "SUPPLIER_CD_2":
                    Sql = "SELECT DISTINCT SUPPLIER_CD AS SUPPLIER_CD_2 FROM  T_PRD_DO_PART_MASTER WHERE FACTORY_CD = '{0}' GROUP BY SUPPLIER_CD ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "SUPPLIER_CD_2").Tables[0];
                    break;

                case "PART_NO":
                    Sql = "SELECT DISTINCT PART_NO FROM  T_PRD_DO_PART_MASTER WHERE FACTORY_CD = '{0}' GROUP BY PART_NO ORDER BY PART_NO ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "PART_NO").Tables[0];
                    break;

                case "BLOCK_CD":
                    Sql = "SELECT DISTINCT BLOCK_CD FROM  T_PRD_DO_PART_MASTER WHERE FACTORY_CD = '{0}' GROUP BY BLOCK_CD ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "BLOCK_CD").Tables[0];
                    break;

                case "BLOCK_CD_DO":
                    Sql = "SELECT DISTINCT BLOCK_CD AS BLOCK_CD_DO FROM  T_PRD_DO_RESULT WHERE FACTORY_CD = '{0}' GROUP BY BLOCK_CD ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "BLOCK_CD_DO").Tables[0];
                    break;

                case "RESULT_DO":
                    Sql = "SELECT DISTINCT SUBSTR(RESULT,0,6) as RESULT_DO FROM  T_PRD_DO_RESULT WHERE FACTORY_CD = '{0}' ORDER BY RESULT_DO ";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "RESULT_DO").Tables[0];
                    break;
//add by Amolakarn 20221020
                case "DOLOGIC":
                    
                    Sql = "SELECT DISTINCT SUBSTR(LOGIC, 0, 6) as DOLOGIC FROM T_PRD_DO_RESULT WHERE FACTORY_CD = '{0}' ORDER BY DOLOGIC ASC";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "DOLOGIC").Tables[0];
                    break;    

                // add by chayanon 20221004
                case "DO_LOGIC":
                    Sql = "SELECT DISTINCT LOGIC as DO_LOGIC FROM  T_PRD_DO_PART_MASTER WHERE FACTORY_CD = '{0}' ORDER BY LOGIC ASC";
                    sb.Remove(0, sb.Length);
                    sb.AppendFormat(Sql, condition[0]);
                    dt = obExSV.ExecuteQuery(sb.ToString(), "DO_LOGIC").Tables[0];
                    break;


            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
        }
        return dt;
    }
}