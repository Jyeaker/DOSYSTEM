﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UI_PRD_S041_DO_Main_Menu.aspx.cs" Inherits="UI_PRD_S041_DO_Main_Menu" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
          <!-- Reference for Freeze Gridview -->
    <link href="js/GridViewScroll/GridviewScroll.css" rel="stylesheet" />
    <link href="js/GridViewScroll/GridviewCustomStyle.css" rel="stylesheet" />
     <%--jQuery v1.9.0 and jQuery UI - v1.9.1--%>
    <script src="js/GridViewScroll/jquery.min.js"></script>
    <script src="js/GridViewScroll/jquery-ui.min.js"></script>    
    <script src="js/GridViewScroll/gridviewScroll.min.js"></script>

    <style>
        body {
           /* background-color:darkcyan;*/
          /*  background-image: url(images/Pic01.jpg);*/
        }


    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
   
    <div class="container" style="text-align: center;">
         <center><b><h1 style ="font-size:50px; font-weight:bold">DO SYSTEM</h1></b></center>
         <br />
           <center><b><h4>Please select factory </h4></b></center>
         <br />
        <center>
        <table  style="width:60%; text-align: center; color: #000000;">
            <tr>
                <td>
                    <asp:Button ID="btnRA" runat="server" Text="CHT-RA" class="btn btn-warning" Width="30%" Style="font-size: 20px; height: 50px; display: inline-block;" OnClick="btnRA_Click" />
                </td>
                <td>
                    <asp:Button ID="btnHT" runat="server" Text="CHT-HT" class="btn btn-warning" Width="30%" Style="font-size: 20px; height: 50px; display: inline-block;" OnClick="btnHT_Click" />
                </td>
            </tr>
        </table>
        </center>
         <br />
         <br />
        <center>
            <img src="images/Do03.jpg" width="500" height="320" />
        </center>
        
    </div>
         

</asp:Content>

