var xmlhttp = null;
var _objName = null;
var _SSM_PortCode = null;
var _SSM_Carrier = null;

function createxmlhttp() {
    if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
}

function recName(str) {
    try {
        var strarr = str.split(":");
        document.getElementById(_objName).value = strarr[0];

        try {
            _SSM_PortCode = strarr[1];
            _SSM_Carrier = strarr[2];
        } catch (ee) {

        }

        //alert(str);   
    } catch (e) {
        //alert(e.message );
    }
}

function alertKeyword() {
    alert("GLB016");
}

function ClearText() {
    try {
        document.getElementById(_objName).value = "";
    } catch (e) {
        //alert(e.message );
    }
}

function destroy_autocomplete(obj) {
    try {
        document.getElementsByTagName("BODY")[0].removeChild(document.getElementById("prompt"));
    } catch (ee) { }
    try {
        objDivFrame = document.getElementById(FindObjectName("divframe")).id;
        document.getElementById(objDivFrame).style.visibility = "hidden";
    } catch (eee) { }

    if (obj != null && obj.callBackMethod != null) {
        var callback = obj.callBackMethod + "()";
        eval(callback);
    }
}

function chkSpecialChar() {
    if (window.event.keyCode == '37' || window.event.keyCode == '42' || window.event.keyCode == '43' || window.event.keyCode == '47' || window.event.keyCode == '39' || window.event.keyCode == '32') {
        return false;
    }
}

function run_autocomplete_SISO(obj, fieldsName, param) {
    destroy_autocomplete(obj);
    try {
        _objName = obj.id;
        createxmlhttp();

        var keyword = document.getElementById(_objName).value;
        var fields = fieldsName;
        xmlhttp.onreadystatechange = handlechange;

        xmlhttp.open("POST", "ajax/txtAutocomplete_SISO.aspx", true)
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis620"); // set Header
        xmlhttp.send("objName=" + escape(_objName) + "&keyword=" + (keyword) + "&fields=" + (fields) + "&param=" + (param));

    } catch (e) {
    }
}

function handlechange() {
    if (xmlhttp.readyState == 4) {
        if (xmlhttp.status == 200) {

            try {
                strHTML = xmlhttp.responseText;
                if(strHTML.indexOf("Total: <font color='#000000'> 0 records") != -1) {

                    recName(''); 

                    if (document.getElementById(_objName) != null) {
                        document.getElementById(_objName).focus();
                    }
                }

                var posTop = (document.getElementById(_objName).offsetTop) + 20 + "px";
                var posLeft = (document.getElementById(_objName).offsetLeft) + "px";

                promptbox = document.createElement('div');
                promptbox.setAttribute('id', 'prompt');
                promptbox.style.position = "absolute";
                promptbox.style.top = posTop;
                promptbox.style.left = posLeft;
                document.getElementsByTagName("BODY")[0].appendChild(promptbox);
                document.getElementById('prompt').innerHTML = strHTML;
            }
            catch (e) {
            }
        }
    }
}



//Create by Anchalee 20150711 PlanA3 for model master  
function run_autocomplete_Plan_A3_inputOther(obj, fieldsName, param) {
    try {
        _objName = obj.id;
        createxmlhttp();

        var keyword = document.getElementById(_objName).value;
        var fields = fieldsName;
        xmlhttp.onreadystatechange = handlechange_inputOther;

        xmlhttp.open("POST", "ajax/txtAutocomplete_Plan_A3.aspx", true)
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis620"); // set Header
        xmlhttp.send("objName=" + escape(_objName) + "&keyword=" + (keyword) + "&fields=" + (fields) + "&param=" + (param));

    } catch (e) { }
}

function handlechange_inputOther() {
    if (xmlhttp.readyState == 4) {
        if (xmlhttp.status == 200) {

            try {
                strHTML = xmlhttp.responseText;

                var posTop = (document.getElementById(_objName).offsetTop);
                var posLeft = (document.getElementById(_objName).offsetLeft);

                promptbox = document.createElement('div');
                promptbox.setAttribute('id', 'prompt');
                promptbox.style.position = "absolute";
                promptbox.style.top = (posTop + 20) + "px";
                promptbox.style.left = posLeft + "px";
                document.getElementsByTagName("BODY")[0].appendChild(promptbox);
                document.getElementById('prompt').innerHTML = strHTML;

            }
            catch (e) {
            }
        }
    }
}



