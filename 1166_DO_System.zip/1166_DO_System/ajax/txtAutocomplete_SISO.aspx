﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="txtAutocomplete_SISO.aspx.cs" Inherits="Ajax_txtAutocomplete" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
	
	<style type="text/css">
        /*Blue Theme */
		.rolloverBlue {
			margin: 0px;
			padding: 0px;
			color: #447e9a;
			background-color: #eef8fb !important;
		}

		.rolloverBlue a {
			display: block;
			width: 100%;
			height: 100%;
			color: #447e9a;
			text-decoration: none;
			background-color: #eef8fb !important;
		}

		.rolloverBlue a:hover {
			padding: 0px 0px;
			color: #d9534f;
			background-color: #f9f9f9 !important;
			font-weight: bold;
			border-color: silver;
			border-style: solid;
			border-width: 0.25px;
		}

		.rolloverShowRecord{
			margin-top:10px !important;
			background-color:white !important;
		}
    </style>
	
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>
