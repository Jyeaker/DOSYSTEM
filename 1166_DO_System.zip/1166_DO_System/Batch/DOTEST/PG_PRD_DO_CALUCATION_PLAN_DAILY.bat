REM #**********************************************************************
REM #    Project name   :   calculation DO - Plan
REM #    START DATE     :   20220218 By Alisa
REM #    MIGRATE TO PG  :   PostgreSQL
REM #**********************************************************************

SET LOGPATH=d:\Log\DO\PG_PRD_DO_CALUCATION_DAILY_PLAN.log

echo %date%  %time%   * ----- JOB START ----- *   > %LOGPATH%
echo %date%  %time%   * ----- START CALCULATION MAKE PLAN FOR DO ----- *   >> %LOGPATH%

D:\PostgreSQL\17\bin\psql.exe -U dosystem -h chtsv0004 -p 5432 -d prod -c "SET statement_timeout = 0; SET work_mem = '512MB'; select dosystem.P_PRD_DO_CALUCATION_DAILY_PLAN();" >> %LOGPATH% 2>&1

echo %date%  %time%   * ----- JOB COMPLETE ----- *   >> %LOGPATH%
pause
EXIT
