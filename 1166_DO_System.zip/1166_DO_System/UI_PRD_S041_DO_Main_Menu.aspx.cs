﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.IO;
using System.Configuration;


public partial class UI_PRD_S041_DO_Main_Menu : System.Web.UI.Page
{
    string dept_cd;
    string USERNAME;
    string Role_Id;
    ExcuteModeServices obEx = new ExcuteModeServices();
    DataTable dt_Query = new DataTable();
    StringBuilder sb = new StringBuilder();

    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        Label lblVersion = (Label)Page.Master.FindControl("lblVersion");

        lblVersion.Text = "22 - V1.20220125";
        lblFormName.Text = "DELIVERY ORDER SYSTEM";


        //USERNAME = Session["username"].ToString();

        USERNAME = Request.QueryString["USERNAME"];
		Session["USER_ID"] = USERNAME;
        //USERNAME = "C025170";


    }
    protected void btnRA_Click(object sender, EventArgs e)
    {
		Session["factory"] = "RA";
        Response.Redirect("UI_PRD_S041_DO_Main_Menu1.aspx?&FACTORY_CD="+"RA"+ "&USERNAME=" + USERNAME);
    }

    protected void btnHT_Click(object sender, EventArgs e)
    {
		Session["factory"] = "HT";
        Response.Redirect("UI_PRD_S041_DO_Main_Menu1.aspx?&FACTORY_CD=" + "HT"+ "&USERNAME=" + USERNAME);
    }


}