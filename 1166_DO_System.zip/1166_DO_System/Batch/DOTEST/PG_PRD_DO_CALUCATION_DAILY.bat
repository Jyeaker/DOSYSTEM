REM #**********************************************************************
REM #    Project name   :   calculation DO 
REM #    START DATE     :   20220218 By Alisa
REM #**********************************************************************

SET LOGPATH=d:\Log\DO\PG_PRD_DO_CALUCATION_DAILY.log

echo %date%  %time%   * ----- JOB START ----- *   > %LOGPATH%
echo %date%  %time%   * ----- START CALCULATION DO ----- *   >> %LOGPATH%

REM c:\app\client\Administrator\product\21.0.0\client_1\bin\sqlPLUS dosystem/dosystem@prodtest @D:\ICS\Batch\DOTEST\PG_PRD_DO_CALUCATION_DAILY.sql

D:\PostgreSQL\17\bin\psql.exe -U dosystem -h chtsv0004 -p 5432 -d prod -c "SET statement_timeout = 0; SET work_mem = '512MB';  select dosystem.P_PRD_DO_CALUCATION_DAILY_ALL_PROCESS();" >> %LOGPATH% 2>&1
pause
EXIT