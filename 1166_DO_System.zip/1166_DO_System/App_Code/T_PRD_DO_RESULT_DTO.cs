﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for T_PRD_DO_RESULT_DTO
/// </summary>
public class T_PRD_DO_RESULT_DTO
{
    public string _FACTORY_CD;
    public string _DELIVERY_KEY;
    public string _DELIVERY_DATEFROM;
    public string _DELIVERY_DATETO;
    public string _BLOCK_CD;
    public string _DELIVERY_LOCATION;
    public string _RESULT;
    public string _DOLOGIC;
	public string _CALCULATION_DATE;

    public string FACTORY_CD
    {
        get { return this._FACTORY_CD; }
        set { this._FACTORY_CD = value.ToUpper(); }

    }
    public string DELIVERY_KEY
    {
        get { return this._DELIVERY_KEY; }
        set { this._DELIVERY_KEY = value.ToUpper(); }

    }
    public string DELIVERY_DATEFROM
    {
        get { return this._DELIVERY_DATEFROM; }
        set { this._DELIVERY_DATEFROM = value.ToUpper(); }

    }
    public string DELIVERY_DATETO
    {
        get { return this._DELIVERY_DATETO; }
        set { this._DELIVERY_DATETO = value.ToUpper(); }

    }
    public string BLOCK_CD
    {
        get { return this._BLOCK_CD; }
        set { this._BLOCK_CD = value.ToUpper(); }

    }
    public string DELIVERY_LOCATION
    {
        get { return this._DELIVERY_LOCATION; }
        set { this._DELIVERY_LOCATION = value.ToUpper(); }

    }
    public string RESULT
    {
        get { return this._RESULT; }
        set { this._RESULT = value.ToUpper(); }

    }

    public string DOLOGIC
    {
        get { return this._DOLOGIC; }
        set { this._DOLOGIC = value.ToUpper(); }

    }
	
	public string CALCULATION_DATE
    {
        get { return this._CALCULATION_DATE; }
        set { this._CALCULATION_DATE = value.ToUpper(); }

    }

    private DOControl_Dataservice Service;
    public T_PRD_DO_RESULT_DTO()
    {
        Service = new DOControl_Dataservice();
    }
    public DataSet DO_INQUIRY_INQ()
    {

        DataSet data;
        data = Service.DO_INQUIRY_INQ(this);
        return data;
    }

    public DataSet DO_INQUIRY_INQ_EXPORT()
    {

        DataSet data;
        data = Service.DO_INQUIRY_INQ_EXPORT(this);
        return data;
    }
}