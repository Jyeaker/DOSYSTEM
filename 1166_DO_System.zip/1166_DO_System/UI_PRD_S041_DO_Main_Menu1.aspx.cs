﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.IO;
using System.Configuration;
public partial class UI_PRD_S041_DO_Main_Menu1 : System.Web.UI.Page
{
    string FACTORY_CD;
    string USERNAME;
    string Role_Id;
    ExcuteModeServices obEx = new ExcuteModeServices();
    DataTable dt_Query = new DataTable();
    StringBuilder sb = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        Label lblVersion = (Label)Page.Master.FindControl("lblVersion");

        USERNAME = Request.QueryString["USERNAME"];
        FACTORY_CD = Request.QueryString["FACTORY_CD"];

        lblVersion.Text = "22 - V1.20220125";
        lblFormName.Text = "DELIVERY ORDER SYSTEM-" + FACTORY_CD;


    }

    protected void btnPART_MASTER(object sender, EventArgs e)
    {

        Response.Redirect("UI_PRD_S041_PART_MASTER_MAINT.aspx?&FACTORY_CD="+ FACTORY_CD + "&USERNAME=" + USERNAME);
    }

    protected void btnDELIVERY_ROUND(object sender, EventArgs e)
    {

        Response.Redirect("UI_PRD_S041_DELIVERY_ROUND_MASTER_MAINT.aspx?&FACTORY_CD=" + FACTORY_CD + "&USERNAME=" + USERNAME);
    }
    protected void btnDO_INQUIRY(object sender, EventArgs e)
    {

        Response.Redirect("UI_PRD_S041_DO_INQUIRY.aspx?&FACTORY_CD=" + FACTORY_CD + "&USERNAME=" + USERNAME);
    }
}