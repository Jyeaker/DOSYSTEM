﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;
using System.Text;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Configuration;

[ScriptService]
public class JSWebService : System.Web.Services.WebService {

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void getAutocompleteData(string fieldname, string param1)
    {
        ExcuteModeServices exObj = new ExcuteModeServices();
        StringBuilder sb = new StringBuilder();
        DataTable dt = new DataTable();
        string Sql;
        string[] condition = param1.Split(',');

        switch (fieldname)
        {
			case "SUPPLIER_CD":
                sb.Remove(0, sb.Length);
                sb.AppendFormat("SELECT DISTINCT SUPPLIER_CD AS TARGET_DATA FROM  T_PRD_DO_DELIVERY_MASTER ORDER BY SUPPLIER_CD");
                break;
                
        }

       

        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        Context.Response.Write(JSSerializer.Serialize(rows));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void getDropdownListData(string fieldname, string param1, string param2, string param3, string param4)
    {
        ExcuteModeServices exObj = new ExcuteModeServices();
        StringBuilder sb = new StringBuilder();
        DataTable dt = new DataTable();

        switch (fieldname) {
            
        }

        dt = exObj.ExecuteQuery(sb.ToString(), "T_DATA_TABLE").Tables[0];

        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        Context.Response.Write(JSSerializer.Serialize(rows));
    }

    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public void getDataFromDatabase(string tablename, string fieldname,string condition)
    {
        ExcuteModeServices exObj = new ExcuteModeServices();
        StringBuilder sb = new StringBuilder();
        DataTable dt = new DataTable();

        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT {0} FROM {1} WHERE {2} ", fieldname, tablename, condition);

        dt = exObj.ExecuteQuery(sb.ToString(), "T_DATA_TABLE").Tables[0];

        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        foreach (DataRow dr in dt.Rows)
        {
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        Context.Response.Write(JSSerializer.Serialize(rows));
    }
	
	
	
}
