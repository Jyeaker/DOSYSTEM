﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Text;
using System.IO;
using System.Net;
using System.Globalization;

public partial class UI_PRD_S041_DELIVERY_ROUND_MASTER_MAINT : System.Web.UI.Page
{
    public string factory { get; set; }
    public string username { get; set; }
    T_PRD_DO_DELIVERY_MASTER_DTO objDTO = new T_PRD_DO_DELIVERY_MASTER_DTO();
    ExcuteModeServices obEx = new ExcuteModeServices();
    DataTable dt_Query = new DataTable();
    StringBuilder sb = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        Label lblVersion = (Label)Page.Master.FindControl("lblVersion");
        lblVersion.Text = "23 - V2.20230503";
        username = Request.QueryString["username"];
        factory = Request.QueryString["FACTORY_CD"];


        lblFormName.Text = "DELIVERY ROUND MASTER MAINTENANCE  - " + factory;

        string key = factory;
        txtSupplierCD.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'SUPPLIER_CD','" + key + "');");
        txtSupplierCD.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'SUPPLIER_CD','" + key + "');");
        txtSupplierCD.Attributes.Add("onblur", "destroy_autocomplete();");

        if (Session["UserName"] != null)
        {
            username = Session["UserName"].ToString().ToUpper();
        }

    }

    #region "BindData"
    protected void BindData()
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataSet ds = new DataSet();

        try
        {
            int count_row = 0;
            this.objDTO.FACTORY_CD = factory;
            this.objDTO.SUPPLIER_CD = txtSupplierCD.Text.ToUpper();
            this.objDTO.SUPPLIER_NAME = txtSupplierName.Text.ToUpper();
            this.objDTO.EFFECT_STA_DATE = txtEffectStartDate.Text.ToUpper();
            ds = objDTO.DO_DELIVERY_ROUND_MASTER_INQ();
            if (ds.Tables.Count > 0)
            {
                dt_Query = ds.Tables[0];
                count_row = dt_Query.Rows.Count;
                lblErrorMsg.Text = CSUtilities.GetErrMsg("IG0008") + " [Total :" + dt_Query.Rows.Count + " rec.]";

                this.gvShowData.DataSource = dt_Query;
                this.gvShowData.DataBind();
            }
            else
            {

                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0128"));
                gvShowData.DataSource = null;
                gvShowData.DataBind();
            }

        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();
        }
    }
    #endregion

    #region "SEARCH"
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BindData();
    }
    #endregion

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";

        txtSupplierCD.Text = "";
        txtSupplierName.Text = "";
        txtEffectStartDate.Text = "";
        gvShowData.DataSource = null;
        gvShowData.DataBind();
    }

    protected void btn_dow_csv_Click(object sender, EventArgs e)
    {
        try
        {
            BindData();
            DataTable DT_CSV = new DataTable();
            DT_CSV = dt_Query;
            DT_CSV.Columns.Remove("CREATE_DATE");
            DT_CSV.Columns.Remove("UPDATE_DATE");

            CsvManagement CsvManagement = new CsvManagement();
            CsvManagement.exportDataToCsv_TH(DT_CSV, "DELIVERY ROUND MASTER MAINTENANCE");
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "MessageError", "$('#ds_MessageError').show();", true);
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        lblFormName_sub.Text = "ADD : DELIVERY ROUND";
        btnAdd_add.Text = "ADD NEW";
        lblfactory_add.Text = factory;
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);

    }

    protected void btnCancel_add_Click(object sender, EventArgs e)
    {
        txtSupplier_Cd_add.ReadOnly = false;
        txtVENDOR_FCTRY_add.ReadOnly = false;
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').hide();$('#showData').show();", true);
        ClearColorScreen2();
        ClearTextScreen2();
        BindData();
    }

    protected void btnAdd_add_Click(object sender, EventArgs e)
    {
        ClearColorScreen2();
        int vCnt = 0;
        Label lblErrMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrMsg.Text = "";

        string vFactory = factory;
        string vSupplier_Cd = this.txtSupplier_Cd_add.Text.ToUpper();
        string vVENDOR_FCTRY = this.txtVENDOR_FCTRY_add.Text.ToUpper();
        string vEffect_Sta_Date = this.txtEffect_Sta_Date_add.Text.ToUpper();
        string vSupplier_Name = this.txtSupplier_Name_add.Text.ToUpper();
        string vTime_Eta_1 = this.txtTime_Eta_1_add.Text;
        string vTime_Eta_2 = this.txtTime_Eta_2_add.Text;
        string vTime_Eta_3 = this.txtTime_Eta_3_add.Text;
        string vTime_Eta_4 = this.txtTime_Eta_4_add.Text;
        string vTime_Eta_5 = this.txtTime_Eta_5_add.Text;
        string vTime_Eta_6 = this.txtTime_Eta_6_add.Text;
        string vTime_Eta_7 = this.txtTime_Eta_7_add.Text;
        string vTime_Eta_8 = this.txtTime_Eta_8_add.Text;
        string vTime_Eta_9 = this.txtTime_Eta_9_add.Text;
        string vTime_Eta_10 = this.txtTime_Eta_10_add.Text;
        string vTime_Eta_11 = this.txtTime_Eta_11_add.Text;
        string vTime_Eta_12 = this.txtTime_Eta_12_add.Text;
        string vTime_Eta_13 = this.txtTime_Eta_13_add.Text;
        string vTime_Eta_14 = this.txtTime_Eta_14_add.Text;
        string vTime_Eta_15 = this.txtTime_Eta_15_add.Text;
        string vTime_Eta_16 = this.txtTime_Eta_16_add.Text;
        string vTime_Eta_17 = this.txtTime_Eta_17_add.Text;
        string vTime_Eta_18 = this.txtTime_Eta_18_add.Text;
        string vTime_Eta_19 = this.txtTime_Eta_19_add.Text;
        string vTime_Eta_20 = this.txtTime_Eta_20_add.Text;
        string vTime_Eta_21 = this.txtTime_Eta_21_add.Text;
        string vTime_Eta_22 = this.txtTime_Eta_22_add.Text;
        string vTime_Eta_23 = this.txtTime_Eta_23_add.Text;
        string vTime_Eta_24 = this.txtTime_Eta_24_add.Text;

        string[] vTime_ETA = {"", txtTime_Eta_1_add.Text, txtTime_Eta_2_add.Text, txtTime_Eta_3_add.Text, txtTime_Eta_4_add.Text, txtTime_Eta_5_add.Text,
                                  txtTime_Eta_6_add.Text, txtTime_Eta_7_add.Text, txtTime_Eta_8_add.Text, txtTime_Eta_9_add.Text, txtTime_Eta_10_add.Text,
                                  txtTime_Eta_11_add.Text, txtTime_Eta_12_add.Text, txtTime_Eta_13_add.Text, txtTime_Eta_14_add.Text, txtTime_Eta_15_add.Text,
                                  txtTime_Eta_16_add.Text, txtTime_Eta_17_add.Text, txtTime_Eta_18_add.Text, txtTime_Eta_19_add.Text, txtTime_Eta_20_add.Text,
                                  txtTime_Eta_21_add.Text, txtTime_Eta_22_add.Text, txtTime_Eta_23_add.Text, txtTime_Eta_24_add.Text,};

        TextBox[] txtTime_ETA = {txtTime_Eta_1_add, txtTime_Eta_1_add, txtTime_Eta_2_add, txtTime_Eta_3_add, txtTime_Eta_4_add, txtTime_Eta_5_add,
                                                      txtTime_Eta_6_add, txtTime_Eta_7_add, txtTime_Eta_8_add, txtTime_Eta_9_add, txtTime_Eta_10_add,
                                                      txtTime_Eta_11_add, txtTime_Eta_12_add, txtTime_Eta_13_add, txtTime_Eta_14_add, txtTime_Eta_15_add,
                                                      txtTime_Eta_16_add, txtTime_Eta_17_add, txtTime_Eta_18_add, txtTime_Eta_19_add, txtTime_Eta_20_add,
                                                      txtTime_Eta_21_add, txtTime_Eta_22_add, txtTime_Eta_23_add, txtTime_Eta_24_add,};

        // Check null
        if (vSupplier_Cd == "")
        {
            txtSupplier_Cd_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0001"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vVENDOR_FCTRY == "")
        {
            txtVENDOR_FCTRY_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0026"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vSupplier_Name == "")
        {
            txtSupplier_Name_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0002"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vEffect_Sta_Date == "")
        {
            txtEffect_Sta_Date_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0003"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        //Chrck Lenght
        if (vSupplier_Cd.Length > 4)
        {
            txtSupplier_Cd_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0004"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vVENDOR_FCTRY.Length > 2)
        {
            txtVENDOR_FCTRY_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0027"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vSupplier_Name.Length > 100)
        {
            txtSupplier_Name_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0005"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vEffect_Sta_Date.Length > 8 || vEffect_Sta_Date.Length < 8)
        {
            txtEffect_Sta_Date_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0006"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }

        //Check Time ETA 1
        if (vTime_Eta_1 == "")
        {
            CSUtilities.dialogMessage(this, "Please specify the first Time ETA 1 โปรดระบุเวลาตัวแรกด้วยค่ะ [Time ETA 1] ");
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (vTime_Eta_1.Length < 4 || vTime_Eta_1.Substring(2, 2) != "00")
        {
            txtTime_Eta_1_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, "Please Time Format HH00 on [Time ETA 1] โปรดระบุเวลาเป็นรูปแบบ HH00 ใน [Time ETA 1]");
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        if (Int32.Parse(vTime_Eta_1) > 2300 || Int32.Parse(vTime_Eta_1) < 0000)
        {
            txtTime_Eta_1_add.BackColor = System.Drawing.Color.Red;
            CSUtilities.dialogMessage(this, "Please input Time range 0000 To 2300 [Time ETA 1] โปรดระบุเวลาในช่วง 0000 ถึง 2300 [Time ETA 1]");
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }
        
        //For Loop Check Time ETA 2 - 24
        int count = 0;        
        for (count = 2; count <= 24 ; count++)
        {            
            if (vTime_ETA[count] != "")
            {
                if (vTime_ETA[count].Length < 4 || vTime_ETA[count].Substring(2, 2) != "00")
                {
                    txtTime_ETA[count].BackColor = System.Drawing.Color.Red;                                       
                    CSUtilities.dialogMessage(this, "Please input Time Format HH00 on [Time ETA " + (count) + "] โปรดระบุเวลาเป็นรูปแบบ HH00 ใน [Time ETA " + (count) + "]");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);                    
                    return;
                }
                if (Int32.Parse(vTime_ETA[count]) > 2300 || Int32.Parse(vTime_ETA[count]) < 0000)
                {
                    txtTime_ETA[count].BackColor = System.Drawing.Color.Red;                    
                    CSUtilities.dialogMessage(this, "Please input Time range 0000 To 2300 [Time ETA " + (count) + "] โปรดระบุเวลาในช่วง 0000 ถึง 2300 [Time ETA " + (count) + "]");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                    return;
                }               
                if (vTime_ETA[count-1] == "")
                {
                    txtTime_ETA[count-1].BackColor = System.Drawing.Color.Red;                    
                    CSUtilities.dialogMessage(this, "Please specify previous [Time ETA " + (count - 1) + "] โปรดระบุเวลาก่อนหน้านี้ [Time ETA " + (count - 1) + "]");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                    return;
                }
                else if (Int32.Parse(vTime_ETA[count]) <= Int32.Parse(vTime_ETA[count-1]))
                {
                    txtTime_ETA[count].BackColor = System.Drawing.Color.Red;                    
                    CSUtilities.dialogMessage(this, "Please specify a delivery time more than the previous one. [Time ETA " + count + "] กรุณาระบุเวลาการส่งให้มากกว่ารอบก่อนหน้า [Time ETA " + count + "]");
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                    return;
                }
            }
        }

        // Check CD_SPLY_FACT IN EUC
        DataTable dt2 = new DataTable();
        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT * FROM dosystem.WBGJT002");
        sb.AppendFormat(" WHERE CD_SPLY_FACT ='{0}' AND CD_SPLY ='{1}' ", vVENDOR_FCTRY, vSupplier_Cd);
        dt2 = obEx.ExecuteQuery(sb.ToString(), "WBGJT002").Tables[0];

        if (dt2.Rows.Count == 0)
        {
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0030"));
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            return;
        }

        //Check Duplicate
        if (lblFormName_sub.Text == "ADD : DELIVERY ROUND")
        {
            DataTable dt1 = new DataTable();            
            sb.Remove(0, sb.Length);
            sb.AppendFormat("SELECT * FROM dosystem.T_PRD_DO_DELIVERY_MASTER ");
            sb.AppendFormat(" WHERE FACTORY_CD ='{0}' AND SUPPLIER_CD ='{1}' AND EFFECT_STA_DATE ='{2}' AND SUPPLIER_NAME ='{3}' AND CD_SPLY_FACT ='{4}' ", factory, vSupplier_Cd, vEffect_Sta_Date, vSupplier_Name, vVENDOR_FCTRY);
            dt1 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_DELIVERY_MASTER").Tables[0];

            if (dt1.Rows.Count > 0)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("SG0001"));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                return;
            }
            
        }        

        try
        {
            objDTO.FACTORY_CD = vFactory;
            objDTO.SUPPLIER_CD = vSupplier_Cd.ToString();
            objDTO.VENDOR_FCTRY = vVENDOR_FCTRY.ToString();
            objDTO.EFFECT_STA_DATE = vEffect_Sta_Date.ToString();
            objDTO.SUPPLIER_NAME = vSupplier_Name.ToString();
            objDTO.TIME_ETA_1 = vTime_Eta_1.ToString();
            objDTO.TIME_ETA_2 = vTime_Eta_2.ToString();
            objDTO.TIME_ETA_3 = vTime_Eta_3.ToString();
            objDTO.TIME_ETA_4 = vTime_Eta_4.ToString();
            objDTO.TIME_ETA_5 = vTime_Eta_5.ToString();
            objDTO.TIME_ETA_6 = vTime_Eta_6.ToString();
            objDTO.TIME_ETA_7 = vTime_Eta_7.ToString();
            objDTO.TIME_ETA_8 = vTime_Eta_8.ToString();
            objDTO.TIME_ETA_9 = vTime_Eta_9.ToString();
            objDTO.TIME_ETA_10 = vTime_Eta_10.ToString();
            objDTO.TIME_ETA_11 = vTime_Eta_11.ToString();
            objDTO.TIME_ETA_12 = vTime_Eta_12.ToString();
            objDTO.TIME_ETA_13 = vTime_Eta_13.ToString();
            objDTO.TIME_ETA_14 = vTime_Eta_14.ToString();
            objDTO.TIME_ETA_15 = vTime_Eta_15.ToString();
            objDTO.TIME_ETA_16 = vTime_Eta_16.ToString();
            objDTO.TIME_ETA_17 = vTime_Eta_17.ToString();
            objDTO.TIME_ETA_18 = vTime_Eta_18.ToString();
            objDTO.TIME_ETA_19 = vTime_Eta_19.ToString();
            objDTO.TIME_ETA_20 = vTime_Eta_20.ToString();
            objDTO.TIME_ETA_21 = vTime_Eta_21.ToString();
            objDTO.TIME_ETA_22 = vTime_Eta_22.ToString();
            objDTO.TIME_ETA_23 = vTime_Eta_23.ToString();
            objDTO.TIME_ETA_24 = vTime_Eta_24.ToString();
            objDTO.FLG_IN_HOUSE = this.rdoinhouse.SelectedValue;
            objDTO.USER_ID = username;

            vCnt = objDTO.DO_DELIVERY_ROUND_MASTER_INS_UPD();

            if (vCnt == 1)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0004"));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                ClearColorScreen2();
              //  ClearTextScreen2();
            }
            else if (vCnt == 2)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0005"));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
                ClearColorScreen2();
               // ClearTextScreen2();
            }
            else
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0002"));
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
            }
        }
        catch (Exception ex)
        {
            lblErrMsg.Text = ex.Message.ToString();
        }


    }
    protected void ClearColorScreen2()
    {        
        txtSupplier_Cd_add.BackColor = System.Drawing.Color.White;
        txtVENDOR_FCTRY_add.BackColor = System.Drawing.Color.White;
        txtEffect_Sta_Date_add.BackColor = System.Drawing.Color.White;        
        txtSupplier_Name_add.BackColor = System.Drawing.Color.White;

        txtTime_Eta_1_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_2_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_3_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_4_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_5_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_6_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_7_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_8_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_9_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_10_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_11_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_12_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_13_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_14_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_15_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_16_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_17_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_18_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_19_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_20_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_21_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_22_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_23_add.BackColor = System.Drawing.Color.White;
        txtTime_Eta_24_add.BackColor = System.Drawing.Color.White;                
    }
    protected void ClearTextScreen2()
    {
        this.txtSupplier_Cd_add.Text = "";
        this.txtVENDOR_FCTRY_add.Text = "";
        this.txtEffect_Sta_Date_add.Text = "";        
        this.txtSupplier_Name_add.Text = "";                
        txtTime_Eta_1_add.Text = "";
        txtTime_Eta_2_add.Text = "";
        txtTime_Eta_3_add.Text = "";
        txtTime_Eta_4_add.Text = "";
        txtTime_Eta_5_add.Text = "";
        txtTime_Eta_6_add.Text = "";
        txtTime_Eta_7_add.Text = "";
        txtTime_Eta_8_add.Text = "";
        txtTime_Eta_9_add.Text = "";
        txtTime_Eta_10_add.Text = "";
        txtTime_Eta_11_add.Text = "";
        txtTime_Eta_12_add.Text = "";
        txtTime_Eta_13_add.Text = "";
        txtTime_Eta_14_add.Text = "";
        txtTime_Eta_15_add.Text = "";
        txtTime_Eta_16_add.Text = "";
        txtTime_Eta_17_add.Text = "";
        txtTime_Eta_18_add.Text = "";
        txtTime_Eta_19_add.Text = "";
        txtTime_Eta_20_add.Text = "";
        txtTime_Eta_21_add.Text = "";
        txtTime_Eta_22_add.Text = "";
        txtTime_Eta_23_add.Text = "";
        txtTime_Eta_24_add.Text = "";
        this.rdoinhouse.SelectedValue = "";
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataTable dt = new DataTable();
        
        if (this.fluUpload.HasFile == true)
        {
            if (Path.GetExtension(this.fluUpload.FileName).ToUpper() != ".CSV")
            {
                CSUtilities.dialogMessage(this, "Please upload in CSV format.");
            }
            else
            {
                try
                {
                    CsvManagement CsvManage = new CsvManagement();
                    CsvManage.fileUpload = this.fluUpload.PostedFile;
                    CsvManage.CsvFileUpload();

                    sb.Remove(0, sb.Length);
                    sb.Append("SUPPLIER_CD,CD_SPLY_FACT,EFFECT_STA_DATE,SUPPLIER_NAME,TIME_ETA_1,TIME_ETA_2,TIME_ETA_3,TIME_ETA_4,TIME_ETA_5,TIME_ETA_6,TIME_ETA_7,TIME_ETA_8,TIME_ETA_9,TIME_ETA_10,TIME_ETA_11,TIME_ETA_12,TIME_ETA_13,TIME_ETA_14,TIME_ETA_15,TIME_ETA_16,TIME_ETA_17,TIME_ETA_18,TIME_ETA_19,TIME_ETA_20,TIME_ETA_21,TIME_ETA_22,TIME_ETA_23,TIME_ETA_24,FLG_INHOUSE");

                    dt = CsvManage.CsvHeaderToDataTable(sb.ToString());

                    if (ChKDetailBeforeUpload(dt))
                    {
                        UploadToDB(dt);

                    }
                }
                catch (Exception ex)
                {
                    lblErrorMsg.Text = ex.Message.ToString();
                }

            }
        }
        else
        {
            CSUtilities.dialogMessage(this, "Please select file to upload.");
        }
    }
    protected bool ChKDetailBeforeUpload(DataTable chkDT)
    {
        Label lblErrMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrMsg.Text = "";
        int number;        
        string str_Supplier_Cd = null;
        string str_VENDOR_FCTRY = null;
        string str_Effect_Sta_Date = null;
        string str_Supplier_Name = null;
        string str_Time_Eta_1 = null;
        string str_Time_Eta_2 = null;
        string str_Time_Eta_3 = null;
        string str_Time_Eta_4 = null;
        string str_Time_Eta_5 = null;
        string str_Time_Eta_6 = null;
        string str_Time_Eta_7 = null;
        string str_Time_Eta_8 = null;
        string str_Time_Eta_9 = null;
        string str_Time_Eta_10 = null;
        string str_Time_Eta_11 = null;
        string str_Time_Eta_12 = null;
        string str_Time_Eta_13 = null;
        string str_Time_Eta_14 = null;
        string str_Time_Eta_15 = null;
        string str_Time_Eta_16 = null;
        string str_Time_Eta_17 = null;
        string str_Time_Eta_18 = null;
        string str_Time_Eta_19 = null;
        string str_Time_Eta_20 = null;
        string str_Time_Eta_21 = null;
        string str_Time_Eta_22 = null;
        string str_Time_Eta_23 = null;
        string str_Time_Eta_24 = null;
        string str_Fig_inhouse = null;

        DataTable dt1 = new DataTable();
        string keyIndex = null;

        foreach (DataRow row in chkDT.Rows)
        {                        
            str_Supplier_Cd = row["SUPPLIER_CD"].ToString().Trim().ToUpper();
            str_VENDOR_FCTRY = row["CD_SPLY_FACT"].ToString().Trim().ToUpper();
            str_Effect_Sta_Date = row["EFFECT_STA_DATE"].ToString().Trim().ToUpper();
            str_Supplier_Name = row["SUPPLIER_NAME"].ToString().Trim().ToUpper();
            str_Time_Eta_1 = row["TIME_ETA_1"].ToString().Trim().ToUpper();
            str_Time_Eta_2 = row["TIME_ETA_2"].ToString().Trim().ToUpper();
            str_Time_Eta_3 = row["TIME_ETA_3"].ToString().Trim().ToUpper();
            str_Time_Eta_4 = row["TIME_ETA_4"].ToString().Trim().ToUpper();
            str_Time_Eta_5 = row["TIME_ETA_5"].ToString().Trim().ToUpper();
            str_Time_Eta_6 = row["TIME_ETA_6"].ToString().Trim().ToUpper();
            str_Time_Eta_7 = row["TIME_ETA_7"].ToString().Trim().ToUpper();
            str_Time_Eta_8 = row["TIME_ETA_8"].ToString().Trim().ToUpper();
            str_Time_Eta_9 = row["TIME_ETA_9"].ToString().Trim().ToUpper();
            str_Time_Eta_10 = row["TIME_ETA_10"].ToString().Trim().ToUpper();
            str_Time_Eta_11 = row["TIME_ETA_11"].ToString().Trim().ToUpper();
            str_Time_Eta_12 = row["TIME_ETA_12"].ToString().Trim().ToUpper();
            str_Time_Eta_13 = row["TIME_ETA_13"].ToString().Trim().ToUpper();
            str_Time_Eta_14 = row["TIME_ETA_14"].ToString().Trim().ToUpper();
            str_Time_Eta_15 = row["TIME_ETA_15"].ToString().Trim().ToUpper();
            str_Time_Eta_16 = row["TIME_ETA_16"].ToString().Trim().ToUpper();
            str_Time_Eta_17 = row["TIME_ETA_17"].ToString().Trim().ToUpper();
            str_Time_Eta_18 = row["TIME_ETA_18"].ToString().Trim().ToUpper();
            str_Time_Eta_19 = row["TIME_ETA_19"].ToString().Trim().ToUpper();
            str_Time_Eta_20 = row["TIME_ETA_20"].ToString().Trim().ToUpper();
            str_Time_Eta_21 = row["TIME_ETA_21"].ToString().Trim().ToUpper();
            str_Time_Eta_22 = row["TIME_ETA_22"].ToString().Trim().ToUpper();
            str_Time_Eta_23 = row["TIME_ETA_23"].ToString().Trim().ToUpper();
            str_Time_Eta_24 = row["TIME_ETA_24"].ToString().Trim().ToUpper();
            str_Fig_inhouse = row["FLG_INHOUSE"].ToString().Trim().ToUpper();


            string[] vTime_ETA = {"", row["TIME_ETA_1"].ToString().Trim().ToUpper(), row["TIME_ETA_2"].ToString().Trim().ToUpper(), row["TIME_ETA_3"].ToString().Trim().ToUpper(), row["TIME_ETA_4"].ToString().Trim().ToUpper(), row["TIME_ETA_5"].ToString().Trim().ToUpper(),
                                  row["TIME_ETA_6"].ToString().Trim().ToUpper(), row["TIME_ETA_7"].ToString().Trim().ToUpper(), row["TIME_ETA_8"].ToString().Trim().ToUpper(), row["TIME_ETA_9"].ToString().Trim().ToUpper(), row["TIME_ETA_10"].ToString().Trim().ToUpper(),
                                  row["TIME_ETA_11"].ToString().Trim().ToUpper(), row["TIME_ETA_12"].ToString().Trim().ToUpper(), row["TIME_ETA_13"].ToString().Trim().ToUpper(), row["TIME_ETA_14"].ToString().Trim().ToUpper(), row["TIME_ETA_15"].ToString().Trim().ToUpper(),
                                  row["TIME_ETA_16"].ToString().Trim().ToUpper(), row["TIME_ETA_17"].ToString().Trim().ToUpper(), row["TIME_ETA_18"].ToString().Trim().ToUpper(), row["TIME_ETA_19"].ToString().Trim().ToUpper(), row["TIME_ETA_20"].ToString().Trim().ToUpper(),
                                  row["TIME_ETA_21"].ToString().Trim().ToUpper(), row["TIME_ETA_22"].ToString().Trim().ToUpper(), row["TIME_ETA_23"].ToString().Trim().ToUpper(), row["TIME_ETA_24"].ToString().Trim().ToUpper()};

            keyIndex = "[SUPPLIER_CD: " + str_Supplier_Cd + " /SUPPLIER_NAME: " + str_Supplier_Name + " /EFFECT_STA_DATE: " + str_Effect_Sta_Date + " ]";

            //Check Null ----------------------------------------------------
            if (str_Supplier_Cd == "")
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0001") + keyIndex);
                return false;
            }
            if (str_VENDOR_FCTRY == "")
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0026") + keyIndex);
                return false;
            }
            if (str_Supplier_Name == "")
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0002") + keyIndex);
                return false;
            }
            if (str_Effect_Sta_Date == "")
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0003") + keyIndex);
                return false;
            }

            //Check Format Date            
            string formats = "yyyyMMd";
            DateTime dateValue;

            if (!DateTime.TryParseExact(str_Effect_Sta_Date, formats, new CultureInfo("en-US"), DateTimeStyles.None, out dateValue))
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0157") + keyIndex);
                return false;
            }

            //Check Lenght ----------------------------------------------------
            if (str_Supplier_Cd.Length > 4)
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0004") + keyIndex);
                return false;
            }
            if (str_VENDOR_FCTRY.Length > 2)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0027") + keyIndex);
                return false;
            }
            if (str_Supplier_Name.Length > 100)
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0005") + keyIndex);
                return false;
            }
            if (str_Effect_Sta_Date.Length > 8 || str_Effect_Sta_Date.Length < 8)
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0006") + keyIndex);
                return false;
            }

            //Check Time ETA 1
            if (str_Time_Eta_1 == "")
            {
                CSUtilities.dialogMessage(this, "Please specify the first Time ETA 1 โปรดระบุเวลาตัวแรกด้วยค่ะ [Time ETA 1] " + keyIndex);                
                return false;
            }
            if (int.TryParse(str_Time_Eta_1, out number) == false)
            {
                CSUtilities.dialogMessage(this, "Time ETA type is number only โปรดระบุเวลาเป็นตัวเลขเท่านั้น [Time ETA 1] " + keyIndex);                
                return false;
            }
            if (str_Time_Eta_1.Length < 4 || str_Time_Eta_1.Substring(2, 2) != "00")
            {
                CSUtilities.dialogMessage(this, "Please iznput Time Format HH00 โปรดระบุเวลาเป็นรูปแบบ HH00 [Time ETA 1] " + keyIndex);                
                return false;
            }
            if (Int32.Parse(str_Time_Eta_1) > 2300 || Int32.Parse(str_Time_Eta_1) < 0000)
            {
                CSUtilities.dialogMessage(this, "Please input Time range 0000 To 2300 โปรดระบุเวลาในช่วง 0000 ถึง 2300 [Time ETA 1] " + keyIndex);                
                return false;
            }

            //Check Time ETA 1
            if (str_Fig_inhouse != "" && str_Fig_inhouse.ToUpper() != "Y" && str_Fig_inhouse.ToUpper() != "N")
            {
                CSUtilities.dialogMessage(this, "Please FLG IN HOUSE is  Y or N or null " + keyIndex);
                return false;
            }

            //For Loop Check Time ETA 2 - 24
            int count = 0;
            for (count = 2; count <= 24; count++)
            {
                if (vTime_ETA[count] != "")
                {
                    if (int.TryParse(str_Time_Eta_1, out number) == false)
                    {
                        CSUtilities.dialogMessage(this, "Time ETA type is number only โปรดระบุเวลาเป็นตัวเลขเท่านั้น [Time ETA " + count + "] " + keyIndex);                        
                        return false;
                    }
                    if (vTime_ETA[count].Length > 4 || vTime_ETA[count].Substring(2, 2) != "00")
                    {
                        CSUtilities.dialogMessage(this, "Please input Time Format HH00 โปรดระบุเวลาเป็นรูปแบบ HH00 [Time ETA " + count + "] " + keyIndex);                        
                        return false;
                    }
                    if (Int32.Parse(vTime_ETA[count]) > 2300 || Int32.Parse(vTime_ETA[count]) < 0000)
                    {
                        CSUtilities.dialogMessage(this, "Please input Time range 0000 To 2300 โปรดระบุเวลาในช่วง 0000 ถึง 2300 [Time ETA " + count + "] " + keyIndex);                        
                        return false;
                    }
                    if (vTime_ETA[count - 1] == "")
                    {
                        CSUtilities.dialogMessage(this, "Please specify previous โปรดระบุเวลาก่อนหน้านี้ [Time ETA " + (count - 1) + "] " + keyIndex);                        
                        return false;
                    }
                    if (Int32.Parse(vTime_ETA[count]) <= Int32.Parse(vTime_ETA[count - 1]))
                    {
                        CSUtilities.dialogMessage(this, "Please specify a delivery time more than the previous one. กรุณาระบุเวลาการส่งให้มากกว่ารอบก่อนหน้า [Time ETA " + count + "] " + keyIndex);                        
                        return false;
                    }
                }
            }

            
            //check Duplicate in CSV            
           // int cntRow = chkDT.Select("SUPPLIER_CD = '" + str_Supplier_Cd + "' AND EFFECT_STA_DATE = '"+ str_Effect_Sta_Date + "'" + "' AND CD_SPLY_FACT = '" + str_VENDOR_FCTRY + '").Length;
           // int cntRow = chkDT.Select("SUPPLIER_CD = '" + str_Supplier_Cd + "' AND EFFECT_STA_DATE = '" + str_Effect_Sta_Date + "'").Length;
            int cntRow = chkDT.Select("SUPPLIER_CD = '" + str_Supplier_Cd + "' AND EFFECT_STA_DATE = '" + str_Effect_Sta_Date + "' AND CD_SPLY_FACT = '" + str_VENDOR_FCTRY + "'").Length;

            if (cntRow > 1)
            {                
                //Primary key is duplicate in CSV file.
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WH0067") + keyIndex);
                return false;
            }

            DataTable dt2 = new DataTable();
            sb.Remove(0, sb.Length);
            sb.AppendFormat("SELECT * FROM dosystem.WBGJT002");
            sb.AppendFormat(" WHERE CD_SPLY_FACT ='{0}' AND CD_SPLY ='{1}' ", str_VENDOR_FCTRY, str_Supplier_Cd);
            dt2 = obEx.ExecuteQuery(sb.ToString(), "WBGJT002").Tables[0];

            if (dt2.Rows.Count == 0)
            {

                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0030") + keyIndex);
                return false;
            }

        }
        return true;
    }
    protected void UploadToDB(DataTable dt)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        int vFlag = 0;
        int vCntRow = 0;

        foreach (DataRow Row in dt.Rows)
        {
            vCntRow++;
            string vIndex = " [Rows : " + vCntRow + "]";
            string str_Fig_inhouse;
            try
            {
                objDTO.FACTORY_CD = factory;
                objDTO.SUPPLIER_CD = Row["SUPPLIER_CD"].ToString().Trim().ToUpper();
                objDTO.VENDOR_FCTRY = Row["CD_SPLY_FACT"].ToString().Trim().ToUpper();
                objDTO.EFFECT_STA_DATE = Row["EFFECT_STA_DATE"].ToString().Trim().ToUpper();
                objDTO.SUPPLIER_NAME = Row["SUPPLIER_NAME"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_1 = Row["TIME_ETA_1"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_2 = Row["TIME_ETA_2"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_3 = Row["TIME_ETA_3"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_4 = Row["TIME_ETA_4"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_5 = Row["TIME_ETA_5"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_6 = Row["TIME_ETA_6"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_7 = Row["TIME_ETA_7"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_8 = Row["TIME_ETA_8"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_9 = Row["TIME_ETA_9"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_10 = Row["TIME_ETA_10"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_11 = Row["TIME_ETA_11"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_12 = Row["TIME_ETA_12"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_13 = Row["TIME_ETA_13"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_14 = Row["TIME_ETA_14"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_15 = Row["TIME_ETA_15"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_16 = Row["TIME_ETA_16"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_17 = Row["TIME_ETA_17"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_18 = Row["TIME_ETA_18"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_19 = Row["TIME_ETA_19"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_20 = Row["TIME_ETA_20"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_21 = Row["TIME_ETA_21"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_22 = Row["TIME_ETA_22"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_23 = Row["TIME_ETA_23"].ToString().Trim().ToUpper();
                objDTO.TIME_ETA_24 = Row["TIME_ETA_24"].ToString().Trim().ToUpper();

                str_Fig_inhouse = Row["FLG_INHOUSE"].ToString().Trim().ToUpper();

                if (str_Fig_inhouse == "N") {

                    str_Fig_inhouse = "";

                }

                objDTO.FLG_IN_HOUSE = str_Fig_inhouse;
                objDTO.USER_ID = username;
                vFlag = objDTO.DO_DELIVERY_ROUND_MASTER_INS_UPD();                

                if (vFlag != 1 && vFlag != 2)
                {
                    CSUtilities.dialogMessage(this, "Insert to database was failure at" + vIndex);
                    return;
                }
                
            }
            catch (Exception ex)
            {
                lblErrorMsg.Text = ex.Message.ToString();
                return;
            }
        }
        
        if (vFlag == 1)
        {
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0004") + "[" + vCntRow + " Rows]");
            BindData();
        }
        else if (vFlag == 2)
        {
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0005") + "[" + vCntRow + " Rows]");
            BindData();
        }
    }

    protected void btnDetialformat_Click(object sender, EventArgs e)
    {
        sb.Remove(0, sb.Length);
        sb.Append("SUPPLIER_CD,VENDOR_FCTRY,EFFECT_STA_DATE,SUPPLIER_NAME,TIME_ETA_1,TIME_ETA_2,TIME_ETA_3,TIME_ETA_4,TIME_ETA_5,TIME_ETA_6,TIME_ETA_7,TIME_ETA_8,TIME_ETA_9,TIME_ETA_10,TIME_ETA_11,TIME_ETA_12,TIME_ETA_13,TIME_ETA_14,TIME_ETA_15,TIME_ETA_16,TIME_ETA_17,TIME_ETA_18,TIME_ETA_19,TIME_ETA_20,TIME_ETA_21,TIME_ETA_22,TIME_ETA_23,TIME_ETA_24,FLG_INHOUSE");

        CsvManagement csvManage = new CsvManagement();
        csvManage.ExportFormatCsv("Format_Delivery_Round_Master", sb.ToString());
    }

    protected void gvShowData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        int vFlag = 0;
        try
        {            
            objDTO.FACTORY_CD = factory;
            objDTO.SUPPLIER_CD = this.gvShowData.Rows[e.RowIndex].Cells[1].Text;
            objDTO.VENDOR_FCTRY = this.gvShowData.Rows[e.RowIndex].Cells[2].Text;
            objDTO.EFFECT_STA_DATE = this.gvShowData.Rows[e.RowIndex].Cells[4].Text;
            objDTO.USER_ID = username;
            vFlag = objDTO.DO_DELIVERY_ROUND_MASTER_DEL();

            if (vFlag == 1)
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0007"));
                BindData();
            }
            else
            {                
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0010"));
            }
        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();

        }
    }

    protected void gvShow_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        lblFormName_sub.Text = "UPDATE : DELIVERY ROUND";
        btnAdd_add.Text = "UPDATE";
        lblfactory_add.Text = factory;
        txtSupplier_Cd_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[1].Text;
        txtSupplier_Cd_add.ReadOnly = true;
        txtSupplier_Cd_add.BackColor = System.Drawing.Color.Silver;
        txtVENDOR_FCTRY_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[2].Text;
        txtVENDOR_FCTRY_add.ReadOnly = true;
        txtVENDOR_FCTRY_add.BackColor = System.Drawing.Color.Silver;
        txtSupplier_Name_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[3].Text;
        txtEffect_Sta_Date_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[4].Text;
       // txtEffect_Sta_Date_add.ReadOnly = true;
        txtEffect_Sta_Date_add.BackColor = System.Drawing.Color.Silver;
        txtTime_Eta_1_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[5].Text.Replace("&nbsp;", "");
        txtTime_Eta_2_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[6].Text.Replace("&nbsp;", "");
        txtTime_Eta_3_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[7].Text.Replace("&nbsp;", "");
        txtTime_Eta_4_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[8].Text.Replace("&nbsp;", "");
        txtTime_Eta_5_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[9].Text.Replace("&nbsp;", "");
        txtTime_Eta_6_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[10].Text.Replace("&nbsp;", "");
        txtTime_Eta_7_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[11].Text.Replace("&nbsp;", "");
        txtTime_Eta_8_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[12].Text.Replace("&nbsp;", "");
        txtTime_Eta_9_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[13].Text.Replace("&nbsp;", "");
        txtTime_Eta_10_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[14].Text.Replace("&nbsp;", "");
        txtTime_Eta_11_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[15].Text.Replace("&nbsp;", "");
        txtTime_Eta_12_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[16].Text.Replace("&nbsp;", "");
        txtTime_Eta_13_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[17].Text.Replace("&nbsp;", "");
        txtTime_Eta_14_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[18].Text.Replace("&nbsp;", "");
        txtTime_Eta_15_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[19].Text.Replace("&nbsp;", "");
        txtTime_Eta_16_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[20].Text.Replace("&nbsp;", "");
        txtTime_Eta_17_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[21].Text.Replace("&nbsp;", "");
        txtTime_Eta_18_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[22].Text.Replace("&nbsp;", "");
        txtTime_Eta_19_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[23].Text.Replace("&nbsp;", "");
        txtTime_Eta_20_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[24].Text.Replace("&nbsp;", "");
        txtTime_Eta_21_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[25].Text.Replace("&nbsp;", "");
        txtTime_Eta_22_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[26].Text.Replace("&nbsp;", "");
        txtTime_Eta_23_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[27].Text.Replace("&nbsp;", "");
        txtTime_Eta_24_add.Text = this.gvShowData.Rows[e.RowIndex].Cells[28].Text.Replace("&nbsp;", "");

        string Flginhouse = this.gvShowData.Rows[e.RowIndex].Cells[29].Text.Replace("&nbsp;", "");
        if (Flginhouse == null)
        {
            Flginhouse = "";

        }
        this.rdoinhouse.SelectedValue = Flginhouse;

        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "my", "$('#AddNewData').show();$('#showData').hide();", true);
    }

    protected void gvShowData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvShowData.PageIndex = e.NewPageIndex;
        BindData();
    }


    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("UI_PRD_S041_DO_Main_Menu1.aspx?&FACTORY_CD=" + factory + "&username=" + username);
    }
}