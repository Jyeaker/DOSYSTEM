-- FUNCTION: dosystem.p_do_part_master_upd_logic(character varying, smallint, character varying)
-- DROP FUNCTION IF EXISTS dosystem.p_do_part_master_upd_logic(character varying, smallint, character varying);

CREATE OR REPLACE FUNCTION dosystem.p_do_part_master_upd_logic(
	pfactory_cd character varying,
	plogic smallint,
	puser_id character varying)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    pflag INTEGER := 0;
BEGIN

    -- Insert history records
    INSERT INTO dosystem.t_prd_do_part_master_his (
        type,
        factory_cd,
        part_no,
        dim,
        block_cd,
        supplier_cd,
        total_process_lt,
        create_date,
        create_by,
        update_date,
        update_by,
        history_date,
        history_by,
        logic,
        sp_plan_slide
    )
    SELECT
        'UPD',
        a.factory_cd,
        a.part_no,
        a.dim,
        a.block_cd,
        a.supplier_cd,
        a.total_process_lt,
        a.create_date,
        a.create_by,
        a.update_date,
        a.update_by,
        CURRENT_DATE,
        puser_id,
        a.logic,
        a.sp_plan_slide
    FROM dosystem.t_prd_do_part_master a
    WHERE factory_cd = pfactory_cd;

    -- Update main table
    UPDATE dosystem.t_prd_do_part_master
    SET logic = plogic,
        update_by = puser_id,
        update_date = CURRENT_DATE
    WHERE factory_cd = pfactory_cd;

    pflag := 1;

    RETURN pflag;

EXCEPTION
    WHEN OTHERS THEN
        pflag := 0;
        RETURN pflag;

END;
$BODY$;

ALTER FUNCTION dosystem.p_do_part_master_upd_logic(character varying, smallint, character varying)
    OWNER TO dosystem;
