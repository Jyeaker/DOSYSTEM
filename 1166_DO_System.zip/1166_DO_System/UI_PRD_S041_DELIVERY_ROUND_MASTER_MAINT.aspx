﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UI_PRD_S041_DELIVERY_ROUND_MASTER_MAINT.aspx.cs" Inherits="UI_PRD_S041_DELIVERY_ROUND_MASTER_MAINT" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <!-- Reference for Freeze Gridview -->
    <link href="js/GridViewScroll/GridviewScroll.css" rel="stylesheet" />
    <link href="js/GridViewScroll/GridviewCustomStyle.css" rel="stylesheet" />
     <%--jQuery v1.9.0 and jQuery UI - v1.9.1--%>
    <script src="js/GridViewScroll/jquery.min.js"></script>
    <script src="js/GridViewScroll/jquery-ui.min.js"></script>    
    <script src="js/GridViewScroll/gridviewScroll.min.js"></script>
    <style type="text/css">
       
    </style>

    <script type="text/javascript">

        //Call Reference in this page only(gridviewScroll Require jQuery v1.9.0 and jQuery UI - v1.9.1)
        var $j = jQuery.noConflict();
        $j(document).ready(function () {
            //Fix header when rows more than 0 rows  
            if(document.getElementById("<%=gvShowData.ClientID %>"))
            {
                var grid = document.getElementById("<%=gvShowData.ClientID %>");
                if (grid.rows.length > 0) {
                    gridviewScroll();
                }
            }
            
        });

        function gridviewScroll() {
                $j('#<%=gvShowData.ClientID%>').gridviewScroll({
                width: screen.width - 160,
                height: 410,
                arrowsize: 30,
                varrowtopimg: "js/GridViewScroll/Images/arrowvt.png",
                varrowbottomimg: "/js/GridViewScroll/Images/arrowvb.png",
                harrowleftimg: "/js/GridViewScroll/Images/arrowhl.png",
                harrowrightimg: "/js/GridViewScroll/Images/arrowhr.png",
                headerrowcount: 1
                });            
        }



        function ConfirmDelete() {
            if (confirm("<%=CSUtilities.GetErrMsg( "CG0003" )%>"))
                    return true;
                else
                    return false;
        }
        function ConfirmUpdate() {
            if (confirm("<%=CSUtilities.GetErrMsg( "CG0004" )%>"))
                    return true;
                else
                    return false;
        }

        $(function () {
        $('#<%=txtEffectStartDate.ClientID%>').datepicker({
            dateFormat: "yymmdd"
        });

        $('#<%=txtEffect_Sta_Date_add.ClientID%>').datepicker({
            dateFormat: "yymmdd"
        });        

        });

        function showAdd() {
            $('#AddNewData').show(); $('#showData').hide();

            return false;
        }

        function isNumberKey(evt, element) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
                return false;
            else {
                var len = $(element).val().length;
                var index = $(element).val().indexOf('.');
                if (index > 0 && charCode == 46) {
                    return false;
                }
                if (index > 0) {
                    var CharAfterdot = (len + 1) - index;
                    if (CharAfterdot > 3) {
                        return false;
                    }
                }

            }
            return true;
        }
        
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <div id="showData">
    <div class="container" style="text-align: center;">
        <table class="table table-hover" style="width: 100%; text-align: center; color: #006bff;">
            <tr>
                <td style="width: 6%; text-align: right; margin-right: 1em; vertical-align: middle;">SUPPLIER CD:</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtSupplierCD" Height="28px" runat="server" MaxLength="4" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>
                <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">SUPPLIER NAME:</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtSupplierName" Height="28px" runat="server" MaxLength="100" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>
                <td style="width: 10%; text-align: right; margin-right: 1em; vertical-align: middle;">EFFECT START DATE: </td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtEffectStartDate" Height="28px" runat="server" MaxLength="8" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" placeholder="YYYYMMDD" ></asp:TextBox>
                </td>   
                             
            </tr>

            <tr style="height: 70%;">
                <td style="height: 80%; width: 100%; text-align: left; margin-left: 1em; text-align: center;" colspan="8">
                    <asp:Button ID="btnSearch" runat="server" Text="SEARCH" CssClass="btn btn-primary" Width="15%" Style="display: inline-block;" OnClick="btnSearch_Click" />
                    <asp:Button ID="btnDownload" runat="server" Text="DOWNLOAD" CssClass="btn btn-info" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btn_dow_csv_Click"/>
                    <asp:Button ID="btnAdd" runat="server" Text="ADD" class="btn btn-success" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btnAdd_Click" />
                    <asp:Button ID="btnClear" runat="server" Text="CLEAR" class="btn btn-warning" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btnClear_Click" />
                    <asp:Button ID="btnExit" runat="server" Text="EXIT" CssClass="btn btn-danger" Width="15%" Style="display: inline-block; margin-left: 1em"  OnClick="btnExit_Click"/>

                </td>
            </tr>
        </table>
    </div>
    <%-- START : Gridview  --%>
    <div class="container" style="height: 420px; width: 90%;">            
            <asp:Panel ID="pnlShowData" runat="server" class="panel panel-default" Height="100%"  >
                <asp:GridView ID="gvShowData" runat="server" Width="100%" CssClass="table-bordered table-hover" Font-Size="Smaller" GridLines="None"
                    AutoGenerateColumns="false"
                    AllowPaging="true" PageSize="30" PagerSettings-Mode="NumericFirstLast"
                    PagerSettings-FirstPageText="First" PagerSettings-LastPageText="Last"
                    OnPageIndexChanging="gvShowData_PageIndexChanging"
                    OnRowDeleting="gvShowData_RowDeleting" 
                    OnRowUpdating="gvShow_RowUpdating">
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <Columns>
                        <asp:TemplateField HeaderText="COMMAND" ItemStyle-Width="2.5%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" HeaderStyle-Width="2.5%" >
                            <ItemTemplate>
                                <asp:ImageButton ID="imgEdit" runat="server" CommandName="update" AlternateText="UPDATE" ImageUrl="~/images/edit.png" Width="20" />
                                <asp:ImageButton ID="imgDel" runat="server" CommandName="delete" AlternateText="DELETE" ImageUrl="~/images/deleteX.png" Width="20" OnClientClick="return ConfirmDelete();" />
                            </ItemTemplate>                            
                            <HeaderStyle Width="2%"></HeaderStyle>
                            <ItemStyle />
                        </asp:TemplateField>
                        <asp:BoundField HeaderText="SUPPLIER_CD" DataField="SUPPLIER_CD" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#40E0D0"/>    
                        <asp:BoundField HeaderText="VENDOR_FCTRY" DataField="CD_SPLY_FACT" HeaderStyle-Width="3%" ItemStyle-Width="3%"  ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#40E0D0"/>                  
                        <asp:BoundField HeaderText="SUPPLIER_NAME" DataField="SUPPLIER_NAME" HeaderStyle-Width="10%" ItemStyle-Width="10%" ItemStyle-HorizontalAlign="Center"  HeaderStyle-BackColor="#40E0D0"/>
                        <asp:BoundField HeaderText="EFFECT_STA_DATE" DataField="EFFECT_STA_DATE" HeaderStyle-Width="4%" ItemStyle-Width="4%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#40E0D0"/>
                        <asp:BoundField HeaderText="TIME_ETA_1" DataField="TIME_ETA_1" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_2" DataField="TIME_ETA_2" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_3" DataField="TIME_ETA_3" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_4" DataField="TIME_ETA_4" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_5" DataField="TIME_ETA_5" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_6" DataField="TIME_ETA_6" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_7" DataField="TIME_ETA_7" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_8" DataField="TIME_ETA_8" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_9" DataField="TIME_ETA_9" HeaderStyle-Width="2.6%" ItemStyle-Width="2.6%" ReadOnly="true" ItemStyle-HorizontalAlign="Center"  HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_10" DataField="TIME_ETA_10"  HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_11" DataField="TIME_ETA_11" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_12" DataField="TIME_ETA_12" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_13" DataField="TIME_ETA_13" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_14" DataField="TIME_ETA_14" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_15" DataField="TIME_ETA_15" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_16" DataField="TIME_ETA_16" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_17" DataField="TIME_ETA_17" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_18" DataField="TIME_ETA_18" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_19" DataField="TIME_ETA_19" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_20" DataField="TIME_ETA_20" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_21" DataField="TIME_ETA_21" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_22" DataField="TIME_ETA_22" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_23" DataField="TIME_ETA_23" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="TIME_ETA_24" DataField="TIME_ETA_24" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" />
                        <asp:BoundField HeaderText="INHOUSE" DataField="FLG_IN_HOUSE" HtmlEncode="false" HeaderStyle-Width="3%" ItemStyle-Width="3%"/>
                         <asp:BoundField HeaderText="CREATE_DATE" DataField="USER_CREATE_DATE" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="CREATE_BY" DataField="CREATE_BY" HeaderStyle-Width="2.5%" ItemStyle-Width="2.5%"  ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="UPDATE_DATE" DataField="USER_UPDATE_DATE" HeaderStyle-Width="3%" ItemStyle-Width="3%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                        <asp:BoundField HeaderText="UPDATE_BY" DataField="UPDATE_BY" HeaderStyle-Width="2.5%" ItemStyle-Width="2.5%" ReadOnly="true" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#6495ED" />
                    </Columns>
                    <HeaderStyle BackColor="#99ccff" ForeColor="Black"  VerticalAlign="Middle" CssClass="headerGrid" />
                    <PagerSettings FirstPageText="First" LastPageText="Last" Mode="NumericFirstLast" />
                    <PagerStyle CssClass="pagination-ys" />
                    <RowStyle Height="40px" Font-Size="11px" HorizontalAlign="Center" VerticalAlign="Middle" CssClass="ItemGrid"  />
                </asp:GridView>                        
            </asp:Panel>
        </div>
        <%-- END : Gridview  --%>
        <%-- START : upload  --%>
        <div class="container" style="position: relative; margin-top: 0.5em; border: dotted; background: #d6eaf8; border-color: #aed6f1;">

                <table class="table" style="width: 80%; margin: 0 auto;">
                <tr>
                    <td style="text-align: left; margin-right: 3em; font-family: Candara; vertical-align: middle; width: 30%;" class="auto-style1">
                        <font size="3px">  Please  select csv : For Upload Data </font></td>

                    <td style="text-align: left; margin-right: 10px; vertical-align: middle; width: 70%;">
                        <asp:FileUpload ID="fluUpload" runat="server" CssClass="form-control" Style="display: inline-block;" Width="50%" />
                        <asp:Button ID="btnUpload" runat="server" Text="Upload CSV" CssClass="btn btn-success" Style="display: inline-block; margin-left: 10px" Width="22%" OnClick="btnUpload_Click" />
                        <asp:Button ID="btnDetialformat" runat="server" Text="Upload Format" CssClass="btn btn-primary" Style="display: inline-block; margin-left: 10px" Width="22%" OnClick="btnDetialformat_Click" />
                    </td>
                </tr>
            </table>
        </div>

        <%-- END : upload  --%>
    </div>
    
    <%-- START : ADD Data Screen //hide  --%>
    <div id="AddNewData" class="container" style="display: none; width: 70%">
        <h4><asp:Label ID="lblFormName_sub" runat="server" Text="" Font-Bold="true" ForeColor="blue"></asp:Label></h4>
        <table class="table" style="width: 100%; margin: auto 0;">            
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>FACTORY CD : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" colspan="2" >      
                        <b><asp:Label ID="lblfactory_add" runat="server" ForeColor="blue"></asp:Label></b>                    
                </td>
            </tr> 
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Supplier Cd : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" colspan="2" >      
                        <asp:TextBox id="txtSupplier_Cd_add" runat="server" CssClass="form-control" style="display:inline-block; text-transform:uppercase;" Width="70%" MaxLength="4" />
                    <font color="red" size="4px">*</font>        
                </td>
            </tr> 

           <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Vendor Facry : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" colspan="2" >      
                        <asp:TextBox id="txtVENDOR_FCTRY_add" runat="server" CssClass="form-control" style="display:inline-block; text-transform:uppercase;" Width="70%" MaxLength="2" />
                    <font color="red" size="4px">*</font>        
                </td>
            </tr>


            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Supplier Name : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" colspan="2" >      
                        <asp:TextBox id="txtSupplier_Name_add" runat="server" CssClass="form-control" style="display:inline-block; text-transform:uppercase;" Width="70%" MaxLength="100" />  
                    <font color="red" size="4px">*</font>      
                </td>
            </tr>
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Effect STA Date : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" colspan="2" >      
                        <asp:TextBox id="txtEffect_Sta_Date_add" runat="server" CssClass="form-control" style="display:inline-block; text-transform:uppercase;" Width="70%" MaxLength="8" placeholder="YYYYMMDD"/> 
                    <font color="red" size="4px">*</font>       
                </td>
            </tr>          
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 1 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_1_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/> 
                    <font color="red" size="4px">*</font>                         
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 13 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_13_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                           
                </td>
            </tr>       
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 2 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_2_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                      
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 14 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_14_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00" />                                         
                </td>
            </tr>      
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 3 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_3_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                  
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 15 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_15_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                         
                </td>
            </tr>  
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 4 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_4_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                        
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 16 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_16_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                           
                </td>
            </tr> 
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 5 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_5_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                          
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 17 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_17_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                          
                </td>
            </tr>   
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 6 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_6_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                        
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 18 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_18_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                        
                </td>
            </tr>      
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 7 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_7_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                         
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 19 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_19_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                           
                </td>
            </tr>           
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 8 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_8_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                       
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 20 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_20_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                         
                </td>
            </tr>   
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 9 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_9_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                      
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 21 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_21_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                        
                </td>
            </tr>     
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 10 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_10_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                  
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 22 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_22_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                          
                </td>
            </tr>  
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 11 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_11_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/>                                        
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 23 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_23_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/> 
                                          
                </td>
            </tr>    
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 12 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                       
                    <asp:TextBox id="txtTime_Eta_12_add" runat="server" CssClass="form-control" style="display:inline-block; position:relative;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/> 
                                   
                </td>
                
                <td style="text-align:right;vertical-align:middle;"><b>Time ETA 24 : </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" > 
                    <asp:TextBox id="txtTime_Eta_24_add" runat="server" CssClass="form-control" style="display:inline-block;" Width="70%" MaxLength="4" onkeypress="return isNumberKey(event,this)" placeholder="HH00"/> 
                                          
                </td>
            </tr>    
            <tr>
                <td style="text-align:right;vertical-align:middle;"><b>IN-HOUSE SUPPILER : </b></td>
                 <td style="text-align:left;margin-left:10px;vertical-align:middle;" >   
                        <asp:RadioButtonList ID="rdoinhouse" runat="server" RepeatColumns="2">
                            <asp:ListItem Value=""  Selected="True">&nbsp;NO&nbsp;&nbsp;</asp:ListItem>           
                            <asp:ListItem Value="Y">&nbsp;YES&nbsp;&nbsp;</asp:ListItem>
                                           
                        </asp:RadioButtonList>
                    </td>
                
                <td style="text-align:right;vertical-align:middle;"><b> </b></td>
                <td style="text-align:left;margin-left:10px;vertical-align:middle;" >                  
                </td>
            </tr> 
                     
            <tr>
                <td style="height: 80%; width: 100%; text-align: left; margin-left: 1em; text-align: center;" colspan="6">
                    <asp:Button ID="btnAdd_add" runat="server" Text="ADD NEW" class="btn btn-success" Width="100px" OnClick="btnAdd_add_Click" />
                    <asp:Button ID="btnCancel" runat="server" Text="EXIT" class="btn btn-danger" Width="100px"  Style="margin-left: 1em" OnClick="btnCancel_add_Click"/>
                </td>
            </tr>
        </table>                
    </div>
    <%-- END : ADD Data Screen //hide  --%>
</asp:Content>

