﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Net.Mime;
using System.IO;
using System.Globalization;
using System.Text;
using System.Data;


/// <summary>
/// Summary description for Utilities
/// </summary>
public class CSUtilities
{
   /* OracleConnection Conn = new OracleConnection();
    OracleCommand Cmd = new OracleCommand();
    OracleDataAdapter Da = new OracleDataAdapter();*/

 /*   public void ConnDB()
    {
        if (Conn.State == ConnectionState.Open)
        {
            Conn.Close();
        }
        else
        {
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            Conn.Open();
        }
    }
 */


    private static NetworkCredential Credential;

    public static void SetupCredential()
    {
        if (Credential == null)
        {
            Credential = new NetworkCredential(ConfigurationManager.AppSettings["domainUsername"], ConfigurationManager.AppSettings["domainPassword"], ConfigurationManager.AppSettings["domain"]);
        }
    }

    public static void ReturnCredential()
    {
        Credential = null;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="pTo"></param>
    /// <param name="pSubject"></param>
    /// <param name="pMessage"></param>
    /// <param name="pAttachedFile"></param>
    public static void SendEmail(string[] pTo, string pSubject, string pMessage)
    {
        try
        {
            string mailServer = ConfigurationManager.AppSettings["Mail_Server"];
            string vMailFrom = ConfigurationManager.AppSettings["Mail_From"];

            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(vMailFrom);

            for (int i = 0; i < pTo.Length; i++)
            {
                mail.To.Add(pTo[i]);
            }

            SmtpClient client = new SmtpClient(mailServer);

            mail.Subject = pSubject;
            mail.Body = pMessage;

            client.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["domainUsername"], ConfigurationManager.AppSettings["domainPassword"], ConfigurationManager.AppSettings["domain"]);
            client.UseDefaultCredentials = true;

            client.Send(mail);
        }
        catch (Exception)
        {

        }
    }

    public static void SendEmail(string[] pTo, string pSubject, string pMessage, string pAttachedFile)
    {
        try
        {
            string mailServer = ConfigurationManager.AppSettings["Mail_Server"];
            string vMailFrom = ConfigurationManager.AppSettings["Mail_From"];

            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(vMailFrom);

            for (int i = 0; i < pTo.Length; i++)
            {
                mail.To.Add(pTo[i]);
            }

            SmtpClient client = new SmtpClient(mailServer);

            mail.Subject = pSubject;
            mail.Body = pMessage;
            mail.Attachments.Add(new Attachment(pAttachedFile, MediaTypeNames.Application.Octet));

            client.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["domainUsername"], ConfigurationManager.AppSettings["domainPassword"], ConfigurationManager.AppSettings["domain"]);
            client.UseDefaultCredentials = true;

            client.Send(mail);
        }
        catch (Exception)
        {

        }
    }

	public static void alertMessage(System.Web.UI.Page objPage,string msg){
        objPage.ClientScript.RegisterStartupScript(objPage.GetType(), "alert", "alert('"+ msg +"');", true);
    }

    public static void dialogMessage(System.Web.UI.Page objPage, string msg)
    {
        objPage.ClientScript.RegisterStartupScript(objPage.GetType(), "alert", "dialog_message('" + msg + "');", true);
    }

    public static void CreateTextFile(string filename,string pText) {
        string path = ConfigurationManager.AppSettings["FilePath"];
        string fullPath = path + filename;

        using (StreamWriter file = new StreamWriter(fullPath, false))
        {
            file.Write(pText);
        }     
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="input data"></param>
    /// <param name="date format"></param>
    public static bool ChkDateFormat(string data, string format)
    {
        DateTime date = new DateTime();
        if (DateTime.TryParseExact(data, format, new CultureInfo("en-US"), DateTimeStyles.None, out date))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public static bool EmailIsValid(string emailaddress)
    {
        try
        {
            MailAddress m = new MailAddress(emailaddress);

            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    public static void CallBatchFile(string filename) {
        string logonDB = ConfigurationManager.AppSettings["LogonDB"].ToString();
        string batchPath = ConfigurationManager.AppSettings["BatchPath"].ToString();

        var info = new System.Diagnostics.ProcessStartInfo();
        info.FileName = @batchPath + filename;
        var process = new System.Diagnostics.Process();
        process.StartInfo = info;
        process.StartInfo.Arguments = logonDB;
        process.Start();
        //Wait for the process to be completed
        process.WaitForExit();
        process.Close();
    }

    public static void SendEmailFrom(string pFrom, string[] pTo, string pSubject, string pMessage)
    {
        try
        {
            string mailServer = ConfigurationManager.AppSettings["Mail_Server"];
            string vMailFrom = pFrom;

            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(vMailFrom);

            for (int i = 0; i < pTo.Length; i++)
            {
                mail.To.Add(pTo[i]);
            }

            SmtpClient client = new SmtpClient(mailServer);

            mail.Subject = pSubject;
            mail.Body = pMessage;

            client.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["domainUsername"], ConfigurationManager.AppSettings["domainPassword"], ConfigurationManager.AppSettings["domain"]);
            client.UseDefaultCredentials = true;

            client.Send(mail);
        }
        catch (Exception)
        {

        }
    }

    public static bool ChkNumberDecimal(string strValue)
    {
        decimal n;
        Boolean result = decimal.TryParse(strValue, out n);
        return result;
    }

    public static bool ChkTimeFormatHHMM(string data)
    {
        DateTime time = new DateTime();
        if (DateTime.TryParseExact(data, "HH:mm", new CultureInfo("en-US"), DateTimeStyles.None, out time))
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    public static string GetErrMsg(string wk_errCode)
    {
		string DBLinkToPROD = ConfigurationManager.AppSettings["DBLinkToPROD"];
        string result = null;
        ExcuteModeServices ObjExSV = new ExcuteModeServices();
        StringBuilder sb = new StringBuilder();
        DataSet ds = new DataSet();

        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT ERROR_MESSAGE ,MESSAGE_TH,MESSAGE_EN FROM dosystem.ERROR_MESSAGE  WHERE ERROR_MESSAGE ='{0}'", wk_errCode.Trim());

        string ErrCd = null;
        string MsgTH = null;
        string MsgEN = null;

        try
        {
            ds = ObjExSV.ExecuteQuery(sb.ToString(), "ERROR_MESSAGE");
            ErrCd = ds.Tables[0].Rows[0]["ERROR_MESSAGE"].ToString();
            MsgTH = ds.Tables[0].Rows[0]["MESSAGE_TH"].ToString();
            MsgEN = ds.Tables[0].Rows[0]["MESSAGE_EN"].ToString();

            result = ErrCd + " : " + MsgTH + " : " + MsgEN;
        }
        catch (Exception ex)
        {
            result = ex.Message.ToString();
        }
        return result;
    }


 public static DataTable GetEnvironmentData(string vDATA_CODE, string vINPUT_DATA_1, string vINPUT_DATA_2, string vINPUT_DATA_3, string vINPUT_DATA_4, string vINPUT_DATA_5, string vINPUT_DATA_6, string vINPUT_DATA_7, string vINPUT_DATA_8, string vINPUT_DATA_9, string vINPUT_DATA_10)
    {
        
        DataSet ds1 = new DataSet();
        ExcuteModeServices ObjExSV = new ExcuteModeServices();
        StringBuilder sb = new StringBuilder();
        DataTable dt = new DataTable();

        sb.Remove(0, sb.Length);
          sb.AppendFormat("SELECT OUTPUT_DATA_1  , OUTPUT_DATA_2  ,OUTPUT_DATA_3  ,OUTPUT_DATA_4  ,OUTPUT_DATA_5  ,OUTPUT_DATA_6  ,OUTPUT_DATA_7  ");
         sb.AppendFormat(",OUTPUT_DATA_8  ,OUTPUT_DATA_9  ,OUTPUT_DATA_10  ");        
        sb.AppendFormat("FROM T_PRD_SISO_COMMON_DATA ");
        sb.AppendFormat("WHERE DATA_CODE =  '{0}' ", vDATA_CODE);
        if (vINPUT_DATA_1 != "") {
            sb.AppendFormat(" AND INPUT_DATA_1  =  '{0}' ", vINPUT_DATA_1);
        }
        if (vINPUT_DATA_2 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_2  =  '{0}' ", vINPUT_DATA_2);
        }
        if (vINPUT_DATA_3 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_3  =  '{0}' ", vINPUT_DATA_3);
        }
        if (vINPUT_DATA_4 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_4  =  '{0}' ", vINPUT_DATA_4);
        }
        if (vINPUT_DATA_5 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_5  =  '{0}' ", vINPUT_DATA_5);
        }
        if (vINPUT_DATA_6 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_6  =  '{0}' ", vINPUT_DATA_6);
        }
        if (vINPUT_DATA_7 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_7  =  '{0}' ", vINPUT_DATA_7);
        }
        if (vINPUT_DATA_8 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_8  =  '{0}' ", vINPUT_DATA_8);
        }
        if (vINPUT_DATA_9 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_9  =  '{0}' ", vINPUT_DATA_9);
        }
        if (vINPUT_DATA_10 != "")
        {
            sb.AppendFormat(" AND INPUT_DATA_10  =  '{0}' ", vINPUT_DATA_10);
        }
        dt = ObjExSV.ExecuteQuery(sb.ToString(), "T_DATA_TABLE").Tables[0];

        return dt;
    }
    
}








