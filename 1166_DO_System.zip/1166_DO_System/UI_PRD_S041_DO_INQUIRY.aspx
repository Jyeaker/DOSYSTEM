﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UI_PRD_S041_DO_INQUIRY.aspx.cs" Inherits="UI_PRD_S041_DO_INQUIRY" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <!-- Reference for Freeze Gridview -->
    <link href="js/GridViewScroll/GridviewScroll.css" rel="stylesheet" />
    <link href="js/GridViewScroll/GridviewCustomStyle.css" rel="stylesheet" />
     <%--jQuery v1.9.0 and jQuery UI - v1.9.1--%>
    <script src="js/GridViewScroll/jquery.min.js"></script>
    <script src="js/GridViewScroll/jquery-ui.min.js"></script>    
    <script src="js/GridViewScroll/gridviewScroll.min.js"></script>
    

    <style type="text/css">
        /*Ex. Custom css on gidview*/
        .CustomHearderGrid > th {
            background-color: #99ccff !important;
            height:40px !important;
            line-height:15px !important;                     
        }
                
        .CustomItemGrid > td {
            
        }
    </style>

    <script type="text/javascript">

        //Call Reference in this page only(gridviewScroll Require jQuery v1.9.0 and jQuery UI - v1.9.1)
        var $j = jQuery.noConflict();
        $j(document).ready(function () {
            //Fix header when rows more than 0 rows  
            if(document.getElementById("<%=gvShowData.ClientID %>"))
            {
                var grid = document.getElementById("<%=gvShowData.ClientID %>");
                if (grid.rows.length > 7) {
                    gridviewScroll();
                }
            }
            
        });

        function gridviewScroll() {
                $j('#<%=gvShowData.ClientID%>').gridviewScroll({
                width: screen.width - 60,
                height: 370,
                arrowsize: 30,
                varrowtopimg: "js/GridViewScroll/Images/arrowvt.png",
                varrowbottomimg: "/js/GridViewScroll/Images/arrowvb.png",
                harrowleftimg: "/js/GridViewScroll/Images/arrowhl.png",
                harrowrightimg: "/js/GridViewScroll/Images/arrowhr.png",
                headerrowcount: 1                 
                });            
        }



        function isNumberKey(evt, element) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
                return false;
            else {
                var len = $(element).val().length;
                var index = $(element).val().indexOf('.');
                if (index > 0 && charCode == 46) {
                    return false;
                }
                if (index > 0) {
                    var CharAfterdot = (len + 1) - index;
                    if (CharAfterdot > 3) {
                        return false;
                    }
                }

            }
            return true;
        }

        $(function () {
        $('#<%=txtDelivery_DateFrom.ClientID%>').datepicker({
            dateFormat: "yymmdd"
        });

        $('#<%=txtDelivery_DateTo.ClientID%>').datepicker({
            dateFormat: "yymmdd"
        });

        $('#<%=txtCalculation.ClientID%>').datepicker({
            dateFormat: "yymmdd"
        });      

        });
                
        
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <div id="showData">
    <div class="container" style="text-align: center;">
        <table class="table table-hover" style="width: 100%; text-align: center; color: #006bff;">
            <tr>
                <td style="text-align: right; vertical-align:middle; width:7%;">FACTORY : </td>
                <td style="text-align: left;  vertical-align:middle; width:5%;">
                    <asp:Label ID="lblFactory" runat="server" ForeColor="Blue" Font-Size="Medium" Font-Bold="True"></asp:Label>
                </td>
                <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">DIV KEY NO :</td>
                <td style="width: 15%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDelivery_Key" Height="28px" runat="server" MaxLength="30" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>
                <td style="width: 6%; text-align: right; margin-right: 1em; vertical-align: middle;">DIV LOCATION :</td>
                <td style="width: 15%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDelivery_Location" Height="28px" runat="server" MaxLength="20" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td> 
                
            </tr> 
            <tr>
                <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">USE BLOCK :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtBlock_Cd" Height="28px" runat="server" MaxLength="4" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>    
                <td style="width: 5%; text-align: right; margin-right: 1em; vertical-align: middle;">PRODUCTION DATE FROM :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDelivery_DateFrom" Height="28px" runat="server" MaxLength="10" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" placeholder="YYYYMMDD" ></asp:TextBox>
                </td>   
                <td style="width: 10%; text-align: right; margin-right: 1em; vertical-align: middle;">PRODUCTION DATE TO :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtDelivery_DateTo" Height="28px" runat="server" MaxLength="10" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" placeholder="YYYYMMDD" ></asp:TextBox>
                </td>  
                
            </tr> 
            <tr> 
                <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">RESULT :</td>
                <td style="width: 15%; text-align: left; margin-right: 1em; vertical-align: middle;" >
                    <asp:TextBox ID="txtResult" Height="28px" runat="server" MaxLength="100" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td>   

                   <td style="width: 7%; text-align: right; margin-right: 1em; vertical-align: middle;">DO LOGIC :</td>
                <td style="width: 15%; text-align: left; margin-right: 1em; vertical-align: middle;" >
                    <asp:TextBox ID="txtDOLogic" Height="28px" runat="server" MaxLength="100" Width="100%" Style="text-transform: uppercase; position: relative;" CssClass="form-control style_Font" ></asp:TextBox>
                </td> 
                  <td style="width: 10%; text-align: right; margin-right: 1em; vertical-align: middle;">CALCULATION DATE :</td>
                <td style="width: 10%; text-align: left; margin-right: 1em; vertical-align: middle;">
                    <asp:TextBox ID="txtCalculation" Height="28px" runat="server" MaxLength="10" Width="100%" Style="text-transform: uppercase;" CssClass="form-control style_Font" placeholder="YYYYMMDD" ></asp:TextBox>
                </td>  
            <tr>
                 <td style="height: 80%; width: 78%; text-align: left; margin-left: 1em; text-align: center;" colspan="8">
                    <asp:Button ID="btnSearch" runat="server" Text="SEARCH" CssClass="btn btn-primary" Width="15%" Style="display: inline-block;" OnClick="btnSearch_Click" />
                    <asp:Button ID="btnDownload" runat="server" Text="DOWNLOAD" CssClass="btn btn-info" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btn_dow_csv_Click"/>                    
                    <asp:Button ID="btnClear" runat="server" Text="CLEAR" class="btn btn-warning" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btnClear_Click" />
                    <asp:Button ID="btnExit" runat="server" Text="EXIT" CssClass="btn btn-danger" Width="15%" Style="display: inline-block; margin-left: 1em" OnClick="btnExit_Click" />

                </td> 
                             
            </tr>

        </table>
    </div>
    <%-- START : Gridview  --%>
    <div class="container" style="height: 380px; width: 100%; text-align: center; ">            
            <asp:Panel ID="pnlShowData" runat="server" class="panel panel-default" Height="100%"  Width="100%">
                <asp:GridView ID="gvShowData" runat="server" Width="100%" CssClass="table-bordered table-hover" Font-Size="Smaller" GridLines="None"
                    AutoGenerateColumns="false"
                    AllowPaging="true" PageSize="200" PagerSettings-Mode="NumericFirstLast"
                    PagerSettings-FirstPageText="First" PagerSettings-LastPageText="Last"
                    OnPageIndexChanging="gvShowData_PageIndexChanging">
                    <FooterStyle BackColor="#1C5E55" Font-Bold="True" ForeColor="White" />
                    <Columns>                        
                        <asp:BoundField HeaderText="DlV Key No" DataField="DELIVERY_KEY" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" >
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Req Delivery Date" DataField="DELIVERY_DATE" ItemStyle-HorizontalAlign="Center"  HeaderStyle-BackColor="#99ccff">
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Req Delivery Time" DataField="DELIVERY_TIME" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff">
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Delivery Order" DataField="DELIVERY_ORDER" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff"  >
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Delivery Location" DataField="DELIVERY_LOCATION" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" >
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Used Block Code" DataField="BLOCK_CD" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" >                        
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Inventory Code" DataField="INVENTORY_CODE" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" >
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="Approver" DataField="APPROVER" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" >
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>

                        <asp:BoundField HeaderText="DOLOGIC" DataField="LOGIC" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" > 
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>
                        
                        <asp:BoundField HeaderText="Resut" DataField="RESULT" ItemStyle-HorizontalAlign="Center" HeaderStyle-BackColor="#99ccff" > 
                        <HeaderStyle BackColor="#99CCFF" />
                        <ItemStyle HorizontalAlign="Center" />
                        </asp:BoundField>
                    </Columns>
                    <HeaderStyle BackColor="#99ccff" HorizontalAlign="Center" ForeColor="Black"  VerticalAlign="Middle" CssClass="headerGrid CustomHearderGrid" Wrap="False"/>
                    <PagerSettings FirstPageText="First" LastPageText="Last" Mode="NumericFirstLast" />
                    <PagerStyle CssClass="pagination-ys" />
                    <RowStyle Height="40px" Font-Size="11px" HorizontalAlign="Center" VerticalAlign="Middle" CssClass="ItemGrid"  Wrap="False"/>
                </asp:GridView>                        
            </asp:Panel>
        </div>
        <%-- END : Gridview  --%>

    </div>    
    
</asp:Content>
