﻿using System;
using System.Data;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;
using System.Configuration;
using System.Web;

/// <summary>
/// Summary description for CsvManagement
/// </summary>
public class CsvManagement
{
    public HttpPostedFile fileUpload { get; set; }
    public string filePath { get; set; }
    private NetworkCredential Credential;

    public void SetupCredential() 
    {
        if (Credential == null) {
            Credential = new NetworkCredential(ConfigurationManager.AppSettings["domainUsername"], ConfigurationManager.AppSettings["domainPassword"], ConfigurationManager.AppSettings["domain"]);
        }
    }

    public void ReturnCredential() 
    {
        Credential = null;
    }

	public void CsvFileUpload()
    {
		string file;
		try{
			string uploadFileName = fileUpload.FileName;
			Regex r = new Regex(@"\\(?:.+)\\(.+)\.(.+)");
			Match m = r.Match(uploadFileName); 
			string fileExt = m.Groups[2].Captures[0].ToString();
			string fileName = m.Groups[1].Captures[0].ToString();
			file = fileName + "." + fileExt;
		}
		catch(Exception)
		{
			file = fileUpload.FileName;
		}        

        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            try
            {
                fileUpload.SaveAs(ConfigurationManager.AppSettings["CsvPath"].ToString() + file);
            }
            catch (Exception)
            {
                ReturnCredential();
            }
            finally 
            {
                ImpersonateManager.undoImpersonation();
            }
        }
    }

    //delete file from folder
    public void CsvDeleteFile()
    {
        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            try
            {                
                File.Delete(filePath);
            }
            catch (Exception)
            {
                ReturnCredential();
            }
            finally
            {
                ImpersonateManager.undoImpersonation();
            }
        }
    }

    public DataTable CsvToDataTable(int NumberOfColumn) 
    {
		DataTable dt = new DataTable();
		
        string file;
		try{
			string uploadFileName = fileUpload.FileName;
			Regex r = new Regex(@"\\(?:.+)\\(.+)\.(.+)");
			Match m = r.Match(uploadFileName); 
			string fileExt = m.Groups[2].Captures[0].ToString();
			string fileName = m.Groups[1].Captures[0].ToString();
			file = fileName + "." + fileExt;
		}
		catch(Exception)
		{
			file = fileUpload.FileName;
		}

        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            StreamReader Sr = File.OpenText(ConfigurationManager.AppSettings["CsvPath"].ToString() + file);
            try
            {
                int rec = 1;
                while (Sr.EndOfStream == false) {
                    string strLine = Sr.ReadLine();
                    if (strLine.Trim() != "") { 
                        string[] strArray = strLine.Split(',');
                       
                        if (rec == 1) // Create Column
                        {
                            for (int i = 0; i < NumberOfColumn; i++)
                            {
                                dt.Columns.Add("COLUMN" + i);
                            }
                        }
                        dt.Rows.Add(strArray);
                        rec++;
                    }
                }

            }
            catch (Exception)
            {
                ReturnCredential();
                Sr.Close();
                Sr.Dispose();
            }
            finally
            {
                ImpersonateManager.undoImpersonation();
                Sr.Close();
                Sr.Dispose();
            }
        }
        return dt;
    }
	
	public DataTable CsvToDataTable(string columnName)
    {
		DataTable dt = new DataTable();
		
        string file;
		try{
			string uploadFileName = fileUpload.FileName;
			Regex r = new Regex(@"\\(?:.+)\\(.+)\.(.+)");
			Match m = r.Match(uploadFileName); 
			string fileExt = m.Groups[2].Captures[0].ToString();
			string fileName = m.Groups[1].Captures[0].ToString();
			file = fileName + "." + fileExt;
		}
		catch(Exception)
		{
			file = fileUpload.FileName;
		}

        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            StreamReader Sr = File.OpenText(ConfigurationManager.AppSettings["CsvPath"].ToString() + file);
            try
            {
                int rec = 1;
                while (Sr.EndOfStream == false)
                {
                    //string strLine = Sr.ReadLine().ToUpper();
                    string strLine = Sr.ReadLine();
                    if (strLine.Trim() != "")
                    {
                        string[] strArray = strLine.Split(',');
                        string[] ColumnName = columnName.Split(',');

                        if (rec == 1) // Create Column
                        {
                            for (int i = 0; i < ColumnName.Length; i++)
                            {   
                                dt.Columns.Add(ColumnName[i]);
                            }
                        }
                        dt.Rows.Add(strArray);
                        rec++;
                    }
                }            
            }
            catch (Exception)
            {
                ReturnCredential();
                Sr.Close();
                Sr.Dispose();
            }
            finally
            {
                ImpersonateManager.undoImpersonation();
                Sr.Close();
                Sr.Dispose();
            }
        }
        return dt;
    }

    public DataTable CsvHeaderToDataTable(string columnName)
    {
		DataTable dt = new DataTable();
		
        string file;
		try{
			string uploadFileName = fileUpload.FileName;
			Regex r = new Regex(@"\\(?:.+)\\(.+)\.(.+)");
			Match m = r.Match(uploadFileName); 
			string fileExt = m.Groups[2].Captures[0].ToString();
			string fileName = m.Groups[1].Captures[0].ToString();
			file = fileName + "." + fileExt;
		}
		catch(Exception)
		{
			file = fileUpload.FileName;
		}

        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            StreamReader Sr = File.OpenText(ConfigurationManager.AppSettings["CsvPath"].ToString() + file);
            try
            {
                int rec = 1;
                while (Sr.EndOfStream == false)
                {
                    //string strLine = Sr.ReadLine().ToUpper();
                    string strLine = Sr.ReadLine();
                    if (strLine.Trim() != "")
                    {
                        string[] strArray = strLine.Split(',');
                        string[] ColumnName;

                        if (rec == 1) // Create Column
                        {
                            if (columnName != "")
                            {
                                ColumnName = columnName.Split(',');
                            }
                            else
                            {
                                ColumnName = strArray;
                            }

                            for (int i = 0; i < ColumnName.Length; i++)
                            {
                                dt.Columns.Add(ColumnName[i]);
                            }
                        }
                        else {
                            dt.Rows.Add(strArray);           
                        }
                                       
                        rec++;
                    }
                }
            }
            catch (Exception)
            {
                ReturnCredential();
                Sr.Close();
                Sr.Dispose();
            }
            finally
            {
                ImpersonateManager.undoImpersonation();
                Sr.Close();
                Sr.Dispose();
            }
        }
        return dt;
    }

    public void ExportFormatCsv(string fileName, string column) 
    {
        HttpContext context = HttpContext.Current;
        context.Response.Clear();
        context.Response.Write(column);
        context.Response.ContentType = "text/csv";
        context.Response.AppendHeader("Content-disposition","attachment; filename=" + fileName + ".csv");
        context.Response.Flush();
        context.Response.End();
    }

    //function download file
    public void Downloadfile(string fileName, string Name)
    {
        HttpContext context = HttpContext.Current;
        filePath = fileName;

        string NameFile = Name;     
              
        SetupCredential();

        if (ImpersonateManager.impersonateValidUser(Credential.UserName, Credential.Domain, Credential.Password))
        {
            try
            {
                
                System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                response.ClearContent();
                response.Clear();
                response.ContentType = "text/plain";
                response.AddHeader("Content-Disposition", "attachment; filename=" + NameFile + ";");
                response.TransmitFile(filePath);
                response.Flush();
                response.End();
                
            }
            catch (Exception)
            {
                ReturnCredential();
            }
            finally
            {
                ImpersonateManager.undoImpersonation();
            }
        }

    }

    public void exportDataToCsv(DataTable dt, string fileName) 
    {
        HttpContext context = HttpContext.Current;
        context.Response.Clear();

        int count = 0;
        foreach (DataColumn column in dt.Columns) 
        {
            if (count == dt.Columns.Count - 1)
            {
                context.Response.Write(column.ColumnName);
            }
            else 
            {
                context.Response.Write(column.ColumnName + ",");
            }
            count++;
        }
        context.Response.Write(Environment.NewLine);

        foreach (DataRow row in dt.Rows) 
        {
            for (int i = 0; i <= dt.Columns.Count - 1; i++) 
            {
                if (i == dt.Columns.Count - 1)
                {
                    context.Response.Write(row[i].ToString().Replace(",", string.Empty));
                }
                else 
                {
                    context.Response.Write(row[i].ToString().Replace(",", string.Empty) + ",");
                }
                
            }
            context.Response.Write(Environment.NewLine);
        }
        context.Response.ContentType = "text/csv";
        context.Response.AppendHeader("Content-disposition", "attachment; filename=" + fileName + ".csv");
        context.Response.End();
    }
	
	
	public void exportDataToCsv_TH(DataTable dt, string fileName)
    {
        HttpContext context = HttpContext.Current;
        context.Response.Clear();
        context.Response.ContentEncoding = System.Text.Encoding.Default;

        int count = 0;
        foreach (DataColumn column in dt.Columns)
        {
            if (count == dt.Columns.Count - 1)
            {
                context.Response.Write(column.ColumnName);
            }
            else
            {
                context.Response.Write(column.ColumnName + ",");
            }
            count++;
        }
        context.Response.Write(Environment.NewLine);

        foreach (DataRow row in dt.Rows)
        {
            for (int i = 0; i <= dt.Columns.Count - 1; i++)
            {
                if (i == dt.Columns.Count - 1)
                {
                    context.Response.Write(row[i].ToString().Replace(",", string.Empty));
                }
                else
                {
                    context.Response.Write(row[i].ToString().Replace(",", string.Empty) + ",");
                }

            }
            context.Response.Write(Environment.NewLine);
        }
        context.Response.ContentType = "text/csv";
        context.Response.AppendHeader("Content-disposition", "attachment; filename=" + fileName + ".csv");
        context.Response.End();

    }
}