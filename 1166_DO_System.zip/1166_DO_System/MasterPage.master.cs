﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.IO;
using System.Configuration;

public partial class MasterPage : System.Web.UI.MasterPage
{
    //ExcuteModeServices obExSV = new ExcuteModeServices();
    StringBuilder sb = new StringBuilder();
    string username = string.Empty;
    string factory = string.Empty;
 


    protected void Page_Load(object sender, EventArgs e)
    {
        //string logingURL = ConfigurationManager.AppSettings["LogingPage"];
        //string currentPageFileName = new FileInfo(this.Request.Url.LocalPath).Name;
		
       if (!IsPostBack)
        {
			try{
                /*
				Session["USER_ID"] = Request.QueryString["USERNAME"].ToString();
				username = Request.QueryString["USERNAME"].ToString();
				*/
                username = "C027643";



            }
			 catch
            {
				this.lblErrorMsg.Text = "Please login again.";
                return;
			}

        }
        else {
			
			try{
                /*
				factory = Session["factory"].ToString();
				username = Session["USER_ID"].ToString();
                */
                username = "C027643";
            }
			 catch
            {
				this.lblErrorMsg.Text = "Please login again.";
                return;
			}
            
        }
      
    }
}
