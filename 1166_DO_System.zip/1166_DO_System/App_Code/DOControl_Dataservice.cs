﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.OracleClient;
using System.Configuration;
using System.Text;
using Npgsql;

public class DOControl_Dataservice
{
    /*
    OracleConnection Conn = new OracleConnection();
    OracleCommand Cmd = new OracleCommand();
    OracleDataAdapter Da = new OracleDataAdapter();

    private void ConnDB()
    {
        if (Conn.State == ConnectionState.Open)
        {
            Conn.Close();
        }
        else
        {
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            Conn.Open();
        }
    }
    */
    private NpgsqlConnection Conn;
    private void ConnDB()
    {
        if (Conn != null && Conn.State == ConnectionState.Open)
        {
            Conn.Close();
        }
        else
        {
            Conn = new NpgsqlConnection();
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            Conn.Open();
        }
    }
    private object GetDbValue(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return DBNull.Value;
        }

        value = value.Trim();

        if (value == "")
        {
            return DBNull.Value;
        }
        return value;
    }
    // START [ T_PRD_DO_DELIVERY_MASTER_DTO ] -- Add by Arpasiri
    public DataSet DO_DELIVERY_ROUND_MASTER_INQ(T_PRD_DO_DELIVERY_MASTER_DTO obj_DTO)
    {
        try
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            ConnDB();

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT * from dosystem.p_do_delivery_round_master_inq(@pfactory,@psullier_cd,@psullier_name,@peffect_date)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psullier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psullier_name", GetDbValue(obj_DTO.SUPPLIER_NAME.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@peffect_date", GetDbValue(obj_DTO.EFFECT_STA_DATE.ToUpper()));

            using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(objCmdPG))
            {
                adapter.Fill(ds);
            }

            return ds;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_DELIVERY_ROUND_MASTER_INS_UPD(T_PRD_DO_DELIVERY_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_delivery_round_master_ins_upd(@pfactory,@psullier_cd,@psullier_name,@peffect_date,@pvendor_fctry,@puser_id,@ptime_eta_1,@ptime_eta_2,@ptime_eta_3,@ptime_eta_4,@ptime_eta_5,@ptime_eta_6,@ptime_eta_7,@ptime_eta_8,@ptime_eta_9,@ptime_eta_10,@ptime_eta_11,@ptime_eta_12,@ptime_eta_13,@ptime_eta_14,@ptime_eta_15,@ptime_eta_16,@ptime_eta_17,@ptime_eta_18,@ptime_eta_19,@ptime_eta_20,@ptime_eta_21,@ptime_eta_22,@ptime_eta_23,@ptime_eta_24,@pflg_in_house)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psullier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psullier_name", GetDbValue(obj_DTO.SUPPLIER_NAME.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@peffect_date", GetDbValue(obj_DTO.EFFECT_STA_DATE.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pvendor_fctry", GetDbValue(obj_DTO.VENDOR_FCTRY.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_1", GetDbValue(obj_DTO.TIME_ETA_1.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_2", GetDbValue(obj_DTO.TIME_ETA_2.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_3", GetDbValue(obj_DTO.TIME_ETA_3.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_4", GetDbValue(obj_DTO.TIME_ETA_4.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_5", GetDbValue(obj_DTO.TIME_ETA_5.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_6", GetDbValue(obj_DTO.TIME_ETA_6.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_7", GetDbValue(obj_DTO.TIME_ETA_7.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_8", GetDbValue(obj_DTO.TIME_ETA_8.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_9", GetDbValue(obj_DTO.TIME_ETA_9.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_10", GetDbValue(obj_DTO.TIME_ETA_10.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_11", GetDbValue(obj_DTO.TIME_ETA_11.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_12", GetDbValue(obj_DTO.TIME_ETA_12.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_13", GetDbValue(obj_DTO.TIME_ETA_13.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_14", GetDbValue(obj_DTO.TIME_ETA_14.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_15", GetDbValue(obj_DTO.TIME_ETA_15.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_16", GetDbValue(obj_DTO.TIME_ETA_16.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_17", GetDbValue(obj_DTO.TIME_ETA_17.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_18", GetDbValue(obj_DTO.TIME_ETA_18.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_19", GetDbValue(obj_DTO.TIME_ETA_19.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_20", GetDbValue(obj_DTO.TIME_ETA_20.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_21", GetDbValue(obj_DTO.TIME_ETA_21.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_22", GetDbValue(obj_DTO.TIME_ETA_22.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_23", GetDbValue(obj_DTO.TIME_ETA_23.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptime_eta_24", GetDbValue(obj_DTO.TIME_ETA_24.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pflg_in_house", GetDbValue(obj_DTO.FLG_IN_HOUSE.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_DELIVERY_ROUND_MASTER_DEL(T_PRD_DO_DELIVERY_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_delivery_round_master_del(@pfactory,@psullier_cd,@peffect_date,@pvendor_fctry,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psullier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@peffect_date", GetDbValue(obj_DTO.EFFECT_STA_DATE.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pvendor_fctry", GetDbValue(obj_DTO.VENDOR_FCTRY.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }
    // END [ T_PRD_DO_DELIVERY_MASTER_DTO ] -- Add by Arpasiri

    // START [ T_PRD_DO_PART_MASTER_DTO ] -- Add by Arpasiri 20211113
    public DataSet DO_PART_MASTER_INQ(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {/*
        DataTable dt = new DataTable();
        ConnDB();
        try
        {
            DataSet ds = new DataSet();
            OracleCommand objCmd = new OracleCommand();
            objCmd.Connection = Conn;
            objCmd.CommandText = "PG_DO_SYSTEM.P_DO_PART_MASTER_INQ";
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.Add("pFactory_Cd", OracleType.VarChar, 2, "FACTORY").Value = obj_DTO.FACTORY_CD.ToUpper();
            objCmd.Parameters.Add("pPart_No", OracleType.VarChar, 12, "PART_NO").Value = obj_DTO.PART_NO.ToUpper();
            objCmd.Parameters.Add("pDim", OracleType.VarChar, 3, "DIM").Value = obj_DTO.DIM.ToUpper();
            objCmd.Parameters.Add("pBlock_Cd", OracleType.VarChar, 4, "BLOCK_CD").Value = obj_DTO.BLOCK_CD.ToUpper();
            objCmd.Parameters.Add("pSupplier_Cd", OracleType.VarChar, 4, "SUPPLIER_CD").Value = obj_DTO.SUPPLIER_CD.ToUpper();
            objCmd.Parameters.Add("pLogic", OracleType.VarChar, 4, "DO_LOGIC").Value = obj_DTO.DO_LOGIC.ToUpper();
            objCmd.Parameters.Add("pCURSOR", OracleType.Cursor).Direction = ParameterDirection.Output;
            OracleDataReader objReader = objCmd.ExecuteReader();
            if (objReader.HasRows)
            {
                dt = new DataTable();
                dt.Load(objReader);
                ds.Tables.Add(dt);
            }
            objReader.Close();
            return ds;
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();

        }
        */
        try
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            ConnDB();

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT * from dosystem.p_do_part_master_inq(@pfactory_cd,@ppart_no,@pdim,@pblock_cd,@psupplier_cd,@plogic)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ppart_no", GetDbValue(obj_DTO.PART_NO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdim", GetDbValue(obj_DTO.DIM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psupplier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@plogic", GetDbValue(obj_DTO.DO_LOGIC.ToUpper()));


            using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(objCmdPG))
            {
                adapter.Fill(ds);
            }

            return ds;

        }

        catch (Npgsql.NpgsqlException ex)
        {

            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }

    }

    public int DO_PART_MASTER_INS(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_part_master_ins(@pfactory_cd,@ppart_no,@pdim,@pblock_cd,@psupplier_cd,@ptotal_process_lt,@pdo_logic,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ppart_no", GetDbValue(obj_DTO.PART_NO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdim", GetDbValue(obj_DTO.DIM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psupplier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptotal_process_lt", Int16.Parse(obj_DTO.TOTAL_PROCESS_LT));
            objCmdPG.Parameters.AddWithValue("@pdo_logic", Int16.Parse(obj_DTO.DO_LOGIC));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_PART_MASTER_UPD(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_part_master_upd(@pfactory_cd,@ppart_no,@pdim,@pblock_cd,@psupplier_cd,@ptotal_process_lt,@pdo_logic,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ppart_no", GetDbValue(obj_DTO.PART_NO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdim", GetDbValue(obj_DTO.DIM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psupplier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ptotal_process_lt", Int32.Parse(obj_DTO.TOTAL_PROCESS_LT));
            objCmdPG.Parameters.AddWithValue("@pdo_logic", Int16.Parse(obj_DTO.DO_LOGIC));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_PART_MASTER_PLAN_SP_UPD(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_part_master_upd_plan_sp(@pfactory_cd,@psp_plan_slide,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psp_plan_slide", Int16.Parse(obj_DTO.SP_PLAN_SLIDE));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_PART_MASTER_LOGIC_UPD(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_part_master_upd_logic(@pfactory_cd,@plogic,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@plogic", Int16.Parse(obj_DTO.DO_LOGIC));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public int DO_PART_MASTER_DEL(T_PRD_DO_PART_MASTER_DTO obj_DTO)
    {
        ConnDB();
        try
        {
            int vCnt = 0;

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT dosystem.p_do_part_master_del(@pfactory_cd,@ppart_no,@pdim,@pblock_cd,@psupplier_cd,@puser_id)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@ppart_no", GetDbValue(obj_DTO.PART_NO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdim", GetDbValue(obj_DTO.DIM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@psupplier_cd", GetDbValue(obj_DTO.SUPPLIER_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@puser_id", GetDbValue(obj_DTO.USER_ID.ToUpper()));

            using (NpgsqlDataReader reader = objCmdPG.ExecuteReader())
            {
                if (reader.Read())
                {
                    vCnt = Convert.ToInt32(reader[0]);
                }
            }

            return vCnt;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    // END [ T_PRD_DO_PART_MASTER_DTO ] -- Add by Arpasiri

    // START [ T_PRD_DO_PART_MASTER_DTO ] -- Add by Arpasiri 20211113
    public DataSet DO_INQUIRY_INQ(T_PRD_DO_RESULT_DTO obj_DTO)
    {
        try
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            ConnDB();

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT * from dosystem.p_do_prd_result_inq(@pfactory_cd,@pdelivery_key,@pdelivery_location,@pblock_cd,@pdatefrom,@pdateto,@presult,@plogic,@pcalculation_date)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdelivery_key", GetDbValue(obj_DTO.DELIVERY_KEY.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdelivery_location", GetDbValue(obj_DTO.DELIVERY_LOCATION.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdatefrom", GetDbValue(obj_DTO.DELIVERY_DATEFROM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdateto", GetDbValue(obj_DTO.DELIVERY_DATETO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@presult", GetDbValue(obj_DTO.RESULT.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@plogic", GetDbValue(obj_DTO.DOLOGIC.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pcalculation_date", GetDbValue(obj_DTO.CALCULATION_DATE.ToUpper()));

            using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(objCmdPG))
            {
                adapter.Fill(ds);
            }

            return ds;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

    public DataSet DO_INQUIRY_INQ_EXPORT(T_PRD_DO_RESULT_DTO obj_DTO)
    {
        try
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            ConnDB();

            NpgsqlCommand objCmdPG = new NpgsqlCommand();
            objCmdPG.Connection = Conn;
            objCmdPG.CommandText = "SELECT * from dosystem.p_do_prd_result_inq_export(@pfactory_cd,@pdelivery_key,@pdelivery_location,@pblock_cd,@pdatefrom,@pdateto,@presult,@plogic,@pcalculation_date)";
            objCmdPG.CommandType = CommandType.Text;
            objCmdPG.Parameters.AddWithValue("@pfactory_cd", GetDbValue(obj_DTO.FACTORY_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdelivery_key", GetDbValue(obj_DTO.DELIVERY_KEY.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdelivery_location", GetDbValue(obj_DTO.DELIVERY_LOCATION.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pblock_cd", GetDbValue(obj_DTO.BLOCK_CD.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdatefrom", GetDbValue(obj_DTO.DELIVERY_DATEFROM.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pdateto", GetDbValue(obj_DTO.DELIVERY_DATETO.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@presult", GetDbValue(obj_DTO.RESULT.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@plogic", GetDbValue(obj_DTO.DOLOGIC.ToUpper()));
            objCmdPG.Parameters.AddWithValue("@pcalculation_date", GetDbValue(obj_DTO.CALCULATION_DATE.ToUpper()));

            using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(objCmdPG))
            {
                adapter.Fill(ds);
            }

            return ds;
        }
        catch (Npgsql.NpgsqlException ex)
        {
            throw new Exception("Database error: " + ex.Message, ex);
        }
        catch (InvalidOperationException ex)
        {
            throw new Exception("Invalid operation: " + ex.Message, ex);
        }
        catch (Exception ex)
        {
            throw new Exception("Unexpected error: " + ex.Message, ex);
        }
        finally
        {
            Conn.Dispose();
            Conn.Close();
        }
    }

}