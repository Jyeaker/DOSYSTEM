﻿/* Require : Include JQuery libary before call following function */

/*  Function    : dialog_message
    Description : Show dialog for message that you want.
    Condition   : 1. Receive a parameter of message.
*/
function dialog_message(msg) {
    $('body').append("<div id='dailogMsg' hidden='hidden' style='text-align:center;vertical-align:middle;margin-top:30px'><span>"+ msg +"</span></div>");
    $('#dailogMsg').dialog({
        buttons: [{
            text: "OK",
            click: function () {
                $('#dailogMsg').dialog('close');
                $('#dailogMsg').remove();
            }
        }],
        modal: true,
        height: 260,
        width: 480,
        title: "Message Box",
    });
}

/*  Function    : IsDecimal
    Description : Check input data is decimal belong condition.
    Condition   : 1. Receive 3 parameter of object , decimal length, digit length.
*/
function IsDecimal(obj, objPre, objScale) {

    var theValue = obj.value;
    oldValue = theValue;

    if (window.event.keyCode < 48 || window.event.keyCode > 57) {
        if (window.event.keyCode == 46) {
            var objValue = obj.value;

            if (objValue.indexOf(".") != -1 || objValue.length == 0) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    } else {
        var objValue = obj.value;
        if (objValue.indexOf(".") != -1) {
            theLength = objValue.substring(objValue.indexOf("."), objValue.length).length;
            thePre = objValue.indexOf(".")
            theScale = objValue.substring(objValue.indexOf("."), objValue.length).length;
            if (theScale > objScale) {
                return false;
            } else {
                return true;
            }
        } else {
            if (objValue.length > (objPre - objScale - 1)) {
                return false;
            } else {
                return true;
            }
        }

        return true;
    }
}

/*  Function    : Freeze Header Gridview 
    Description : Freeze Header of Gridview.
    Condition   : 1. Receive a parameter of object getElements of Gridview.
                  2. Receive a parameter of Gridview Height.
*/
function FreezeHeaderGrid(grid, GridHight) {

    var ScrollHeight = GridHight;
   
    var gridchk = (grid) ? grid : null;
    if (gridchk) {

        var gridWidth = grid.offsetWidth;
        var gridHeight = grid.offsetHeight;
        var headerCellWidths = new Array();
        for (var i = 0; i < grid.getElementsByTagName("TH").length; i++) {
            headerCellWidths[i] = grid.getElementsByTagName("TH")[i].offsetWidth;
        }

        grid.parentNode.appendChild(document.createElement("div"));

        var parentDiv = grid.parentNode;

        var table = document.createElement("table");

        for (i = 0; i < grid.attributes.length; i++) {
            if (grid.attributes[i].specified && grid.attributes[i].name != "id") {
                table.setAttribute(grid.attributes[i].name, grid.attributes[i].value);
            }
        }

        table.style.cssText = grid.style.cssText;
        table.style.width = gridWidth + "px";
        table.appendChild(document.createElement("tbody"));
        table.getElementsByTagName("tbody")[0].appendChild(grid.getElementsByTagName("TR")[0]);

        var cells = table.getElementsByTagName("TH");

        var gridRow = grid.getElementsByTagName("TR")[0];

        for (var i = 0; i < cells.length; i++) {

            var width;

            if (headerCellWidths[i] > gridRow.getElementsByTagName("TD")[i].offsetWidth) {
                width = headerCellWidths[i];
            }
            else {
                width = gridRow.getElementsByTagName("TD")[i].offsetWidth;
            }

            cells[i].style.width = parseInt(width - 3) + "px";
            gridRow.getElementsByTagName("TD")[i].style.width = parseInt(width - 3) + "px";
        }

        parentDiv.removeChild(grid);

        var dummyHeader = document.createElement("div");

        dummyHeader.appendChild(table);

        parentDiv.appendChild(dummyHeader);

        var scrollableDiv = document.createElement("div");

        if (parseInt(gridHeight) > ScrollHeight) {
            gridWidth = parseInt(gridWidth) + 17;
        }

        scrollableDiv.style.cssText = "margin-top:-20px;overflow:auto;height:" + ScrollHeight + "px;width:" + gridWidth + "px";
        scrollableDiv.appendChild(grid);
        parentDiv.appendChild(scrollableDiv);
    }    
}

/*  Function    : get_autocomplete_data
    Description : Request a column data in database to array
    Condition   : 1. Receive a parameter of related fieldname in web service
                  2. A column return need to be name as TARGET_DATA 
*/

function get_autocomplete_data(param, param1, handledata) {
    var arrList = [];
    $.ajax({
        type: 'POST',
        url: 'ajax/JSWebService.asmx/getAutocompleteData',
        data: '{fieldname : "' + param + '" , param1 : "' + param1 + '"}',
        contentType: 'application/json',
        dataType: 'text',
        async: false,
        success: function (response) {
            var strarr = response.split("}]");
            var str = strarr[0] + "}]";
            var obj = JSON.parse(str);

            for (var i = 0; i < obj.length; i++) {
                arrList[i] = obj[i].TARGET_DATA;
            }
            handledata(arrList);
        },
        error: function (xhr, status, error) {
            alert(xhr.responseText);
        }
    });
}


/*  Function    : get_autocomplete_data
    Description : Request a column data in database to array
    Condition   : 1. Receive a parameter of related fieldname in web service
                  2. A column return need to be name as TARGET_DATA 
*/

function get_dropdownlist_data(fieldname,param1,param2,param3,param4,handledata) {
    var arrList = [];
    $.ajax({
        type: 'POST',
        url: 'ajax/JSWebService.asmx/getDropdownListData',
        data: '{fieldname : "' + fieldname + '" , param1 : "' + param1 + '" , param2 : "' + param2 + '" , param3 : "' + param3 + '" , param4 : "' + param4 + '"}',
        contentType: 'application/json',
        dataType: 'text',
        async:false,
        success: function (response) {
            var strarr = response.split("}]");
            var str = strarr[0] + "}]";

            var obj = JSON.parse(str);
            for (var i = 0; i < obj.length; i++) {
                arrList[i] = obj[i].TARGET_DATA;
            }
            handledata(arrList);
        },
        error: function (xhr, status, error) {
            alert(xhr.responseText);
        }
    });
}

/*  Function    : get_database_data
    Description : Request data from data base and return to json
    Condition   : 1. Receive 4 parameter are following.
                    1) table name 
                    2) columns name (separate by comma) 
                    3) wherecause 
                    4) Your function to handle data
*/
function get_database_data(tablename, fieldname, condition,handledata) {

    var obj;
    var strdata = '{tablename : "' + tablename + '" , fieldname : "' + fieldname + '" , condition : "' + condition + '"}'

    $.ajax({
        type: 'POST',
        url: 'ajax/JSWebService.asmx/getDataFromDatabase',
        data: strdata,
        contentType: 'application/json',
        dataType: 'text',
        async: false,
        success: function (response) {
            var strarr = response.split("}]");

            if (strarr.length != 1) {
                var str = strarr[0] + "}]";
                obj = JSON.parse(str);
            }
            handledata(obj);

        },
        error: function (xhr, status, error) {
            alert(xhr.responseText);
        }
    });
}


/*  Function    : dialog_message
    Description : Show dialog for confirmation.
    Condition   : 1. Receive a parameter of message.
    Limitation  : Can't input single quote or double quote
*/
function confirm_dialog(type,inputmsg) {
    var reslut;
    var msg;
    switch (type) {
        case "INSERT":
            msg = "Do you really to add data?";
            break;
        case "UPDATE":
            msg = "Do you really to update data?";
        case "DELETE":
            msg = "Do you really to delete data?";
            break;
        case "INSERT_UPDATE":
            msg = "Do you really to insert/update data?";
            break;
        case "OTHER":
            msg = inputmsg;
    }
    
    if (confirm(msg) == true) {
        return true;
    } else {
        return false;
    }
}

/*  Function    : Freeze Header Gridview and Set div id
    Description : Freeze Header of Gridview and Set div id (can freeze multiple gridview in one page) 
    Condition   : 1. Receive a parameter of object getElements of Gridview.
                  2. Receive a parameter of Gridview Height.
                  3. Receive a parameter div id 
    How to use :
                $('#<%=GridviewID.ClientID %>').Scrollable({
                    ScrollHeight: 300,
                    divID: "Div1"
                });
*/
(function ($) {
    $.fn.Scrollable = function (options) {
        var defaults = {
            ScrollHeight: 300,
            Width: 0,
            divID: "div"
        };
        var options = $.extend(defaults, options);
        return this.each(function () {
            var grid = $(this).get(0);
            var gridWidth = grid.offsetWidth;
            var headerCellWidths = new Array();
            for (var i = 0; i < grid.getElementsByTagName("TH").length; i++) {
                headerCellWidths[i] = grid.getElementsByTagName("TH")[i].offsetWidth;
            }
            grid.parentNode.appendChild(document.createElement("div"));
            var parentDiv = grid.parentNode;

            var table = document.createElement("table");
            for (i = 0; i < grid.attributes.length; i++) {
                if (grid.attributes[i].specified && grid.attributes[i].name != "id") {
                    table.setAttribute(grid.attributes[i].name, grid.attributes[i].value);
                }
            }
            table.style.cssText = grid.style.cssText;
            table.style.width = gridWidth + "px";
            table.appendChild(document.createElement("tbody"));
            table.getElementsByTagName("tbody")[0].appendChild(grid.getElementsByTagName("TR")[0]);
            var cells = table.getElementsByTagName("TH");

            var gridRow = grid.getElementsByTagName("TR")[0];
            for (var i = 0; i < cells.length; i++) {
                var width;
                if (headerCellWidths[i] > gridRow.getElementsByTagName("TD")[i].offsetWidth) {
                    width = headerCellWidths[i];
                }
                else {
                    width = gridRow.getElementsByTagName("TD")[i].offsetWidth;
                }
                cells[i].style.width = parseInt(width - 3) + "px";
                gridRow.getElementsByTagName("TD")[i].style.width = parseInt(width - 3) + "px";
            }
            parentDiv.removeChild(grid);

            var dummyHeader = document.createElement("div");
            dummyHeader.appendChild(table);
            parentDiv.appendChild(dummyHeader);
            if (options.Width > 0) {
                gridWidth = options.Width;
            }
            var scrollableDiv = document.createElement("div");
            gridWidth = parseInt(gridWidth) + 17;
            scrollableDiv.style.cssText = "margin-top:-20px;overflow:auto;height:" + options.ScrollHeight + "px;width:" + gridWidth + "px";
            scrollableDiv.appendChild(grid);
            scrollableDiv.setAttribute("id", options.divID)
            parentDiv.appendChild(scrollableDiv);
        });
    };
})(jQuery);

/*  Function    : Find time interval in minute
    Description : Find time interval in minute by input start time and finish time in format HH:mm
    Condition   : 1. Receive two parameter of start time and finish time.
*/
function CalculateMin(pStartTime, pFinishTime) {
    
    var startArray = pStartTime.split(":");
    var EndArray = pFinishTime.split(":");

    var beginHour = parseFloat(startArray[0]);
    var beginMin = parseFloat(startArray[1]);
    var endHour = parseFloat(EndArray[0]);
    var endMin = parseFloat(EndArray[1]);
    var hourToMin = 0;
    var min = 0;
    var totalMin = 0;
    var diff = 0;

    if (endHour < beginHour) {
        diff = 24 - Math.abs(endHour - beginHour);
    } else if (endHour == beginHour && endMin < beginMin) {
        diff = 24 - Math.abs(endHour - beginHour);
    } else {
        diff = Math.abs(endHour - beginHour);
    }
    hourToMin = diff * 60;
    min = endMin - beginMin;
    totalMin = hourToMin + min;

    return totalMin;
}
