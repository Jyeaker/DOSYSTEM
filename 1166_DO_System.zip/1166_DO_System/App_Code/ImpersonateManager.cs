﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Security.Principal;
using System.Runtime.InteropServices;
/// <summary>
/// Summary description for ImpersonateManager
/// </summary>
public static class ImpersonateManager
{
    private static int LOGON32_LOGON_INTERACTIVE = 2;
    private static int LOGON32_PROVIDER_DEFAULT = 0;
    private static WindowsImpersonationContext impersonationContext;

    [DllImport("advapi32.dll")]
    public static extern int LogonUser(String ipszUsername,String ipszDomain, String ipszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);

    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern int DuplicateToken( IntPtr ExistingTokenHandle, int ImpersonationLevel, ref IntPtr DuplicateTokenHandle);

    [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern bool RevertToSelf();

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern long CloseHandle(IntPtr handle);

    public static bool impersonateValidUser(String userName, String doMain, String passWord) {
        WindowsIdentity tmpWindowsIdentity;
        IntPtr token = IntPtr.Zero;
        IntPtr tokenDuplicate = IntPtr.Zero;
        bool result = false;

        if(RevertToSelf())
        {
            if(LogonUser(userName, doMain, passWord, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, ref token) != 0 )
            {
                if(DuplicateToken(token,2,ref tokenDuplicate) != 0)
                {
                    tmpWindowsIdentity = new WindowsIdentity(tokenDuplicate);
                    impersonationContext = tmpWindowsIdentity.Impersonate();
                    if(impersonationContext != null){
                        result = true;
                    }
                }
            }
        }

        if(!tokenDuplicate.Equals(IntPtr.Zero))
        {
            CloseHandle(tokenDuplicate);
        }

        if (!token.Equals(IntPtr.Zero)) 
        {
            CloseHandle(token);
        }
        return result;
    }

    public static void undoImpersonation()
    {
        impersonationContext.Undo();
    }
}