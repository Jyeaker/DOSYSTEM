﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;


public partial class Default : System.Web.UI.Page
{
    string factory_cd;
    string dept_cd;
    string USERNAME;
    string Role_Id;

    protected void Page_Load(object sender, EventArgs e)
    {


        //if (Session["UserName"] != null)
        //{
        //    USER_ID = Session["UserName"].ToString().ToUpper();
        //    factory_cd = Session["factory_cd"].ToString().ToUpper();
        //    dept_cd = Session["dept_cd"].ToString().ToUpper();
        //    Role_Id = Session["Role_Id"].ToString().ToUpper();
        //}
       
        //Label lblVersion = (Label)Page.Master.FindControl("lblVersion");
        //lblVersion.Text = "20-V1.20200401";
        //Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        //lblFormName.Text = "MAIN MENU "   + USER_ID + factory_cd;

      
    //   Response.Redirect("UI_SISO_S038_Main_Menu.aspx?UserName=" + USER_ID + "&Role_Id=" + Role_Id);

        //Session["UserName"] =  Session["UserName"].ToString().ToUpper();
        //factory_cd = Session["factory_cd"].ToString().ToUpper();
        //dept_cd = Session["dept_cd"].ToString().ToUpper();
        //Role_Id = Session["Role_Id"].ToString().ToUpper();

    }

  
}