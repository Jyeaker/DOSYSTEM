<%@ webhandler language="VB" class="JavaScriptHandler" %>

Imports System.IO
Imports System
Imports System.Web


Public Class JavaScriptHandler
    Implements IHttpHandler
    
    Dim Request As HttpRequest
    Dim Response As HttpResponse

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return True
        End Get
    End Property
    

    Public Sub ProcessRequest(ByVal ctx As HttpContext) Implements IHttpHandler.ProcessRequest
 
        Request = HttpContext.Current.Request
        Response = HttpContext.Current.Response
        
        Dim jsName As String = ctx.Request.QueryString("jsname")
      
		If Not String.IsNullOrEmpty(jsName) Then
            
			Dim jsSourceCode As String = ""
            
			Dim path As String = HttpContext.Current.Server.MapPath("~/js/" + jsName + ".js")
            
			Dim fileSt As FileStream = New FileStream(path, FileMode.Open, FileAccess.Read)
			Dim sr As StreamReader = New StreamReader(fileSt)
			jsSourceCode = sr.ReadToEnd()
			sr.Close()
			fileSt.Close()

            'Natpaphat
            If (jsName.ToUpper().Equals("POPCALENDAR_EN")) Then
                jsSourceCode = jsSourceCode.Replace("WG0005", "\n" + CSUtilities.GetErrMsg("WG0005") + "\t\t")
            End If

			Response.Clear()
			Response.Write(jsSourceCode)
            
		End If
        
    End Sub
End Class