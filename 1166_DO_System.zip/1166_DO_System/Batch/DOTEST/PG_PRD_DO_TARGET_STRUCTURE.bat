REM #**********************************************************************
REM #    Project name   :   PG_PRD_DO_TARGET_STRUCTURE
REM #    START DATE     :   20220719 By Alisa
REM #    MIGRATE TO PG  :   PostgreSQL
REM #**********************************************************************

SET LOGPATH=d:\Log\DO\PG_PRD_DO_TARGET_STRUCTURE.log

echo %date%  %time%   * ----- JOB START ----- *   > %LOGPATH%
echo %date%  %time%   * ----- START DO TARGET STRUCTURE ----- *   >> %LOGPATH%

D:\PostgreSQL\17\bin\psql.exe -U dosystem -h chtsv0004 -p 5432 -d prod -c "SET statement_timeout = 0; SET work_mem = '512MB'; select dosystem.P_PRD_DO_TARGET_STRUCTURE();" >> %LOGPATH% 2>&1

echo %date%  %time%   * ----- JOB COMPLETE ----- *   >> %LOGPATH%
pause
EXIT

