﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;

public partial class UI_PRD_S041_DO_INQUIRY : System.Web.UI.Page
{
    public string factory { get; set; }
    public string username { get; set; }
    T_PRD_DO_RESULT_DTO objDTO = new T_PRD_DO_RESULT_DTO();
    ExcuteModeServices obEx = new ExcuteModeServices();
    DataTable dt_Query = new DataTable();
    StringBuilder sb = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        Label lblVersion = (Label)Page.Master.FindControl("lblVersion");
        lblVersion.Text = "22 - V2.20221106";
        username = Request.QueryString["username"];
        //username = "C025174";
        factory = Request.QueryString["FACTORY_CD"];
        //factory = "RA";
        this.lblFactory.Text = factory;
        lblFormName.Text = "DO INQUIRY  - " + factory;

        string key = factory;

        txtBlock_Cd.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'BLOCK_CD_DO','" + key + "');");
        txtBlock_Cd.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'BLOCK_CD_DO','" + key + "');");
        txtBlock_Cd.Attributes.Add("onblur", "destroy_autocomplete();");

        txtResult.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'RESULT_DO','" + key + "');");
        txtResult.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'RESULT_DO','" + key + "');");
        txtResult.Attributes.Add("onblur", "destroy_autocomplete();");

        txtDOLogic.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'DOLOGIC','" + key + "');");
        txtDOLogic.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'DOLOGIC','" + key + "');");
        txtDOLogic.Attributes.Add("onblur", "destroy_autocomplete();");

        if (Session["UserName"] != null)
        {
            //username = "C025174";
            username = Session["UserName"].ToString().ToUpper();
        }
    }
    #region "BindData"
    protected void BindData()
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataSet ds = new DataSet();

        try
        {
            int count_row = 0;

            this.objDTO.FACTORY_CD = lblFactory.Text.ToUpper();
            this.objDTO.DELIVERY_KEY = txtDelivery_Key.Text.ToUpper();
            this.objDTO.DELIVERY_DATEFROM = txtDelivery_DateFrom.Text.ToUpper();
            this.objDTO.DELIVERY_DATETO = txtDelivery_DateTo.Text.ToUpper();
            this.objDTO.BLOCK_CD = txtBlock_Cd.Text.ToUpper();
            this.objDTO.DELIVERY_LOCATION = txtDelivery_Location.Text.ToUpper();
            this.objDTO.RESULT = txtResult.Text.ToUpper();
            this.objDTO.DOLOGIC = txtDOLogic.Text.ToUpper();
            this.objDTO.CALCULATION_DATE = txtCalculation.Text.ToUpper();
            ds = objDTO.DO_INQUIRY_INQ();

            if (ds.Tables.Count > 0)
            {
                dt_Query = ds.Tables[0];
                count_row = dt_Query.Rows.Count;
                lblErrorMsg.Text = CSUtilities.GetErrMsg("IG0008") + " [Total :" + dt_Query.Rows.Count + " rec.]";

                this.gvShowData.DataSource = dt_Query;
                this.gvShowData.DataBind();
            }
            else
            {

                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0128"));
                gvShowData.DataSource = null;
                gvShowData.DataBind();
            }

        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();
        }
    }


    protected void Export()
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataSet ds = new DataSet();

        try
        {
            int count_row = 0;

            this.objDTO.FACTORY_CD = lblFactory.Text.ToUpper();
            this.objDTO.DELIVERY_KEY = txtDelivery_Key.Text.ToUpper();
            this.objDTO.DELIVERY_DATEFROM = txtDelivery_DateFrom.Text.ToUpper();
            this.objDTO.DELIVERY_DATETO = txtDelivery_DateTo.Text.ToUpper();
            this.objDTO.BLOCK_CD = txtBlock_Cd.Text.ToUpper();
            this.objDTO.DELIVERY_LOCATION = txtDelivery_Location.Text.ToUpper();
            this.objDTO.RESULT = txtResult.Text.ToUpper();
            this.objDTO.DOLOGIC = txtDOLogic.Text.ToUpper();
            this.objDTO.CALCULATION_DATE = txtCalculation.Text.ToUpper();
            ds = objDTO.DO_INQUIRY_INQ_EXPORT();

            if (ds.Tables.Count > 0)
            {
                dt_Query = ds.Tables[0];
                count_row = dt_Query.Rows.Count;

            }
            else
            {

                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0128"));

            }

        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();
        }
    }
    #endregion

    #region "SEARCH"
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtDelivery_DateFrom.Text != "" && txtDelivery_DateTo.Text == "")
        {            
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0016"));            
        }
        if (txtDelivery_DateFrom.Text == "" && txtDelivery_DateTo.Text != "")
        {            
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0015"));            
        }
        else
        {
            BindData();
        }
        
    }
    #endregion
    protected void btnClear_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";

        txtDelivery_Key.Text = "";
        txtDelivery_Location.Text = "";
        txtBlock_Cd.Text = "";
        txtDelivery_DateFrom.Text = "";
        txtDelivery_DateTo.Text = "";
        txtResult.Text = "";
        txtDOLogic.Text = "";
        txtCalculation.Text = "";
        gvShowData.DataSource = null;
        gvShowData.DataBind();
    }

    protected void btn_dow_csv_Click(object sender, EventArgs e)
    {
        try
        {
            Export();
            DataTable DT_CSV = new DataTable();
            DT_CSV = dt_Query;
            DT_CSV.Columns.Remove("FACTORY_CD");
            CsvManagement CsvManagement = new CsvManagement();
            CsvManagement.exportDataToCsv_TH(DT_CSV, "DO INQUIRY");
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "MessageError", "$('#ds_MessageError').show();", true);
        }
   
    }


    protected void gvShowData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvShowData.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("UI_PRD_S041_DO_Main_Menu1.aspx?&FACTORY_CD=" + factory + "&username=" + username);
    }
}