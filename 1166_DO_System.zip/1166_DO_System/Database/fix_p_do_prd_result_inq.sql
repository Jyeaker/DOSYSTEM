-- FIX: 42804 structure of query does not match function result type
-- เพิ่ม explicit cast ให้ตรงกับ RETURNS TABLE

CREATE OR REPLACE FUNCTION dosystem.p_do_prd_result_inq(
    pfactory_cd character varying,
    pdelivery_key character varying,
    pdelivery_location character varying,
    pblock_cd character varying,
    pdatefrom character varying,
    pdateto character varying,
    presult character varying,
    plogic character varying,
    pcalculation_date character varying
)
RETURNS TABLE(
    delivery_key character varying,
    delivery_date text,
    delivery_time character varying,
    delivery_order numeric,
    delivery_location character varying,
    block_cd character varying,
    inventory_code character varying,
    comment character varying,
    approver character varying,
    result text,
    factory_cd character varying,
    part_no character varying,
    dim character varying,
    supplier_cd character varying,
    ratio numeric,
    class character varying,
    logic smallint,
    update_date text
)
LANGUAGE plpgsql
AS $function$
DECLARE
    wk_select character varying := '';
    wk_where character varying := '';
    vwork_next VARCHAR(8) := '';
BEGIN

    IF pfactory_cd IS NOT NULL THEN
        wk_where := wk_where || ' AND a.factory_cd LIKE ' || quote_literal(pfactory_cd);
    END IF;

    IF pdelivery_key IS NOT NULL THEN
        wk_where := wk_where || ' AND a.delivery_key LIKE ' || quote_literal(pdelivery_key);
    END IF;

    IF pdelivery_location IS NOT NULL THEN
        wk_where := wk_where || ' AND a.delivery_location LIKE ' || quote_literal(pdelivery_location);
    END IF;

    IF pblock_cd IS NOT NULL THEN
        wk_where := wk_where || ' AND a.block_cd LIKE ' || quote_literal(pblock_cd);
    END IF;

    IF presult IS NOT NULL THEN
        wk_where := wk_where || ' AND SUBSTR(a.result, 1, 6) LIKE ' || quote_literal(presult);
    END IF;

    IF plogic IS NOT NULL THEN
        wk_where := wk_where || ' AND a.logic::text LIKE ' || quote_literal(plogic);
    END IF;

    IF pcalculation_date IS NOT NULL THEN
        wk_where := wk_where || ' AND TO_CHAR(a.update_date, ''YYYYMMDD'') LIKE ' || quote_literal(pcalculation_date);
    END IF;

    IF pdatefrom IS NOT NULL AND pdateto IS NOT NULL THEN
        SELECT TO_CHAR(TO_DATE(pdateto, 'YYYYMMDD') + INTERVAL '1 day', 'YYYYMMDD')
        INTO vwork_next;

        wk_where := wk_where || ' AND a.delivery_date || a.delivery_time BETWEEN ' ||
                    quote_literal(pdatefrom) || ' || ''0800'' AND ' ||
                    quote_literal(vwork_next) || ' || ''0800''';
    END IF;

    IF wk_where IS NOT NULL THEN
        wk_where := ' WHERE ' || SUBSTR(wk_where, 5);
    END IF;

    wk_select :=
        'SELECT delivery_key::character varying, ' ||
        'delivery_date::text, ' ||
        'delivery_time::character varying, ' ||
        'SUM(delivery_order)::numeric AS delivery_order, ' ||
        'delivery_location::character varying, ' ||
        'block_cd::character varying, ' ||
        'inventory_code::character varying, ' ||
        'comment::character varying, ' ||
        'approver::character varying, ' ||
        'result::text, ' ||
        'factory_cd::character varying, ' ||
        'part_no::character varying, ' ||
        'dim::character varying, ' ||
        'supplier_cd::character varying, ' ||
        'ratio::numeric, ' ||
        'class::character varying, ' ||
        'logic::smallint, ' ||
        'a.update_date::text ' ||
        'FROM ( ' ||
        '    SELECT ' ||
        '        delivery_key, ' ||
        '        CASE WHEN delivery_date IS NULL THEN NULL ' ||
        '             ELSE SUBSTR(delivery_date, 1, 4) || ''/'' || SUBSTR(delivery_date, 5, 2) || ''/'' || SUBSTR(delivery_date, 7, 2) ' ||
        '        END AS delivery_date, ' ||
        '        delivery_time, delivery_order, delivery_location, block_cd, inventory_code, comment, approver, ' ||
        '        CASE WHEN b.message_en IS NULL THEN a.result ' ||
        '             ELSE a.result || '' : '' || b.message_en ' ||
        '        END AS result, ' ||
        '        factory_cd, part_no, dim, supplier_cd, ratio, class, logic, ' ||
        '        TO_CHAR(a.update_date, ''YYYYMMDD'') AS update_date ' ||
        '    FROM dosystem.t_prd_do_result a ' ||
        '    LEFT JOIN dosystem.error_message b ON a.result = b.error_message ' ||
        wk_where ||
        ') a ' ||
        'GROUP BY delivery_key, delivery_date, delivery_time, delivery_location, block_cd, ' ||
        'inventory_code, comment, approver, result, factory_cd, part_no, dim, supplier_cd, ' ||
        'ratio, class, logic, update_date ' ||
        'ORDER BY delivery_key, delivery_date, delivery_time';

    RETURN QUERY EXECUTE wk_select;

END;
$function$;

ALTER FUNCTION dosystem.p_do_prd_result_inq(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying)
    OWNER TO dosystem;
