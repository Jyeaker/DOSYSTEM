﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using Npgsql; 


public class ExcuteModeServices
{
    private string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    enum ExecuteMode { ExecuteScalar, ExecuteTable, ExecuteNonQuery };

    private NpgsqlConnection GetConnection()
    {
        NpgsqlConnection conn = new NpgsqlConnection(connectionString);
        conn.Open();
        return conn;
    }

    private Object ExcuteSQL(string sql, ExecuteMode exeMode)
    {
        object result = null;

        using (NpgsqlConnection conn = GetConnection())
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand(sql, conn))
            {
                try
                {
                    if (exeMode.Equals(ExecuteMode.ExecuteScalar))
                    {
                        result = cmd.ExecuteScalar();
                    }
                    else if (exeMode.Equals(ExecuteMode.ExecuteTable))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);
                            result = dt;
                        }
                    }
                    else if (exeMode.Equals(ExecuteMode.ExecuteNonQuery))
                    {
                        using (NpgsqlTransaction tranx = conn.BeginTransaction())
                        {
                            cmd.Transaction = tranx;
                            try
                            {
                                result = cmd.ExecuteNonQuery();
                                tranx.Commit();
                            }
                            catch (Exception ex)
                            {
                                tranx.Rollback();
                                throw ex;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        } 
        return result;
    }

    public Int32 ExecuteNonQuery(string sql)
    {
        object res = ExcuteSQL(sql, ExecuteMode.ExecuteNonQuery);
        return res != null ? Convert.ToInt32(res) : 0;
    }

    public object ExecuteScalar(string sql)
    {
        return ExcuteSQL(sql, ExecuteMode.ExecuteScalar);
    }

    public DataSet ExecuteQuery(string sql, string tablename)
    {
        DataSet ds = new DataSet();
        DataTable dt = (DataTable)ExcuteSQL(sql, ExecuteMode.ExecuteTable);
        if (dt != null)
        {
            dt.TableName = tablename;
            ds.Tables.Add(dt);
        }
        return ds;
    }
}