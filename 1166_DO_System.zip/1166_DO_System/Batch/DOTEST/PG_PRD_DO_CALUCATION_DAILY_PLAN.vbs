
Set objMessage = CreateObject("CDO.Message") 'Support_Change_Domain'
objMessage.Subject = "DO SYSTEM  : CALUCATION DAILY COMPLETE STEP MAKE PLAN" 'Support_Change_Domain'
objMessage.From = "PRODTEST@MAIL.CANON" 'Support_Change_Domain'
objMessage.To = "alisa@MAIL.CANON"'Support_Change_Domain'
objMessage.TextBody = "Calculation DO system step 1 (Make plan) Completed  of "  & Day(Date) & " " & MonthName(Month(Date),True) & " " & Year(Date) & vbCRLF & ""

objMessage.AddAttachment ("D:\ICS\Log\DOTEST\PG_PRD_DO_CALUCATION_DAILY_PLAN.log")

'==This section provides the configuration information for the remote SMTP server.
'==Normally you will only change the server name or IP.
objMessage.Configuration.Fields.Item _
("http://schemas.microsoft.com/cdo/configuration/sendusing") = 2 

'Name or IP of Remote SMTP Server
objMessage.Configuration.Fields.Item _
("http://schemas.microsoft.com/cdo/configuration/smtpserver") = "nonauth-smtp.global.canon.co.jp"'Support_Change_Domain'

'Server port (typically 25)
objMessage.Configuration.Fields.Item _
("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = 25 

objMessage.Configuration.Fields.Update

'==End remote SMTP server configuration section==

objMessage.Send
