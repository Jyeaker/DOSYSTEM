﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="UI_PRD_S041_DO_Main_Menu1.aspx.cs" Inherits="UI_PRD_S041_DO_Main_Menu1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
       <!-- Reference for Freeze Gridview -->
    <link href="js/GridViewScroll/GridviewScroll.css" rel="stylesheet" />
    <link href="js/GridViewScroll/GridviewCustomStyle.css" rel="stylesheet" />
     <%--jQuery v1.9.0 and jQuery UI - v1.9.1--%>
    <script src="js/GridViewScroll/jquery.min.js"></script>
    <script src="js/GridViewScroll/jquery-ui.min.js"></script>    
    <script src="js/GridViewScroll/gridviewScroll.min.js"></script>
    <style>
        body {
            /* background-color:darkcyan;*/
            /*  background-image: url(images/Pic01.jpg);*/
        }
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container" style="text-align: center;">
        <center>
          <table  style="width:60%; text-align: center; color: #000000; ">
               <tr>
                    <td style="width: 10%; text-align: left; font-size: 15px;">
                       <b> MASTER</b>
                    </td>
               </tr>

               <tr>
                   <td style="width: 5%"></td>
                    <td style="width: 100%; text-align: left; font-size: 15px;">
                        <asp:LinkButton runat="server" OnClick="btnPART_MASTER"><h5>1.PART MASTER MAINTENANCE</h5></asp:LinkButton>
                    </td>
               </tr>
               <tr>
                    <td style="width: 5%"></td>
                    <td style="width: 100%; text-align: left; font-size: 15px;">
                          <asp:LinkButton runat="server" OnClick="btnDELIVERY_ROUND"><h5>2.DELIVERY ROUND MASTER MAINTENANCE</h5></asp:LinkButton>
                    </td>
               </tr>
                </table>
            <br />

             <table  style="width:60%; text-align: center; color: #000000;">
               <tr>
                <td style="width: 10%; text-align: left; font-size: 15px;">
                    <b> INQUIRY</b>
                </td>
               </tr>
               <tr>
                    <td style="width: 5%"></td>
                    <td style="width: 100%; text-align: left; font-size: 15px;">
                         <asp:LinkButton runat="server" OnClick="btnDO_INQUIRY"><h5>1.DO INQUIRY</h5></asp:LinkButton>
                    </td>
               </tr>
             </table>
             </center>
          <br />
        <center>
            <img src="images/Do02.png" width="400" height="400" />
        </center>
    </div>


</asp:Content>
