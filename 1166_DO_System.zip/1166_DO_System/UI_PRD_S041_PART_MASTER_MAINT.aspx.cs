﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

public partial class UI_PRD_S041_PART_MASTER_MAINT : System.Web.UI.Page
{
    public string factory { get; set; }
    public string username { get; set; }
    T_PRD_DO_PART_MASTER_DTO objDTO = new T_PRD_DO_PART_MASTER_DTO();
    ExcuteModeServices obEx = new ExcuteModeServices();
    DataTable dt_Query = new DataTable();
    StringBuilder sb = new StringBuilder();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblFormName = (Label)Page.Master.FindControl("lblFormName");
        Label lblVersion = (Label)Page.Master.FindControl("lblVersion");
        lblVersion.Text = "22 - V2.20221116";

        //username = Request.QueryString["username"];
        username = "C027643";
        factory = Request.QueryString["FACTORY_CD"];
        //factory = "HT";

        this.hdnFactory.Value = factory;
        this.hdnUserId.Value = username;
        lblFormName.Text = "PART MASTER MAINTENANCE  - " + factory;

        string key = factory;
        txtPartNo.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'PART_NO','" + key + "');");
        txtPartNo.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'PART_NO','" + key + "');");
        txtPartNo.Attributes.Add("onblur", "destroy_autocomplete();");

        txtUseBlock.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'BLOCK_CD','" + key + "');");
        txtUseBlock.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'BLOCK_CD','" + key + "');");
        txtUseBlock.Attributes.Add("onblur", "destroy_autocomplete();");

        txtSupplierCD.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'SUPPLIER_CD_2','" + key + "');");
        txtSupplierCD.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'SUPPLIER_CD_2','" + key + "');");
        txtSupplierCD.Attributes.Add("onblur", "destroy_autocomplete();");

        //add by chayanon 20221004
        txtDogic.Attributes.Add("onfocus", "run_autocomplete_SISO(this,'DO_LOGIC','" + key + "');");
        txtDogic.Attributes.Add("onkeyup", "run_autocomplete_SISO(this,'DO_LOGIC','" + key + "');");
        txtDogic.Attributes.Add("onblur", "destroy_autocomplete();");
        //fn chayanon





        if (Session["UserName"] != null)
        {
            username = "C027643";
            //username = Session["UserName"].ToString().ToUpper();
        }

        //get sp_plan_slide 20221006 CN
        getSP_Plan_Slide(this.hdnFactory.Value);
        //get logic
        getLogic(this.hdnFactory.Value);

    }

    protected void getSP_Plan_Slide(string factory)
    {
        DataTable dt1;

        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT DISTINCT SP_PLAN_SLIDE FROM dosystem.t_prd_do_part_master");
        sb.AppendFormat(" WHERE  FACTORY_CD = '{0}'", factory);
        dt1 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];

        if (dt1.Rows.Count > 0)
        {
            this.hdnSP_PLAN_SLIDE.Value = dt1.Rows[0]["SP_PLAN_SLIDE"].ToString();
        }
    }

    protected void getLogic(string factory)
    {
        DataTable dt1;

        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT DISTINCT LOGIC FROM dosystem.t_prd_do_part_master");
        sb.AppendFormat(" WHERE  FACTORY_CD = '{0}'", factory);
        dt1 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];

        if (dt1.Rows.Count > 0)
        {
            this.hdnLOGIC.Value = dt1.Rows[0]["LOGIC"].ToString();
        }
    }





    #region "BindData"
    protected void BindData()
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataSet ds = new DataSet();

        try
        {
            int count_row = 0;

            this.objDTO.FACTORY_CD = factory;
            this.objDTO.PART_NO = txtPartNo.Text.ToUpper();
            this.objDTO.DIM = txtDIM.Text.ToUpper();
            this.objDTO.BLOCK_CD = txtUseBlock.Text.ToUpper();
            this.objDTO.SUPPLIER_CD = txtSupplierCD.Text.ToUpper();
            this.objDTO.DO_LOGIC = txtDogic.Text.ToUpper();
            ds = objDTO.DO_PART_MASTER_INQ();

            if (ds.Tables.Count > 0)
            {
                dt_Query = ds.Tables[0];
                count_row = dt_Query.Rows.Count;
                lblErrorMsg.Text = CSUtilities.GetErrMsg("IG0008") + " [Total :" + dt_Query.Rows.Count + " rec.]";

                this.gvShowData.DataSource = dt_Query;
                this.gvShowData.DataBind();
            }
            else
            {

                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WL0128"));
                gvShowData.DataSource = null;
                gvShowData.DataBind();
            }

        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();
        }
    }
    #endregion

    #region "SEARCH"
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BindData();
    }
    #endregion

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";

        txtSupplierCD.Text = "";
        txtPartNo.Text = "";
        txtDIM.Text = "";
        txtUseBlock.Text = "";
        txtDogic.Text = "";
        txtSupplierCD.Text = "";

        gvShowData.DataSource = null;
        gvShowData.DataBind();
    }

    protected void btn_dow_csv_Click(object sender, EventArgs e)
    {
        try
        {
            BindData();
            DataTable DT_CSV = new DataTable();
            DT_CSV = dt_Query;
            DT_CSV.Columns.Remove("UPDATE_DATE");
            DT_CSV.Columns.Remove("CREATE_DATE");

            CsvManagement CsvManagement = new CsvManagement();
            CsvManagement.exportDataToCsv_TH(DT_CSV, "PART MASTER MAINTENANCE");
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "MessageError", "$('#ds_MessageError').show();", true);
        }
    }

    #region "Web Method"
    [WebMethod]
    public static string Update_SP_Plan_Slide(string pFac, string pUser, string pSP_Plan_Slide)
    {
        StringBuilder sb = new StringBuilder();
        ExcuteModeServices obEx = new ExcuteModeServices();
        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row = new Dictionary<string, object>();
        DataTable dt1 = new DataTable();
        T_PRD_DO_PART_MASTER_DTO objDTO = new T_PRD_DO_PART_MASTER_DTO();
       
       
        int vCntRow = 0;

        if (pSP_Plan_Slide == "" || pSP_Plan_Slide.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (!(Regex.IsMatch(pSP_Plan_Slide, @"^\d+$")))
        {
            row.Add("RESULT", "กรุณาระบุข้อมูลเป็นตัวเลข"); ;
            goto FINISH;
        }


        if (pSP_Plan_Slide.Length > 2)
        {
            row.Add("RESULT", "กรุณาระบุข้อมูล Special Plan Slide 2 ตัวอักษร"); ;
            goto FINISH;
        }

        int Int_pSP_Plan_Slide = Int32.Parse(pSP_Plan_Slide);

        if (Int_pSP_Plan_Slide > 16 )
        {
            row.Add("RESULT", "กรุณาระบุข้อมูล Special Plan Slide <= 16 hr."); ;
            goto FINISH;
        }

        try
        {
            int vFlag = 0;



            objDTO.FACTORY_CD = pFac.ToString().Trim().ToUpper();
            objDTO.SP_PLAN_SLIDE = pSP_Plan_Slide;
            objDTO.USER_ID = pUser;

            vFlag = objDTO.DO_PART_MASTER_PLAN_SP_UPD();

            if (vFlag == 1)
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("IG0004"));
            }
            else
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("WL0001"));
            }



        }
        catch (Exception ex)
        {

            row.Add("RESULT", ex.Message.ToString());
        }




    
        FINISH:
        rows.Add(row);
        return JSSerializer.Serialize(rows);
    }

    #endregion

    #region "Web Method - Update Logic"
    [WebMethod]
    public static string Update_Logic(string pFac, string pUser, string pLogic)
    {
        StringBuilder sb = new StringBuilder();
        ExcuteModeServices obEx = new ExcuteModeServices();
        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row = new Dictionary<string, object>();
        DataTable dt1 = new DataTable();
        T_PRD_DO_PART_MASTER_DTO objDTO = new T_PRD_DO_PART_MASTER_DTO();


        int vCntRow = 0;

        if (pLogic == "" || pLogic.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (!(Regex.IsMatch(pLogic, @"^\d+$")))
        {
            row.Add("RESULT", "กรุณาระบุข้อมูลเป็นตัวเลข");
            goto FINISH;
        }

        if (pLogic != "1" && pLogic != "2" && pLogic != "3")
        {
            row.Add("RESULT", "กรุณาระบุ DO LOGIC = 1, 2 หรือ 3");
            goto FINISH;
        }

        try
        {
            int vFlag = 0;

            objDTO.FACTORY_CD = pFac.ToString().Trim().ToUpper();
            objDTO.DO_LOGIC = pLogic;
            objDTO.USER_ID = pUser;

            vFlag = objDTO.DO_PART_MASTER_LOGIC_UPD();

            if (vFlag == 1)
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("IG0004"));
            }
            else
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("WL0001"));
            }

        }
        catch (Exception ex)
        {

            row.Add("RESULT", ex.Message.ToString());
        }


    FINISH:
        rows.Add(row);
        return JSSerializer.Serialize(rows);
    }

    #endregion

    #region "Web Method"
    [WebMethod]
    public static string AddNew(string pFac, string pPartNo, string pDim, string pUseBlock, string pSupplierCD, string pUser, string pTotal_Process_Lt,string pDoLogic)
    {
        StringBuilder sb = new StringBuilder();
        ExcuteModeServices obEx = new ExcuteModeServices();
        JavaScriptSerializer JSSerializer = new JavaScriptSerializer();
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row = new Dictionary<string, object>();        
        DataTable dt1 = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable dt3 = new DataTable();
        T_PRD_DO_PART_MASTER_DTO objDTO = new T_PRD_DO_PART_MASTER_DTO();

        //Check null
        if (pPartNo == "" || pPartNo.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (pDim == "" || pDim.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (pUseBlock == "" || pUseBlock.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (pSupplierCD == "" || pSupplierCD.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        if (pTotal_Process_Lt == "" || pTotal_Process_Lt.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }
        // add do logic 20221005
        if (pDoLogic == "" || pDoLogic.ToUpper() == "UNDEFINED")
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("WG0001"));
            goto FINISH;
        }

        //Check dupplicate data
        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT * FROM dosystem.T_PRD_DO_PART_MASTER ");
        sb.AppendFormat(" WHERE FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}' AND BLOCK_CD = '{3}' AND SUPPLIER_CD = '{4}' ", pFac, pPartNo, pDim, pUseBlock, pSupplierCD);
        dt1 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];

        if (dt1.Rows.Count > 0)
        {
            row.Add("RESULT", CSUtilities.GetErrMsg("SG0001"));
            goto FINISH;
        }


        // add TOTAL_PROCESS_LT  20221005
        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT DISTINCT TOTAL_PROCESS_LT FROM dosystem.T_PRD_DO_PART_MASTER ");
        sb.AppendFormat(" WHERE  FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}'  ", pFac, pPartNo, pDim);
        dt2 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];
        string TOTAL_PROCESS_LT_CHK = null;


        if (dt2.Rows.Count > 0)
        {
            TOTAL_PROCESS_LT_CHK = dt2.Rows[0]["TOTAL_PROCESS_LT"].ToString();

            if (TOTAL_PROCESS_LT_CHK != pTotal_Process_Lt.ToString())
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("WF0024"));
                goto FINISH;
            }
        }



        // add do logic 20221005
        sb.Remove(0, sb.Length);
        sb.AppendFormat("SELECT DISTINCT LOGIC FROM dosystem.T_PRD_DO_PART_MASTER ");
        sb.AppendFormat(" WHERE  FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}'  ", pFac, pPartNo, pDim );
        dt3 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];
        string LOGIC_CHK = null;


        if (dt2.Rows.Count > 0) {
            LOGIC_CHK = dt3.Rows[0]["LOGIC"].ToString();

            if (LOGIC_CHK != pDoLogic.ToString())
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("WF0023"));
                goto FINISH;
            }
        }

           



        try
        {
            int vFlag;

            objDTO.FACTORY_CD = pFac.Trim();
            objDTO.PART_NO = pPartNo.Trim();
            objDTO.DIM = pDim.Trim();
            objDTO.BLOCK_CD = pUseBlock.Trim();
            objDTO.SUPPLIER_CD = pSupplierCD.Trim();
            objDTO.TOTAL_PROCESS_LT = pTotal_Process_Lt.Trim();
            objDTO.DO_LOGIC = pDoLogic.Trim();
            objDTO.USER_ID = pUser;
            vFlag = objDTO.DO_PART_MASTER_INS();

            if (vFlag == 1)
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("IG0004"));
            }
            else
            {
                row.Add("RESULT", CSUtilities.GetErrMsg("WL0001"));
            }

        }
        catch (Exception ex)
        {

            row.Add("RESULT", ex.Message.ToString());
        }

    FINISH:
        rows.Add(row);
        return JSSerializer.Serialize(rows);
    }
    #endregion


    protected void btnUpload_Click(object sender, EventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        DataTable dt = new DataTable();

        if (this.fluUpload.HasFile == true)
        {
            if (Path.GetExtension(this.fluUpload.FileName).ToUpper() != ".CSV")
            {
                CSUtilities.dialogMessage(this, "Please upload in CSV format.");
            }
            else
            {
                try
                {
                    CsvManagement CsvManage = new CsvManagement();
                    CsvManage.fileUpload = this.fluUpload.PostedFile;
                    CsvManage.CsvFileUpload();

                    sb.Remove(0, sb.Length);
                    sb.Append("PART_NO,DIM,BLOCK_CD,SUPPLIER_CD,TOTAL_PROCESS_LT,DO_LOGIC");

                    dt = CsvManage.CsvHeaderToDataTable(sb.ToString());

                    if (ChKDetailBeforeUpload(dt))
                    {
                        UploadToDB(dt);

                    }
                }
                catch (Exception ex)
                {
                    lblErrorMsg.Text = ex.Message.ToString();
                }
                BindData();
            }
        }
        else
        {
            CSUtilities.dialogMessage(this, "Please select file to upload.");
        }
    }
    protected bool ChKDetailBeforeUpload(DataTable chkDT)
    {
        Label lblErrMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrMsg.Text = "";
        int number;        
        string str_Factory_Cd = factory;
        string str_Part_No = null;
        string str_Dim = null;
        string str_Block_Cd = null;
        string str_Supplier_Cd = null;
        string str_Total_Process_Lt = null;
        //add do logic 20221005 cn
        string str_Do_Logic = null;



        DataTable dt1 = new DataTable();
        string keyIndex = null;

        foreach (DataRow row in chkDT.Rows)
        {
            str_Supplier_Cd = row["SUPPLIER_CD"].ToString().Trim().ToUpper();
            str_Part_No = row["PART_NO"].ToString().Trim().ToUpper();
            str_Block_Cd = row["BLOCK_CD"].ToString().Trim().ToUpper();
            str_Dim = row["DIM"].ToString().Trim().ToUpper();
            str_Total_Process_Lt = row["TOTAL_PROCESS_LT"].ToString().Trim().ToUpper();
            //add do logic 20221005 cn
            str_Do_Logic = row["DO_LOGIC"].ToString().Trim().ToUpper();

            keyIndex = "[SUPPLIER_CD: " + str_Supplier_Cd + " /PART_NO: " + str_Part_No + " /BLOCK_CD: " + str_Block_Cd + " /DIM: " + str_Dim + " / DO_LOGIC: " + str_Do_Logic + "]";

            //Check Null ----------------------------------------------------
            if (str_Part_No == "" )
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0007") + keyIndex);
                return false;
            }

            if (str_Dim == "" )
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0008") + keyIndex);
                return false;
            }

            if (str_Block_Cd == "")
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0009") + keyIndex);
                return false;
            }

            if (str_Supplier_Cd == "")
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0001") + keyIndex);
                return false;
            }

            if (str_Total_Process_Lt == "")
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0010") + keyIndex);
                return false;
            }
            //add do logic 20221005 cn
            if (str_Do_Logic == "")
            {
                CSUtilities.dialogMessage(this, "กรุณาระบุ DO LOGIC" + keyIndex);
                return false;
            }
            else if(str_Do_Logic != "1" && str_Do_Logic != "2" && str_Do_Logic != "3")   {

                CSUtilities.dialogMessage(this, "DO LOGIC = 1,2,3 " + keyIndex);
                return false;


            }


            //Check Lenght ----------------------------------------------------

            if (str_Part_No.Length > 12)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0011") + keyIndex);
                return false;
            }
            if (str_Dim.Length > 3)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0012") + keyIndex);
                return false;
            }
            if (str_Block_Cd.Length > 4)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0013") + keyIndex);
                return false;
            }
            if (str_Supplier_Cd.Length > 4)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0004") + keyIndex);
                return false;
            }
            if (str_Total_Process_Lt.Length > 6)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0014") + keyIndex);                
                return false;
            }

            if (!(Regex.IsMatch(str_Do_Logic, @"^\d+$")))
            {
                CSUtilities.dialogMessage(this, "กรุณาระบุ DO LOGIC เป็นตัวเลข" + keyIndex);
                return false;
            }

            //Check format
            if (!(Regex.IsMatch(str_Total_Process_Lt, @"^\d+$")))
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0021") + keyIndex);
                return false;
            }


            //Check Duplicate

            DataTable dt2 = new DataTable();
            sb.Remove(0, sb.Length);
            sb.AppendFormat("SELECT * FROM dosystem.T_PRD_DO_PART_MASTER ");
            sb.AppendFormat(" WHERE FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}' AND BLOCK_CD = '{3}' AND SUPPLIER_CD = '{4}'  ", str_Factory_Cd, str_Part_No, str_Dim, str_Block_Cd, str_Supplier_Cd);
            dt2 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];
            if (dt2.Rows.Count > 0)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("SG0001") + keyIndex);
                return false;
            }

            // add TOTAL_PROCESS_LT  20221005
            sb.Remove(0, sb.Length);
            sb.AppendFormat("SELECT DISTINCT dosystem.TOTAL_PROCESS_LT FROM T_PRD_DO_PART_MASTER ");
            sb.AppendFormat(" WHERE  FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}'  ", str_Factory_Cd, str_Part_No, str_Dim);
            dt2 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];
            string TOTAL_PROCESS_LT_CHK = null;


            if (dt2.Rows.Count > 0)
            {
                TOTAL_PROCESS_LT_CHK = dt2.Rows[0]["TOTAL_PROCESS_LT"].ToString();

                if (TOTAL_PROCESS_LT_CHK != str_Total_Process_Lt.ToString())
                {

                    CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0024") + keyIndex);
                    return false;
                }
            }



            // add do logic 20221005
            sb.Remove(0, sb.Length);
            sb.AppendFormat("SELECT DISTINCT LOGIC FROM dosystem.T_PRD_DO_PART_MASTER ");
            sb.AppendFormat(" WHERE  FACTORY_CD ='{0}' AND PART_NO = '{1}' AND DIM = '{2}'  ", str_Factory_Cd, str_Part_No, str_Dim);
            dt2 = obEx.ExecuteQuery(sb.ToString(), "T_PRD_DO_PART_MASTER").Tables[0];
            string LOGIC_CHK = null;


            if (dt2.Rows.Count > 0)
            {
                LOGIC_CHK = dt2.Rows[0]["LOGIC"].ToString();

                if (LOGIC_CHK != str_Do_Logic.ToString())
                {
                    CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WF0023") + keyIndex);
                    return false;
                }
            }


            //check Duplicate in CSV            
            int cntRow = chkDT.Select("PART_NO = '" + str_Part_No + "' AND DIM = '" + str_Dim + "' AND BLOCK_CD = '" + str_Block_Cd + "' AND SUPPLIER_CD = '" + str_Supplier_Cd + "' AND DO_LOGIC = '" + str_Do_Logic + "'").Length;

            if (cntRow > 1)
            {
                //Primary key is duplicate in CSV file.
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("WH0067") + keyIndex);
                return false;
            }

        }
        return true;
    }
    protected void UploadToDB(DataTable dt)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrorMsg.Text = "";
        int vFlag = 0;
        int vCntRow = 0;


        // add sp_plan_slide 20221005
        DataTable dt1 = new DataTable();
        

        foreach (DataRow Row in dt.Rows)
        {
            vCntRow++;
            string vIndex = " [Rows : " + vCntRow + "]";
            //add sp_plan_slide 20221005 cn


            try
            {
                objDTO.FACTORY_CD = factory;                
                objDTO.PART_NO = Row["PART_NO"].ToString().Trim().ToUpper();
                objDTO.DIM = Row["DIM"].ToString().Trim().ToUpper();
                objDTO.BLOCK_CD = Row["BLOCK_CD"].ToString().Trim().ToUpper();
                objDTO.SUPPLIER_CD = Row["SUPPLIER_CD"].ToString().Trim().ToUpper();
                objDTO.TOTAL_PROCESS_LT = Row["TOTAL_PROCESS_LT"].ToString().Trim().ToUpper();
                objDTO.DO_LOGIC = Row["DO_LOGIC"].ToString();

                objDTO.USER_ID = username;
                vFlag = objDTO.DO_PART_MASTER_INS();


                if (vFlag != 1)
                {
                    CSUtilities.dialogMessage(this, "Insert to database was failure at" + vIndex);
                    return;
                }

            }
            catch (Exception ex)
            {

                lblErrorMsg.Text = ex.Message.ToString();
                return;
            }
        }

        if (vFlag == 1)
        {
            CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0004") + "[" + vCntRow + " Rows]");
            
        }        
    }

    protected void btnDetialformat_Click(object sender, EventArgs e)
    {
        sb.Remove(0, sb.Length);
        sb.Append("PART_NO,DIM,BLOCK_CD,SUPPLIER_CD,TOTAL_PROCESS_LT,DO_LOGIC");

        CsvManagement csvManage = new CsvManagement();
        csvManage.ExportFormatCsv("Format_Part_Master", sb.ToString());
    }

    protected void gvShowData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label lblErrorMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        int vFlag = 0;
        try
        {
            objDTO.FACTORY_CD = factory;            
            objDTO.PART_NO = this.gvShowData.Rows[e.RowIndex].Cells[1].Text;
            objDTO.DIM = this.gvShowData.Rows[e.RowIndex].Cells[2].Text;
            objDTO.BLOCK_CD = this.gvShowData.Rows[e.RowIndex].Cells[3].Text;
            objDTO.SUPPLIER_CD = this.gvShowData.Rows[e.RowIndex].Cells[4].Text;
            

            objDTO.USER_ID = username;

            vFlag = objDTO.DO_PART_MASTER_DEL();

            if (vFlag == 1)
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0007"));
                BindData();
            }
            else
            {
                CSUtilities.dialogMessage(this, CSUtilities.GetErrMsg("IG0010"));
            }
        }
        catch (Exception ex)
        {
            lblErrorMsg.Text = ex.Message.ToString();

        }
    }

    protected void gvShow_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvShowData.EditIndex = e.NewEditIndex;
        BindData();
    }

    protected void gvShow_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvShowData.EditIndex = -1;
        BindData();
    }
    protected void gvShow_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label lblErrMsg = (Label)Page.Master.FindControl("lblErrorMsg");
        lblErrMsg.Text = "";

        int vCnt = 0;
        int errFlag = 0;

        TextBox txtTotalEdit = (TextBox)gvShowData.Rows[e.RowIndex].Cells[5].Controls[0];    
        TextBox txtDoLogicEdit = (TextBox)gvShowData.Rows[e.RowIndex].Cells[6].Controls[0];
   

        string strPart_No = gvShowData.Rows[e.RowIndex].Cells[1].Text;
        string strDim = gvShowData.Rows[e.RowIndex].Cells[2].Text;
        string strBlock_Cd = gvShowData.Rows[e.RowIndex].Cells[3].Text;
        string strSupplier_Cd = gvShowData.Rows[e.RowIndex].Cells[4].Text;        
        string TotalEdit = txtTotalEdit.Text.ToUpper();
        string DoLogic = txtDoLogicEdit.Text.ToUpper();



        // Check null
        if (TotalEdit == "")
        {
            txtTotalEdit.BackColor = System.Drawing.Color.Red;
            txtTotalEdit.Focus();
            lblErrMsg.Text = CSUtilities.GetErrMsg("WG0001");
            errFlag = 1;
            return;
        }

        if (DoLogic == "")
        {
            txtDoLogicEdit.BackColor = System.Drawing.Color.Red;
            txtDoLogicEdit.Focus();
            lblErrMsg.Text = CSUtilities.GetErrMsg("WG0001");
            errFlag = 1;
            return;
        }
        else if (DoLogic != "1" && DoLogic != "2" && DoLogic != "3")
        {
            txtDoLogicEdit.BackColor = System.Drawing.Color.Red;
            txtDoLogicEdit.Focus();
            lblErrMsg.Text = "DO LOGIC = 1,2,3";
            errFlag = 1;
            return;
        }



        if (errFlag == 0)
        {
            try
            {
                objDTO.FACTORY_CD = factory;
                objDTO.PART_NO = strPart_No;
                objDTO.DIM = strDim;
                objDTO.BLOCK_CD = strBlock_Cd;
                objDTO.SUPPLIER_CD = strSupplier_Cd;
                objDTO.TOTAL_PROCESS_LT = TotalEdit;
                objDTO.DO_LOGIC = DoLogic;
                objDTO.USER_ID = username;
                vCnt = objDTO.DO_PART_MASTER_UPD();

                if (vCnt == 1)
                {
                    gvShowData.EditIndex = -1;
                    BindData();
                    lblErrMsg.Text = CSUtilities.GetErrMsg("IG0004");
                }
                else
                {
                    lblErrMsg.Text = CSUtilities.GetErrMsg("WL0002");
                }
            }
            catch (Exception ex)
            {
                lblErrMsg.Text = ex.Message.ToString();
            }
        }

    }


    protected void gvShowData_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        this.gvShowData.PageIndex = e.NewPageIndex;
        BindData();
    }

    protected void gvShowData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onmouseover", "javascript:this.style.cursor = 'pointer';");            
        }
        if (Convert.ToBoolean(e.Row.RowState & DataControlRowState.Edit))
        {
            TextBox txt_Total = (TextBox)e.Row.Cells[5].Controls[0];
            txt_Total.CssClass = "form-control input-sm";
            txt_Total.Width = 90;
            
        }
    }


    protected void btnExit_Click(object sender, EventArgs e)
    {
        Response.Redirect("UI_PRD_S041_DO_Main_Menu1.aspx?&FACTORY_CD=" + factory + "&username=" + username);
    }


}
